/* Documentation - flowing, multi-page A4 portrait documents built from blocks (elements).
   Every page is its own single-page spread (data-pages="1"):
     .dc-first  page 1: shared header (js/header.js) + document details + flow
     .dc-mid    intermediate pages: reduced header + flow + footer with title + page number
     .dc-last   end page (optional, always last): reduced header + flow + full footer band
   Pages are added / removed by the author (Elements panel: + Page, + End page; "Remove" above each page).
   Blocks (.dc-blk[data-blk]) live in the .dc-flow of each page. app.js (dcFlow) only pushes forward: anything after a
   page break or that no longer fits moves to the top of the next page (headings travel with what follows).
   Insert blocks from the Elements panel; the floating block toolbar moves, duplicates, deletes and sets options. */
window.TEMPLATES = window.TEMPLATES || {};
(function () {
  const ce = 'contenteditable="true" spellcheck="false"';
  const P = "Body text. Write in short, plain sentences: what the reader needs to know, in the order they need it.";
  const ICON = {
    fact: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 7v6M12 16.5v.5"/></svg>',
    note: '<svg viewBox="0 0 24 24"><path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 12h7M9 16h7"/></svg>',
    best: '<svg viewBox="0 0 24 24"><path d="M12 3l2.7 5.6 6.1.8-4.5 4.2 1.1 6.1L12 16.8 6.6 19.7l1.1-6.1L3.2 9.4l6.1-.8z"/></svg>',
    info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7.5v.5"/></svg>',
    check:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M7.5 12.5l3 3 6-6.5"/></svg>',
    stop: '<svg viewBox="0 0 24 24"><path d="M8 2.5h8l5.5 5.5v8L16 21.5H8L2.5 16V8z"/><path d="M8 12h8"/></svg>',
    clock:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6.5V12l3.5 2.5"/></svg>',
    people:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.2-5.5 6.5-5.5s5.900 1.900 6.500 5.500M16 4.800a3.500 3.500 0 0 1 0 6.400M18.500 14.800c1.700.800 2.700 2.600 3 5.200"/></svg>',
    warn: '<svg viewBox="0 0 24 24"><path d="M12 3 2 21h20L12 3z"/><path d="M12 10v5M12 17.8v.4"/></svg>',
    tip:  '<svg viewBox="0 0 24 24"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V16h5v-.1c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/></svg>',
    link: '<svg viewBox="0 0 24 24"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></svg>',
    tick: '<svg viewBox="0 0 24 24"><path d="M4 12.5l5 5L20 6.5"/></svg>',
    cross:'<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>'
  };
  const CALLOUT = { fact: "Key fact", note: "Note", warn: "Warning", tip: "Tip", best: "Best practice" };
  const fig = (slot, label, cls = "") => `<div class="d-fig dc-img ${cls}" data-slot="${slot}" data-label="${label}"><div class="in"><img alt=""></div></div>`;
  /* certification cells: one "Compliance" link pill per entry (split with ";"); a URL becomes the link, anything else is kept as the hover title */
  const CERT = c => { const url = /^(https?:\/\/|www\.)|\.[a-z]{2,}(\/|$)/i.test(c), href = url ? (/^https?:/i.test(c) ? c : "https://" + c) : "";
    return `<span class="dc-sp-b" data-link="sc${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}"${href ? ` data-href="${href}"` : ""}${!url && c && c !== "Certification" ? ` title="${c}"` : ""}><i class="dc-sp-bi">${ICON.link}</i>Verified</span>`; };
  const SPEC_ROW = (p, u, c) => `<div class="dc-sp-r"><div class="dc-sp-pw" data-link="sp${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}"><i class="dc-sp-li" title="Click to add a link to the product">${ICON.link}</i><div class="ed dc-sp-p" ${ce}>${p}</div></div><div class="ed dc-sp-u" ${ce}>${u}</div><div class="dc-sp-c">${(c || "").split(/\s*;\s*/).filter(Boolean).map(CERT).join("") || CERT("")}</div></div>`;
  const blk = (type, inner, extra = "") => `<div class="dc-blk" data-blk="${type}"${extra}>${inner}</div>`;
  const chart = (type, o) => blk(type, `<div class="dc-chart" data-chart="${JSON.stringify(o).replace(/&/g, "&amp;").replace(/"/g, "&quot;")}"></div>`);
  const li = (n, t) => Array.from({ length: n }, (_, i) => `<li>${t.replace(/^\[/, "")} ${i + 1}</li>`).join("");
  /* Process Cards: numbered arrow header + card with a bold line and a paragraph; horizontal row(s) or a vertical stack */
  const stage = i => `<div class="dc-fc"><div class="dc-fh"><i class="dc-fn"></i><div class="ed dc-fl" data-role="caption" ${ce}>Stage ${i}</div></div><div class="dc-fb"><div class="ed dc-fbt" data-role="dcsh" ${ce}>Bold line for this stage</div><div class="ed dc-fbp dc-rich" ${ce}><p>A short description of what happens at this stage and who is responsible for it.</p></div></div></div>`;
  const step = i => `<div class="dc-step"><i class="dc-tick" title="Mark this step complete"></i><span class="dc-sn"></span><div class="ed dc-stt" data-role="dcst" ${ce}>Step ${i}</div><div class="ed dc-stx" ${ce}>What happens, in one or two short lines.</div></div>`;

  /* element library: label for the Elements panel + html(uid) */
  const B = {
    ltitle:  { label: "Lge Text", html: () => blk("ltitle", `<div class="ed dc-lt" data-role="dclt" ${ce}>LARGE TITLE</div>`) },
    lsub:    { label: "Lge Sub-text", html: () => blk("lsub", `<div class="ed dc-ls" data-role="dcls" ${ce}>Large sub-title</div>`) },
    space:   { label: "Space", html: () => blk("space", `<div class="dc-space" data-v="1"></div>`) },
    map:     { label: "Map", html: u => blk("map", `<div class="dc-mapu"><div class="d-fig dc-img dc-map" data-slot="dc${u}" data-label="Site map - click to add" data-mapslot="1"><div class="in"><img alt=""></div></div><div class="dc-mapcap"><i>${ICON.link}</i>Click for Directions</div></div>`) },
    maptext: { label: "Map Text", html: u => B.map.html(u).replace('data-blk="map"', 'data-blk="map" data-w="50"') },   // a map block at half width with text beside it (same controls as Map)
    toc:     { label: "Contents", html: () => blk("toc", `<div class="dc-toc" data-lv="1"><div class="ed dc-toch" data-role="dch" ${ce}>Contents</div><div class="dc-tlist"></div></div>`) },
    section: { label: "Section", html: () => blk("section", `<div class="dc-sect"><span class="dc-num">01</span><div class="ed dc-stitle" data-role="dcsect" ${ce}>Section title</div></div>`) },
    heading: { label: "Heading", html: () => blk("heading", `<div class="ed dc-h" data-role="dch" ${ce}>Heading</div>`) },
    sub:     { label: "Sub-heading", html: () => blk("sub", `<div class="ed dc-sh" data-role="dcsh" ${ce}>Sub-heading</div>`) },
    para:    { label: "Text", html: () => blk("para", `<div class="ed dc-p dc-rich" ${ce}><p>${P}</p></div>`) },
    paraplus:{ label: "Text+", html: () => blk("para", `<div class="ed dc-p dc-rich plus" ${ce}><p>${P}</p></div>`) },   // Text x 1.3 (same element; size can still be changed in Text style)
    olist:   { label: "Numbered", html: () => blk("list", `<ol class="ed dc-list dc-rich" ${ce}><li>First item</li><li>Second item<ol><li>Sub-item</li><li>Sub-item</li></ol></li><li>Third item</li></ol>`) },
    list:    { label: "Bulleted", html: () => blk("list", `<ul class="ed dc-list dc-rich" ${ce}>${li(3, "[List item")}</ul>`) },
    list2:   { label: "List (x2)", html: () => blk("list2", `<ul class="ed dc-list dc-rich two" ${ce}>${li(6, "[List item")}</ul>`) },
    list3:   { label: "List (x3)", html: () => blk("list3", `<ul class="ed dc-list dc-rich three" ${ce}>${li(9, "[List item")}</ul>`) },
    callout: { label: "Attention", html: () => blk("callout", `<div class="dc-call" data-v="fact"><i class="dc-cicon">${ICON.fact}</i><div class="dc-ctag">${CALLOUT.fact}</div><div class="ed dc-ctext dc-rich" ${ce}><p>The one thing the reader must remember from this section.</p></div></div>`) },
    glance:  { label: "Glance", html: () => blk("glance", `<div class="dc-glance">${[["Time needed", "2 hours"], ["Who", "Site manager"], ["You will need", "PPE, permit"]].map(([l, v]) => `<div class="dc-gi"><div class="ed dc-gl" data-role="statl" ${ce}>${l}</div><div class="ed dc-gv" data-role="statv" ${ce}>${v}</div></div>`).join("")}</div>`) },
    medial:  { label: "Image Left", html: u => blk("media", `<div class="dc-media"><div class="dc-mfig">${fig("dc" + u, "Photo")}</div><div class="dc-mtext"><div class="ed dc-sh" data-role="dcsh" ${ce}>Sub-heading</div><div class="ed dc-p dc-rich" ${ce}><p>${P}</p><p>A second short paragraph if needed.</p></div></div></div>`) },
    mediar:  { label: "Image Right", html: u => blk("media", `<div class="dc-media flip"><div class="dc-mfig">${fig("dc" + u, "Photo")}</div><div class="dc-mtext"><div class="ed dc-sh" data-role="dcsh" ${ce}>Sub-heading</div><div class="ed dc-p dc-rich" ${ce}><p>${P}</p><p>A second short paragraph if needed.</p></div></div></div>`) },
    /* image with a link beside it (link on the left by default); same image tools as Image Left / Right */
    medialink: { label: "Image Link", html: u => blk("media", `<div class="dc-media flip lnk"><div class="dc-mfig">${fig("dc" + u, "Photo")}</div><div class="dc-mtext"><div class="dc-url" data-link="dl${u}" data-href="https://www.gmi.co.uk"><i class="dc-uicon">${ICON.link}</i><div><div class="ed dc-ulabel" data-role="dch" ${ce}>Link title, e.g. Open the 360 site tour</div><div class="dc-uaddr">www.gmi.co.uk</div></div></div></div></div>`) },
    imagefw: { label: "Image", html: u => blk("imagefw", `${fig("dc" + u, "Photo", "wide")}`) },
    image2:  { label: "Image (x2)", html: u => blk("image2", `<div class="dc-pair">${fig("dc" + u + "a", "Photo")}${fig("dc" + u + "b", "Photo")}</div>`) },
    image3:  { label: "Image (x3)", html: u => blk("image3", `<div class="dc-pair three">${["a", "b", "c"].map(x => fig("dc" + u + x, "Photo")).join("")}</div>`) },
    image4:  { label: "Image (x4)", html: u => blk("image4", `<div class="dc-pair four">${["a", "b", "c", "d"].map(x => fig("dc" + u + x, "Photo")).join("")}</div>`) },
    para3:   { label: "Text (x3)", html: () => blk("para3", `<div class="ed dc-p dc-rich three" ${ce}><p>${P}</p><p>${P}</p><p>${P}</p></div>`) },
    para4:   { label: "Text (x4)", html: () => blk("para4", `<div class="ed dc-p dc-rich four" ${ce}><p>${P}</p><p>${P}</p><p>${P}</p><p>${P}</p></div>`) },
    para2:   { label: "Text (x2)", html: () => blk("para2", `<div class="ed dc-p dc-rich two" ${ce}><p>${P}</p><p>A second paragraph flows into the right-hand column when the left one is full.</p><p>${P}</p></div>`) },
    flow:    { label: "Process Cards", html: () => blk("flow", `<div class="dc-flowc" data-c="red">${[1, 2, 3, 4].map(stage).join("")}</div>`) },
    steps:   { label: "Process", html: () => blk("steps", `<div class="dc-steps">${[1, 2, 3, 4].map(step).join("")}</div>`) },
    dodont:  { label: "Do / Don't", html: () => blk("dodont", `<div class="dc-dd"><div class="dc-do"><div class="dc-ddh"><i>${ICON.tick}</i><span class="ed dc-ddl" ${ce}>Do</span></div><ul class="ed dc-rich" ${ce}>${li(3, "[Do")}</ul></div><div class="dc-dont"><div class="dc-ddh"><i>${ICON.cross}</i><span class="ed dc-ddl" ${ce}>Don&rsquo;t</span></div><ul class="ed dc-rich" ${ce}>${li(3, "[Don't")}</ul></div><div class="ed dc-p dc-rich dc-ddtext" ${ce}><p>Explain why this matters, or what to do instead.</p></div></div>`) },
    directory: { label: "Directory", html: () => blk("directory", `<div class="ed dc-tablewrap dc-rich" ${ce}><table class="dc-table dc-dir"><thead><tr><th>Name</th><th>Role</th><th>Business</th><th>Email</th><th>Telephone</th></tr></thead><tbody>${[1, 2, 3].map(() => "<tr><td>Name</td><td>Role</td><td>Business</td><td>name@company.co.uk</td><td>01234 567890</td></tr>").join("")}</tbody></table></div>`) },
    /* signature block: Name 30% | Position 30% | Date 10% | Signature 30%, tall rows to sign in */
    sign:    { label: "Signatures", html: () => blk("sign", `<div class="ed dc-tablewrap dc-rich" ${ce}><table class="dc-table dc-sign" style="table-layout:fixed"><thead><tr><th style="width:30%">Name</th><th style="width:30%">Position</th><th style="width:10%">Date</th><th style="width:30%">Signature</th></tr></thead><tbody>${[1, 2, 3].map(() => "<tr><td></td><td></td><td></td><td></td></tr>").join("")}</tbody></table></div>`) },
    table:   { label: "Table", html: () => blk("table", `<div class="ed dc-tablewrap dc-rich" ${ce}><table class="dc-table"><thead><tr><th>Item</th><th>Detail</th><th>Who</th></tr></thead><tbody>${[1, 2, 3].map(() => "<tr><td>...</td><td>...</td><td>...</td></tr>").join("")}</tbody></table></div>`) },
    /* QR code (as on Project Info): click the code (or the address) to change the link; the code redraws to match */
    qr:      { label: "QR Code", html: u => blk("qr", `<div class="dc-qrb"><div class="d-qr" data-link="dq${u}" data-href="https://www.gmi.co.uk" title="Click to change the link"></div><div class="dc-qrt"><div class="ed dc-ulabel" data-role="dch" ${ce}>What the code opens, e.g. Site induction video</div><div class="ed dc-p dc-rich" ${ce}><p>Scan or Click</p></div><div class="dc-uaddr" data-link="dq${u}" data-href="https://www.gmi.co.uk">www.gmi.co.uk</div></div></div>`) },
    url:     { label: "Link", html: u => blk("url", `<div class="dc-url" data-link="dl${u}" data-href="https://www.gmi.co.uk"><i class="dc-uicon">${ICON.link}</i><div><div class="ed dc-ulabel" data-role="dch" ${ce}>Link title, e.g. Read the full policy</div><div class="dc-uaddr">www.gmi.co.uk</div></div></div>`) },
    timeline:{ label: "Timeline", html: () => blk("timeline", `<div class="dc-gantt" data-chart="${JSON.stringify({ t: "gantt", c: "#d20a11", d: [
      ["Site set-up and welfare", "2026-11-02", "2026-11-13"], ["Groundworks and drainage", "2026-11-16", "2026-12-18"],
      ["Frame erection", "2027-01-04", "2027-02-26"], ["Roof and envelope", "2027-02-15", "2027-04-09"], ["Internal fit-out", "2027-03-22", "2027-05-28"]] }).replace(/"/g, "&quot;")}"></div>`) },
    inhere:  { label: "In Here", html: () => blk("inhere", `<div class="dc-inhere" data-c="red"><div class="ed dc-ihl" ${ce}>In here</div><div class="ed dc-iht dc-rich" ${ce}><p>A short introduction to this section: what it covers, who it is for and what the reader will be able to do by the end. Keep it under 100 words.</p></div></div>`) },
    /* product highlight: name | type, two open content cells, then link | detail | detail | link */
    product: { label: "Product", html: u => {
      const lk = (x, t) => `<div class="dc-url dc-pr-l" data-link="pl${u}${x}" data-href="https://www.gmi.co.uk"><i class="dc-uicon">${ICON.link}</i><div><div class="ed dc-ulabel" ${ce}>${t}</div><div class="dc-uaddr">www.gmi.co.uk</div></div></div>`;
      const dt = (l, v) => `<div class="dc-pr-x"><div class="ed dc-pr-xl" ${ce}>${l}</div><div class="ed dc-pr-xv" ${ce}>${v}</div></div>`;
      return blk("product", `<div class="dc-prod" data-c="red"><div class="ed dc-pr-n" data-role="dch" ${ce}>Product name</div><div class="ed dc-pr-t" ${ce}>Product type</div>`
        + `<div class="ed dc-pr-c dc-rich" data-ph="Add content" ${ce}></div><div class="ed dc-pr-c dc-rich" data-ph="Add content" ${ce}></div>`
        + lk("a", "Product page") + dt("Detail", "Value") + dt("Detail", "Value") + lk("b", "Datasheet") + `</div>`); } },
    /* product list: product | main use | certification, one row per product (toolbar: + / − row, Paste list) */
    specs:   { label: "Product List", html: () => blk("specs", `<div class="dc-spec" data-c="red"><div class="dc-sp-h"><span class="ed" ${ce}>Product</span><span class="ed" ${ce}>Main use</span><span class="ed" ${ce}>Certification</span></div>${[1, 2, 3].map(() => SPEC_ROW("Product name", "What it is used for, in a few words", "Certification")).join("")}</div>`) },
    /* how long something takes: a clock icon, the time in large type, a small caption and (Rule style) a divider line running on from it */
    duration: { label: "Duration", html: () => blk("duration", `<div class="dc-dur" data-c="green" data-v="rule"><svg class="dc-dur-i" viewBox="0 0 48 48" aria-hidden="true"><rect x="7" y="10" width="34" height="31" rx="4"/><path d="M7 20h34M16 5v9M32 5v9"/></svg><span class="dc-dur-g"><span class="ed dc-dur-v" ${ce}>3m</span><span class="ed dc-dur-t" ${ce}>Time to complete</span></span><i class="dc-dur-l"></i></div>`) },
    hr:      { label: "Divider", html: () => blk("hr", `<div class="dc-hr" data-v="line"><span></span></div>`) },
    /* charts: data lives in data-chart (JSON), drawn and edited by app.js (renderPlus / editPlus) */
    "ch-pie":   { label: "Donut", html: () => chart("ch-pie", { t: "pie", h: "Breakdown", cl: "Total", cv: "", u: "",
      d: [["Category A", 420, "#d20a11"], ["Category B", 260, "#1d1d1b"], ["Category C", 180, "#8a8a90"], ["Category D", 90, "#f08a8d"]] }) },
    "ch-pie2":  { label: "Double Donut", html: () => chart("ch-pie2", { t: "pie2", h: "Sales by product", i: "Last year", o: "This year",
      d: [["Product A", 12, 18, "#d20a11"], ["Product B", 29, 20, "#1d1d1b"], ["Product C", 45, 35, "#8a8a90"], ["Product D", 14, 27, "#f08a8d"]] }) },
    "ch-sun":   { label: "Sunburst", html: () => chart("ch-sun", { t: "sun", h: "Incident numbers", u: "", dp: 2, r1: "Region", r2: "Severity", r3: "Cause",
      d: [["Yorkshire", "#d20a11", [["Near miss", 16], ["Minor", 9], ["Lost time", 3]], [["Slips & trips", 11], ["Manual handling", 9], ["Plant", 8]]],
          ["North West", "#1d1d1b", [["Near miss", 12], ["Minor", 4], ["Lost time", 5], ["RIDDOR", 1]], [["Slips & trips", 8], ["Manual handling", 7], ["Plant", 7]]],
          ["Midlands", "#8a8a90", [["Near miss", 5], ["Minor", 4], ["Lost time", 3], ["RIDDOR", 1]], [["Slips & trips", 6], ["Plant", 7]]],
          ["North East", "#ff8c2a", [["Near miss", 3], ["Minor", 2], ["Lost time", 1]], [["Slips & trips", 4], ["Manual handling", 2]]]] }) },
    "ch-kpi":   { label: "Bars + KPIs", html: () => chart("ch-kpi", { t: "kpi", h: "Weekly values", c: "#d20a11", u: "",
      d: [["Wk 1", 62], ["Wk 2", 78], ["Wk 3", 55], ["Wk 4", 84], ["Wk 5", 96], ["Wk 6", 71], ["Wk 7", 88], ["Wk 8", 67]],
      k: [["Target", "90", "up"], ["Last week", "71", "down"], ["Last month", "74", "up"]] }) },
    "ch-gauge": { label: "Gauge", html: () => chart("ch-gauge", { t: "gauge", h: "Progress to target", v: 850, max: 1200, u: "", s: "", c: "#d20a11" }) },
    "ch-lines": { label: "Line", html: () => chart("ch-lines", { t: "lines", h: "Trend over time", a: 1,
      x: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      s: [["Series A", "#d20a11", [22, 28, 26, 34, 41, 38, 46, 52, 49, 57, 63, 68]], ["Series B", "#1d1d1b", [15, 18, 24, 22, 27, 33, 31, 36, 42, 40, 45, 51]],
          ["Series C", "#8a8a90", [8, 12, 11, 16, 15, 21, 25, 23, 28, 31, 30, 36]]] }) },
    "ch-radar": { label: "Radar", html: () => chart("ch-radar", { t: "radar", h: "Areas of knowledge", max: 10, c: "#d20a11",
      d: [["Planning", 8], ["Safety", 9], ["Quality", 7], ["Cost", 6], ["Programme", 8], ["Design", 5], ["Commercial", 6], ["Logistics", 7],
          ["Sustainability", 4], ["People", 8], ["Client", 9], ["Digital", 5]] }) },
    "ch-track": { label: "Progress", html: () => chart("ch-track", { t: "track", h: "Programme position", s: "2026-01-05", n: "", e: "2026-12-18", m: [["Target", "2026-11-27"]],
      ln: "Now", c: "#d20a11", ca: "#ffc15e", cb: "#f7c3c9" }) },
    pagebreak: { label: "Page break", html: () => blk("pagebreak", `<div class="dc-break"><span>Page break</span></div>`) }
  };
  const ORDER = ["ltitle", "lsub", "toc", "section", "heading", "sub", "para", "para2", "url", "list", "list2", "map",
                 "medial", "mediar", "imagefw", "image2", "callout", "inhere", "glance", "steps", "flow", "dodont", "table", "timeline", "space", "hr", "duration",
                 "ch-pie", "ch-pie2", "ch-sun", "ch-kpi", "ch-gauge", "ch-lines", "ch-radar", "ch-track"];

  const mini = () => `
  <div class="dc-mini"><i class="gh-l3"></i><i class="gh-l2"></i><i class="gh-l1"></i><div class="dc-mtitle" data-sync-of="title">DOCUMENT TITLE</div></div>
  <img class="d-logo dc-mlogo" data-logo="colour" alt="GMI">`;
  const pn = '<span class="dc-pn"></span>';
  /* revision record: sits at the foot of the contents page (front page if there is no contents); newest revision on top.
     Each entry: Reference | Revision | Issued | Owner, then a full-width Revision notes row. */
  const revEntry = (ref = "GMI-XXX-000", rev = "A", date = "DD-Mmm-YY", owner = "Name, Role", notes = "First issue.") => `<div class="dc-rv">
    <div class="dc-meta"><div><b>Reference</b><span class="ed dc-rvref" data-role="caption" ${ce}>${ref}</span></div><div><b>Revision</b><span class="ed dc-rvrev" data-role="caption" ${ce}>${rev}</span></div><div><b>Issued</b><span class="ed dc-rvdate" data-role="caption" ${ce}>${date}</span></div><div><b>Owner</b><span class="ed dc-rvown" data-role="caption" ${ce}>${owner}</span></div></div>
    <div class="dc-rvn"><b>Revision notes</b><div class="ed dc-rvnt" data-role="caption" ${ce}>${notes}</div></div></div>`;
  const revs = () => `<div class="dc-revs"><div class="dc-rvh">Revision record</div>${revEntry()}</div>`;
  /* end page: the full stepped header (mirrors the front page sub-title and title) and stepped brand shapes rising from the bottom left */
  const endHead = () => `<div class="gh dc-endh"><i class="gh-l3"></i><i class="gh-l2"></i><i class="gh-l1"></i><div class="gh-sub" data-sync-of="sub">DOCUMENTATION</div><div class="gh-title d-mast" data-sync-of="title">DOCUMENT TITLE</div></div>
  <div class="gh-logo"><img class="d-logo" data-logo="ed-colour" alt="GMI Exceptional Delivery"></div>`;
  const endArt = () => `<svg class="dc-endart" viewBox="0 180 210 117" preserveAspectRatio="none" aria-hidden="true">
    <polygon class="ea-a" points="128,188 210,188 210,297 60,297 60,256"/>
    <polygon class="ea-b" points="48,236 150,236 150,297 12,297 12,272"/>
    <polygon class="ea-c" points="130,212 210,212 210,297 80,297 80,262"/></svg>`;

  /* "More Info": who to contact. Round profile photo, name, region (from the Region selector) and an email icon (first.last@gmi.co.uk from the name); x1 to x3 side by side; image border controls apply to the photo */
  const MAIL = '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>';
  const MORE = { label: "More Info", html: u => `<div class="dc-blk" data-blk="moreinfo"><div class="dc-mi" data-c="red"><div class="d-fig dc-img round" data-slot="dc${u}" data-label="Profile"><div class="in"><img alt=""></div></div><div class="dc-mit"><div class="ed dc-min" data-role="dcsh" ${ce}>Name Surname</div><div class="dc-mil" data-region-name>${regionOf().name}</div></div><div class="dc-mimail" data-link="dm${u}" data-href="mailto:name.surname@gmi.co.uk" title="name.surname@gmi.co.uk (made from the name). Click to type a different address">${MAIL}</div></div></div>` };
  B.moreinfo = MORE;
  /* Template settings read by the shared editor (app.js): blocks (a template made of blocks on flowing pages gets the full editor);
     identifier:false drops the front-page identifier row; endPage:false drops the mandatory GMI end page; cats:[[key,label]..] adds the
     footer category buttons and keeps every page's .gf banner in step. Add a setting here instead of testing the template name in app.js. */
  window.TEMPLATES.documentation = {
    name: "Documentation",
    desc: "A4 portrait &middot; flowing pages",
    file: "documentation",
    pages: 3,                       // starting count; app.js counts the real pages
    portraitOnly: true,
    landscape: true,   // the Landscape button turns the pages into A4 landscape (297 x 210 mm); templates built on this one that are portrait-only set landscape:false
    defaultSlots: {},
    slotOrder: [],
    slotLabels: {},
    blocks: B, blockOrder: ORDER,
    blockGroups: [["Text", [["ltitle", "Title", "Large title text"], ["lsub", "Sub-title", "Large sub-title text"], ["paraplus", "Text+", "Text with a large opening paragraph"],
                             ["heading", "Heading", "A heading"], ["sub", "Sub-heading", "A sub-heading"], ["para", "Text", "A paragraph of text"]]],
                  ["Lists and links", [["list", "Bullets", "A bulleted list"], ["olist", "Numbered", "A numbered list"], ["url", "Link", "A web link (button or address)"],
                             ["map", "Map", "A map of the site, with optional text beside it"], ["qr", "QR", "A QR code that opens a web address"], ["video", "Video", "Coming soon", true]]],
                  ["Images", [["imagefw", "Image", "A photo across the page (choose 1 to 4 across in the Layout panel)"], ["medial", "Image Text", "A photo with text beside it (swap sides with the arrows)"], ["medialink", "Image Link", "A photo with a web link beside it"]]],
                  ["Components", [["space", "Spacer", "A blank gap"], ["hr", "Divider", "A dividing line"], ["callout", "Attention", "A highlighted note: fact, note, warning, tip or best practice"],
                             ["steps", "Process", "Numbered process steps"], ["flow", "Process Cards", "Numbered stages as cards, in a row or stacked down the page"], ["dodont", "Do / Don't", "Do and Don't panels"],
                             ["duration", "Duration", "How long something takes: calendar icon, time and a divider line"], ["glance", "Glance", "Key facts at a glance"], ["moreinfo", "More Info", "Who to contact: photo, name, region and an email icon"],
                             ["table", "Table", "A table you can add rows and columns to"], ["directory", "Directory", "A contact directory table"], ["specs", "Product List", "A list of products with their use and certification"]]],
                  ["Charts", [["ch-track", "Progress", "Progress tracker"], ["timeline", "Timeline", "A programme timeline"], ["ch-lines", "Line", "Line chart"],
                             ["ch-pie", "Donut", "Donut chart"], ["ch-pie2", "Double Donut", "Two donut rings sharing the same segments"], ["ch-sun", "Sunburst", "Category, sub and sub-sub rings, each ring a different split of the category"],
                             ["ch-kpi", "Bars + KPIs", "Bar chart with key figures"], ["ch-gauge", "Gauge", "Gauge chart"], ["ch-radar", "Radar", "Radar chart"]]]], callouts: CALLOUT, icons: ICON, calloutIcons: ["fact", "note", "warn", "tip", "best", "info", "check", "stop", "clock", "people"], step, flowStage: stage, specRow: SPEC_ROW,
    page: kind => kind === "chap"
      ? `<section class="d-spread nl dc dc-mid dc-chap" data-pages="1">${mini()}<div class="dc-cbox"><div class="dc-chead"><span class="dc-cnum">01</span><div class="ed dc-ctitle" data-role="dcsect" ${ce}>Chapter title</div></div><div class="dc-clist"></div></div></section>`
      : kind === "mid"
      ? `<section class="d-spread nl dc dc-mid" data-pages="1">${mini()}<div class="dc-flow"></div><div class="dc-foot"><span class="dc-ftitle" data-sync-of="ref">GMI-XXX-000</span>${pn}</div></section>`
      : `<section class="d-spread nl dc dc-last" data-pages="1"><div class="dc-flow"></div>${endArt()}
  <div class="ed dc-fcontact" data-role="addr" ${ce}>${regionContact()}</div><img class="d-logo dc-elogo" data-logo="white" alt="GMI">${pn}</section>`,
    endHead, endArt, revs, revEntry,
    html(style) {
      const starter = "";            // opens as a blank playground: first, intermediate and end page
      const page = this.page;
      return `
<section class="d-spread nl dc dc-first" id="dc-top" data-style="${style}" data-pages="1">
  ${gmiHeader({ sub: "DOCUMENTATION", title: "DOCUMENT TITLE", date: monYY(), sync: true })}
  <div class="dc-flow">${starter}</div>
  ${revs()}
</section>
${page("mid").replace('class="d-spread', `data-style="${style}" class="d-spread`)}
${page("last").replace('class="d-spread', `data-style="${style}" class="d-spread`)}`;
    }
  };
})();
