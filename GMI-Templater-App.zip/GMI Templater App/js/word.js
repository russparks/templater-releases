/* Word export: the document's text as a plain, editable .docx (headings, paragraphs, bullet and numbered lists, tables, bold/italic).
   No pictures, charts, maps or GMI styling: the full-looking copy goes alongside as a PDF (app.js #outWord).
   GMI_WORD.build(pages, title) reads the live pages (so it can tell what is hidden or how big text is) and returns a .docx Blob.
   A .docx is a zip of XML parts; zipStore (app.js) packs them. */
window.GMI_WORD = (function () {
  "use strict";
  const SKIP = ".pgctl,.pgopts,.dc-up,.dc-foot,.gf,.dc-mini,.dc-mlogo,.gh-logo,.d-logo,.dc-endart,.dc-toc,.dc-clist,.dc-pn,svg,img,canvas,button,input,select,video,iframe,.maplibregl-map,.maplibregl-control-container,[data-blk=pagebreak],[data-blk=spacer],[data-blk=divider],.dc-guide,.ph-hint";
  const BLOCK = /^(block|flex|grid|list-item|table|table-row|table-cell|flow-root|inline-grid|inline-flex)$/;
  const xe = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const shown = el => { const cs = getComputedStyle(el); return cs.display !== "none" && cs.visibility !== "hidden" && +cs.opacity !== 0; };

  /* text runs of an element: bold / italic from the computed style, <br> as a line break */
  function runs(el, base) {
    const out = [];
    (function walk(n, b, i) {
      for (const c of n.childNodes) {
        if (c.nodeType === 3) { let t = c.textContent.replace(/\s+/g, " "); if (t && c.parentElement && getComputedStyle(c.parentElement).textTransform === "uppercase") t = t.toUpperCase(); if (t) out.push({ t, b, i }); }
        else if (c.nodeType === 1) {
          if (c.matches(SKIP) || !shown(c) || (base.noLists && /^(UL|OL)$/.test(c.tagName))) continue;
          if (c.tagName === "BR") { out.push({ br: 1 }); continue; }
          const cs = getComputedStyle(c); walk(c, +cs.fontWeight >= 600, cs.fontStyle === "italic");
        }
      }
    })(el, base.b, base.i);
    while (out.length && out[0].t && !out[0].t.trim()) out.shift();
    if (out.length && out[0].t) out[0].t = out[0].t.replace(/^\s+/, "");
    if (out.length && out[out.length - 1].t) out[out.length - 1].t = out[out.length - 1].t.replace(/\s+$/, "");
    return out;
  }
  const runXml = rs => rs.map(r => r.br ? "<w:r><w:br/></w:r>" : `<w:r>${r.b || r.i ? `<w:rPr>${r.b ? "<w:b/>" : ""}${r.i ? "<w:i/>" : ""}</w:rPr>` : ""}<w:t xml:space="preserve">${xe(r.t)}</w:t></w:r>`).join("");
  const hasText = rs => rs.some(r => r.t && r.t.trim());

  function build(pages, title) {
    const body = [], nums = []; let numId = 2;
    const para = (rs, style, extra = "") => { if (!hasText(rs)) return; body.push(`<w:p><w:pPr>${style ? `<w:pStyle w:val="${style}"/>` : ""}${extra}</w:pPr>${runXml(rs)}</w:p>`); };
    const styleFor = (el, rs) => {
      if (el.closest(".gh-title")) return "Title"; if (el.closest(".gh-sub")) return "Subtitle";
      if (el.closest(".dc-ctitle")) return "Heading1";
      const pt = parseFloat(getComputedStyle(el).fontSize) * .75, bold = +getComputedStyle(el).fontWeight >= 600, len = rs.reduce((n, r) => n + (r.t || "").length, 0);
      if (len > 140 || len < 4 || /^[\d\s.,%£$:/+-]+[a-z]{0,2}$/i.test(rs.map(r => r.t || "").join("").trim())) return "";   // big numbers and figures stay as (bold) text, not headings
      if (pt >= 17) return "Heading1"; if (pt >= 13.5 && bold) return "Heading2"; if (pt >= 11.5 && bold && len < 90) return "Heading3"; return "";
    };
    function list(el, lvl) {
      const ordered = el.tagName === "OL"; let id = 1;
      if (ordered) { id = numId++; nums.push(id); }
      for (const li of el.children) {
        if (li.tagName !== "LI" || !shown(li)) continue;
        para(runs(li, { b: false, i: false, noLists: true }), "ListParagraph", `<w:numPr><w:ilvl w:val="${Math.min(lvl, 4)}"/><w:numId w:val="${id}"/></w:numPr>`);
        [...li.children].filter(c => /^(UL|OL)$/.test(c.tagName)).forEach(n => list(n, lvl + 1));
      }
    }
    function table(el) {
      const rows = [...el.rows].filter(shown); if (!rows.length) return;
      const cols = Math.max(...rows.map(r => r.cells.length));
      const tr = rows.map(r => `<w:tr>${[...r.cells].map(c => { const rs = runs(c, { b: c.tagName === "TH", i: false }); return `<w:tc><w:tcPr><w:tcW w:w="${Math.round(9000 / cols)}" w:type="dxa"/></w:tcPr><w:p>${runXml(rs)}</w:p></w:tc>`; }).join("")}</w:tr>`).join("");
      body.push(`<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="5000" w:type="pct"/></w:tblPr><w:tblGrid>${"<w:gridCol/>".repeat(cols)}</w:tblGrid>${tr}</w:tbl>`, "<w:p/>");
    }
    function walk(el) {
      if (el.matches(SKIP) || !shown(el)) return;
      if (/^(UL|OL)$/.test(el.tagName)) return list(el, 0);
      if (el.tagName === "TABLE") return table(el);
      const kids = [...el.children].filter(c => !c.matches(SKIP) && shown(c));
      const blockKids = kids.filter(c => BLOCK.test(getComputedStyle(c).display) || /^(UL|OL|TABLE|P|H[1-6]|DIV|LI)$/.test(c.tagName));
      if (!blockKids.length) { const rs = runs(el, { b: +getComputedStyle(el).fontWeight >= 600, i: getComputedStyle(el).fontStyle === "italic" }); if (hasText(rs)) para(rs, styleFor(el, rs)); return; }
      // mixed: loose text between blocks becomes its own paragraph
      let loose = [];
      const flush = () => { if (!loose.length) return; const s = document.createElement("span"); loose.forEach(n => s.appendChild(n.cloneNode(true))); s.style.cssText = "position:absolute;left:-9999px"; el.appendChild(s); const rs = runs(s, { b: false, i: false }); s.remove(); para(rs, ""); loose = []; };
      for (const c of el.childNodes) {
        if (c.nodeType === 1 && blockKids.includes(c)) { flush(); walk(c); }
        else if (c.nodeType === 3 || (c.nodeType === 1 && !c.matches(SKIP) && shown(c))) loose.push(c);
      }
      flush();
    }
    pages.forEach((sp, i) => {
      if (i && sp.classList.contains("dc-chap")) body.push('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
      const head = sp.querySelector(":scope > .gh"); if (head) { const s = head.querySelector(".gh-sub"), t = head.querySelector(".gh-title"); if (s && shown(s)) para(runs(s, { b: false, i: false }), "Subtitle"); if (t) para(runs(t, { b: false, i: false }), "Title"); }
      const ct = sp.querySelector(".dc-ctitle"); if (ct) para(runs(ct, { b: false, i: false }), "Heading1");
      sp.querySelectorAll(":scope > .dc-flow, :scope > .dc-revs").forEach(walk);
      if (sp.classList.contains("dc-last")) { const a = sp.querySelector(".dc-fcontact"); if (a) { body.push("<w:p/>"); para(runs(a, { b: false, i: false }), ""); } }
    });
    if (!body.length) body.push("<w:p/>");

    const W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
    const doc = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ${W}><w:body>${body.join("")}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr></w:body></w:document>`;
    const st = (id, name, ppr, rpr, extra = "") => `<w:style w:type="paragraph" w:styleId="${id}"><w:name w:val="${name}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>${extra}<w:pPr>${ppr}</w:pPr><w:rPr>${rpr}</w:rPr></w:style>`;
    const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles ${W}>
<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:sz w:val="21"/><w:szCs w:val="21"/><w:lang w:val="en-GB"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
${st("Title", "Title", '<w:spacing w:after="240"/>', '<w:b/><w:sz w:val="48"/>')}
${st("Subtitle", "Subtitle", '<w:spacing w:after="60"/>', '<w:caps/><w:color w:val="555555"/><w:sz w:val="24"/>')}
${st("Heading1", "heading 1", '<w:keepNext/><w:spacing w:before="360" w:after="120"/><w:outlineLvl w:val="0"/>', '<w:b/><w:sz w:val="32"/>')}
${st("Heading2", "heading 2", '<w:keepNext/><w:spacing w:before="240" w:after="80"/><w:outlineLvl w:val="1"/>', '<w:b/><w:sz w:val="26"/>')}
${st("Heading3", "heading 3", '<w:keepNext/><w:spacing w:before="200" w:after="60"/><w:outlineLvl w:val="2"/>', '<w:b/><w:sz w:val="22"/>')}
${st("ListParagraph", "List Paragraph", '<w:spacing w:after="60"/><w:ind w:left="720"/><w:contextualSpacing/>', "")}
<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:color="BFBFBF"/><w:left w:val="single" w:sz="4" w:color="BFBFBF"/><w:bottom w:val="single" w:sz="4" w:color="BFBFBF"/><w:right w:val="single" w:sz="4" w:color="BFBFBF"/><w:insideH w:val="single" w:sz="4" w:color="BFBFBF"/><w:insideV w:val="single" w:sz="4" w:color="BFBFBF"/></w:tblBorders><w:tblCellMar><w:left w:w="100" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>
</w:styles>`;
    const lvls = fmt => [0, 1, 2, 3, 4].map(l => `<w:lvl w:ilvl="${l}"><w:start w:val="1"/><w:numFmt w:val="${fmt === "bullet" ? "bullet" : ["decimal", "lowerLetter", "lowerRoman", "decimal", "lowerLetter"][l]}"/><w:lvlText w:val="${fmt === "bullet" ? ["•", "–", "•", "–", "•"][l] : `%${l + 1}.`}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${720 + 360 * l}" w:hanging="360"/></w:pPr></w:lvl>`).join("");
    const numbering = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering ${W}><w:abstractNum w:abstractNumId="0">${lvls("bullet")}</w:abstractNum><w:abstractNum w:abstractNumId="1">${lvls("decimal")}</w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>${nums.map(n => `<w:num w:numId="${n}"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>`).join("")}</w:numbering>`;
    const core = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xe(title)}</dc:title><dc:creator>GMI Templater</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString().slice(0, 19)}Z</dcterms:created></cp:coreProperties>`;
    const enc = s => new TextEncoder().encode(s);
    return [
      ["[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>`],
      ["_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`],
      ["word/_rels/document.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/></Relationships>`],
      ["word/document.xml", doc], ["word/styles.xml", styles], ["word/numbering.xml", numbering], ["docProps/core.xml", core]
    ].map(([name, s]) => ({ name, data: enc(s) }));
  }
  return { build };
})();
