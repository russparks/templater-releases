/* Blank Page - a playground: the Documentation engine (every element, the Layout panel, toolbars, flowing pages) on plain pages with
   no rules. Output chooses the paper (A4 / A3, portrait / landscape; app.js paperApply writes data-pw / data-ph in mm and the --pw / --ph
   custom properties on every page). Layout > Page Setup (app.js pageSetup) switches a header, a footer and the logo on or off and picks the
   category colour; this file's setup(page, cfg) applies that to a page. The settings live on the pages as data-hdr, data-ftr, data-logo
   and data-cat, so they save with the document and new pages copy them. Styles live in css/dc.css under "Blank Page". */
window.TEMPLATES = window.TEMPLATES || {};
(function () {
  const D = window.TEMPLATES.documentation, A = window.TEMPLATES.alert;
  const DEF = { hdr: false, sub: false, ftr: false, info: true, logo: true, cat: "safety" };
  const cfgOf = () => { const f = document.querySelector("#doc .d-spread.dc"); if (!f) return Object.assign({}, DEF); const d = f.dataset;
    return { hdr: d.hdr === "1", sub: d.sub === "1", ftr: d.ftr === "1", info: d.info !== "0", logo: d.logo !== "0", cat: d.cat || DEF.cat }; };
  const MINI = '<div class="dc-mini"><i class="gh-l3"></i><i class="gh-l2"></i><i class="gh-l1"></i><div class="dc-mtitle" data-sync-of="title">TITLE</div></div><img class="d-logo dc-mlogo" data-logo="colour" alt="GMI">';
  /* put the header / footer / logo / category on one page to match cfg */
  function setup(sp, cfg) {
    if (sp.classList.contains("dc-last")) { sp.dataset.cat = cfg.cat; return; }   // the GMI end page keeps its own design, in the category colour
    const first = sp.classList.contains("dc-first"), has = q => sp.querySelector(":scope > " + q);
    sp.dataset.hdr = cfg.hdr ? "1" : "0"; sp.dataset.sub = cfg.sub ? "1" : "0"; sp.dataset.ftr = cfg.ftr ? "1" : "0"; sp.dataset.info = cfg.info ? "1" : "0"; sp.dataset.logo = cfg.logo ? "1" : "0"; sp.dataset.cat = cfg.cat;
    let hdrEls = sp.querySelectorAll(":scope > .gh, :scope > .gh-logo, :scope > .dc-mini, :scope > .dc-mlogo");
    /* front page header: title only (as on Alert) or minor title + main title (as on Documentation). Switching keeps what was typed. */
    if (cfg.hdr && first && hdrEls.length && !!sp.querySelector(":scope > .gh .gh-sub") !== !!cfg.sub) {
      const t = sp.querySelector(":scope > .gh .gh-title"), u = sp.querySelector(":scope > .gh .gh-sub"); sp._keepTitle = t ? t.innerHTML : ""; if (u) sp._keepSub = u.innerHTML; hdrEls.forEach(e => e.remove()); hdrEls = [];
    }
    sp.classList.toggle("dc-alert", cfg.hdr && first && !cfg.sub);
    if (!cfg.hdr) hdrEls.forEach(e => e.remove());
    else if (!hdrEls.length) {
      if (first) { let h = gmiHeader({ sub: sp._keepSub || "MINOR TITLE", title: sp._keepTitle || "TITLE", date: window.monYY ? window.monYY() : "", sync: true });
        if (!cfg.sub) h = h.replace(/<div class="ed gh-sub"[^>]*>[^<]*<\/div>/, ""); sp.insertAdjacentHTML("afterbegin", h); delete sp._keepTitle; }
      else sp.insertAdjacentHTML("afterbegin", MINI);
    }
    let gf = has(".gf");
    if (!cfg.ftr && gf) gf.remove();
    else if (cfg.ftr) { if (!gf) { sp.insertAdjacentHTML("beforeend", A.footer(cfg.cat)); gf = has(".gf"); }
      gf.dataset.cat = cfg.cat; const t = gf.querySelector(".gf-t"); if (t) t.textContent = cfg.cat.toUpperCase(); }
    sp.querySelectorAll(".d-logo").forEach(i => { if (window.LOGO_DATA && !i.getAttribute("src")) i.src = window.LOGO_DATA[i.dataset.logo || "colour"]; });
    const t0 = document.querySelector('#doc [data-sync="title"]'); if (t0) sp.querySelectorAll('[data-sync-of="title"]').forEach(x => { x.innerHTML = t0.innerHTML; });
  }
  const pg = (cls, style) => `<section class="d-spread nl dc dc-blank ${cls}" ${style ? `data-style="${style}" ` : ""}data-pages="1" data-pw="210" data-ph="297" style="--pw:210mm;--ph:297mm"><div class="dc-flow"></div></section>`;
  const make = (cls, style, cfg) => { const t = document.createElement("div"); t.innerHTML = pg(cls, style); const sp = t.firstElementChild; setup(sp, cfg); return t.innerHTML; };
  window.TEMPLATES.blank = Object.assign({}, D, {
    name: "Blank Page",
    desc: "A4 or A3, portrait or landscape &middot; free layout",
    file: "blank",
    blank: true, landscape: false,
    identifier: false, endPage: false,
    setup, cfgOf,
    page: kind => {
      if (kind === "mid" || !D.page) return make("dc-mid", "", cfgOf());
      /* other page kinds (Chapter) come from Documentation, on this template's plain page */
      const t = document.createElement("div"); t.innerHTML = D.page(kind); const sp = t.firstElementChild; if (!sp) return make("dc-mid", "", cfgOf());
      sp.querySelectorAll(":scope > .dc-foot, :scope > .dc-revs").forEach(e => e.remove());
      sp.classList.add("dc-blank"); sp.dataset.pw = "210"; sp.dataset.ph = "297"; sp.style.setProperty("--pw", "210mm"); sp.style.setProperty("--ph", "297mm"); setup(sp, cfgOf()); return t.innerHTML;
    },
    html(style) { return make("dc-first", style, DEF).replace("<section ", '<section id="dc-top" '); }
  });
})();
