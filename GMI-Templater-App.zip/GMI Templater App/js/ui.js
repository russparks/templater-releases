/* UI layer. Presentation and navigation only: it rearranges the existing controls and adds the home screen,
   the document bar (name, save state, Save, Export) and the component search. It never changes the document itself;
   everything it does goes through the same functions and buttons the engine already has (window.GMI_APP). */
(() => {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const A = window.GMI_APP, esc = A.chEsc;
  const mem = { get(k) { try { return JSON.parse(localStorage.getItem("gmiui:" + k)); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem("gmiui:" + k, JSON.stringify(v)); } catch (e) {} } };
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const hhmm = t => new Date(t).toTimeString().slice(0, 5);
  const when = t => { const d = new Date(t), n = new Date(), day = 864e5, a = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
    return (t >= a ? "Today" : t >= a - day ? "Yesterday" : d.toLocaleDateString("en-GB", { day: "numeric", month: "short" })) + ", " + hhmm(t); };
  const TYPES = [["documentation", "Documentation", "Guides, procedures and reports on flowing A4 pages"], ["alert", "Alert", "A one-page safety, quality or environment alert"],
    ["training", "Training", "Training material in A3 landscape or A4 portrait"], ["blank", "Blank Page", "An empty page to build anything on"]].filter(t => window.TEMPLATES[t[0]]);
  const ICON = { home: '<svg viewBox="0 0 20 20"><path d="M3 9.500 10 3l7 6.500M5 8.500V17h10V8.500"/></svg>', chev: '<svg viewBox="0 0 20 20"><path d="m6 8 4 4 4-4"/></svg>',
    find: '<svg viewBox="0 0 20 20"><circle cx="9" cy="9" r="5.500"/><path d="m13.500 13.500 3.500 3.500"/></svg>', folder: '<svg viewBox="0 0 20 20"><path d="M2.500 5.500h5l1.500 2h8.500v8.500h-15z"/></svg>',
    plus: '<svg viewBox="0 0 20 20"><path d="M10 4v12M4 10h12"/></svg>',
    save: '<svg viewBox="0 0 20 20"><path d="M4 3.5h9.5L16.5 6.5v10h-12.5z"/><path d="M7 3.5v4h6v-4M7 16.5v-5h6v5"/></svg>',
    dup: '<svg viewBox="0 0 20 20"><rect x="7" y="7" width="9.5" height="9.5" rx="1.5"/><path d="M13 7V4.5A1 1 0 0 0 12 3.5H4.5a1 1 0 0 0-1 1V12a1 1 0 0 0 1 1H7"/></svg>',
    open: '<svg viewBox="0 0 20 20"><path d="M2.5 5.5h5l1.500 2h8.500v8.500h-15z"/><path d="M10 14.5v-5M7.8 11.5 10 9.3l2.2 2.2"/></svg>',
    photo: '<svg viewBox="0 0 20 20"><rect x="2.5" y="4" width="15" height="12" rx="1.5"/><circle cx="7.3" cy="8.300" r="1.5"/><path d="m3 15 4.5-4.500 3.500 3.500 2.500-2.500 3.500 3.500"/></svg>',
    hist: '<svg viewBox="0 0 20 20"><path d="M3.5 10a6.500 6.500 0 1 0 2-4.700"/><path d="M3.5 3.5v3h3M10 6.500V10l2.500 1.500"/></svg>', file: '<svg viewBox="0 0 20 20"><path d="M5 2.500h6.500L15 6v11.500H5z"/><path d="M11.500 2.500V6H15"/></svg>' };
  document.body.classList.add("ui2", "ui3");

  /* ============================== left: only "add things" ============================== */
  $(".brandrow").hidden = true; $(".types").closest(".grp").hidden = true;
  const box = $("#dcElBtns"), els = $("#dcEls");
  { $("h4", els).firstChild.textContent = "Add to the page"; $("h4", $("#dcPages")).firstChild.textContent = "Pages";
    $("h4", $("#dcPages")).insertAdjacentHTML("afterbegin", '<svg class="h4i" viewBox="0 0 20 20"><path d="M5 2.500h7L15.500 6v11.500H5z"/><path d="M12 2.500V6h3.500"/></svg>'); $("h4", els).insertAdjacentHTML("afterbegin", '<svg class="h4i" viewBox="0 0 20 20"><circle cx="10" cy="10" r="7.500"/><path d="M10 6.500v7M6.500 10h7"/></svg>');
    const find = el("div", "elfind", `${ICON.find}<input id="elFind" type="search" placeholder="Find a component" autocomplete="off" spellcheck="false"><kbd>/</kbd>`);
    $("h4", els).after(find);
    const q = $("#elFind", find), shut = mem.get("shut") || {};
    const apply = () => { const term = q.value.trim().toLowerCase(); let head = null, any = false, shown = 0; const close = () => { if (head) head.hidden = !!term && !any; };
      [...box.children].forEach(n => {
        if (n.classList.contains("els-h")) { close(); head = n; any = false; n.classList.toggle("shut", !term && !!shut[n.dataset.g]); return; }
        if (n.classList.contains("els-hr")) { n.hidden = !!term; return; }
        const hit = !term || n.textContent.toLowerCase().includes(term) || (n.title || "").toLowerCase().includes(term);
        n.hidden = !hit || (!term && head && !!shut[head.dataset.g]); if (hit) { any = true; shown++; } });
      close(); box.classList.toggle("none", !!term && !shown); box.dataset.none = term ? `Nothing matches "${q.value.trim()}"` : ""; };
    const dress = () => { $$(".els-h", box).forEach(h => { if (h.dataset.g) return; h.dataset.g = h.textContent.trim(); h.tabIndex = 0; h.title = "Click to fold or unfold this group"; h.insertAdjacentHTML("beforeend", `<svg class="chev" viewBox="0 0 20 20"><path d="m6 8 4 4 4-4"/></svg>`);
        const tog = () => { shut[h.dataset.g] = !shut[h.dataset.g]; mem.set("shut", shut); apply(); }; h.onclick = tog; h.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); tog(); } }; }); apply(); };
    new MutationObserver(() => { if ($(".els-h:not([data-g])", box)) dress(); }).observe(box, { childList: true }); dress(); q.oninput = apply;
    q.onkeydown = e => { if (e.key === "Escape") { q.value = ""; apply(); q.blur(); } if (e.key === "Enter") { const f = $$(".mini.el", box).find(b => !b.hidden && !b.disabled); if (f) { f.click(); q.select(); } } };
    addEventListener("keydown", e => { if (e.key !== "/" || e.metaKey || e.ctrlKey || e.altKey || !$("#home").hidden) return; const a = document.activeElement; if (a && (a.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName))) return; if (els.hidden) return; e.preventDefault(); q.focus(); q.select(); }); }

  /* ============================== right: what is selected, then the document's own settings ============================== */
  const right = $("#right"), ep = $("#elPane"), ib = $("#imgBorder"), ts = $("#textStyle"), wsCard = $("#wsCard"), wsTop = $("#wsTop"), outgrp = $(".outgrp"), styleGrp = $("#styleTiles").closest(".grp");
  wsCard.hidden = true;                                               // project / version controls live in the document bar now (the originals stay in the page so their logic keeps working)
  const card = el("section", "selcard", `<div class="selhead"><span>Selected</span><b id="selName">Nothing yet</b></div><p class="selnone" id="selNone">Click anything on the page to see its options here.</p>`); card.id = "selCard";
  right.insertBefore(card, ep); card.appendChild(ep); card.appendChild(ib); card.appendChild(ts); $("h4", ts).firstChild.textContent = "Text ";
  { const name = $("#epName"), sync = () => { const on = !ep.hidden; $("#selName").textContent = on ? (name.textContent || "Component") : "Nothing yet"; $("#selNone").hidden = on; card.classList.toggle("has", on); };
    new MutationObserver(sync).observe(ep, { attributes: true, attributeFilter: ["hidden"] }); new MutationObserver(sync).observe(name, { childList: true, characterData: true, subtree: true }); sync(); }
  const docSet = el("section", "grp docset", `<h4>Document</h4><div class="dsrow"><span class="lab">Style</span><span id="dsStyle"></span></div><div class="dsrow"><span class="lab">Region</span><span id="dsRegion"></span></div>`);
  const psGrp = el("section", "grp docset psgrp", `<h4>Page setup</h4><div id="psSide"></div>`); psGrp.hidden = true;
  right.insertBefore(docSet, styleGrp); right.insertBefore(psGrp, styleGrp); $("#dsStyle", docSet).appendChild($("#styleTiles")); $("#dsRegion", docSet).appendChild($("#regionSel")); styleGrp.hidden = true;

  /* ============================== document bar ============================== */
  const tbl = $(".tb-l"), tbr = $(".tb-r"), undo = $(".zoom", tbl);
  $("#docTitle").hidden = true;
  const homeBtn = el("button", "hbtn", ICON.home); homeBtn.id = "homeBtn"; homeBtn.title = "Home: start a new document or open another one";
  const docBox = el("button", "docbox", `<span class="dname"><i id="dPill"></i><b id="dName"></b></span><span class="dstat" id="dStat"></span>`); docBox.id = "docBox"; docBox.title = "This document: versions, files and project";
  tbl.prepend(docBox); tbl.prepend(homeBtn);
  const folder = $("#wsBtn"); folder.classList.add("fchip"); tbr.appendChild(folder); wsTop.hidden = true;
  const save = el("div", "split", `<button class="mini prim" id="uiSave" title="Save a version (Ctrl/Cmd+S)">Save</button><button class="mini prim" id="uiSaveMore" title="Versions, files and project">${ICON.chev}</button>`);
  const exp = el("button", "mini prim", `Export ${ICON.chev}`); exp.id = "uiExport"; exp.title = "Export as HTML or PDF";
  tbr.appendChild(save); tbr.appendChild(exp);
  { const tc = $(".tb-c"), ao = el("span", "allor", `<span class="zsep"></span><span class="aol">All pages</span><button class="hbtn" data-o="portrait" title="Make every page portrait"><svg viewBox="0 0 20 20"><rect x="6" y="3" width="8" height="14" rx="1.2"/></svg></button><button class="hbtn" data-o="landscape" title="Make every page landscape"><svg viewBox="0 0 20 20"><rect x="3" y="6" width="14" height="8" rx="1.2"/></svg></button>`);
    tc.appendChild(ao); ao.hidden = true; setInterval(() => { ao.hidden = !(A.perPage && A.perPage()); }, 600);   // Documentation and Training: turn every page at once (each page also has its own buttons)
    $$("[data-o]", ao).forEach(b => b.onclick = async () => { const o = b.dataset.o, n = document.querySelectorAll("#doc .d-spread.dc").length;
      if (await A.choose("All pages?", `Make all ${n} pages ${o}? Pages you have set one by one change too. You can undo this.`, ["Cancel", `All ${o}`]) === 1) A.allOrient(o); }); }
  { const tc = $(".tb-c"), sep = el("span", "zsep"); tc.appendChild(sep); tc.appendChild($("#status")); tc.appendChild($("#wcount")); const tr = $("#trimBtn"); if (tr) tc.appendChild(tr); }   // page health sits with the view controls, under the page

  /* popovers */
  const pop = el("div", "pop"); pop.id = "uiPop"; pop.hidden = true; document.body.appendChild(pop); let popFor = null;
  const closePop = () => { pop.hidden = true; popFor = null; if (outgrp.parentNode === pop) right.appendChild(outgrp); };
  const openPop = (anchor, fill, cls) => { if (popFor === anchor) return closePop(); closePop(); pop.className = "pop " + (cls || ""); pop.innerHTML = ""; fill(pop); pop.hidden = false; popFor = anchor;
    const r = anchor.getBoundingClientRect(); pop.style.top = r.bottom + 8 + "px"; pop.style.left = "auto"; pop.style.right = Math.max(12, innerWidth - r.right) + "px";
    if (cls === "left") { pop.style.right = "auto"; pop.style.left = r.left + "px"; } };
  addEventListener("mousedown", e => { if (!pop.hidden && !pop.contains(e.target) && !(popFor && popFor.contains(e.target))) closePop(); });
  addEventListener("keydown", e => { if (e.key === "Escape") closePop(); });
  outgrp.hidden = true;
  exp.onclick = () => openPop(exp, p => { outgrp.hidden = false; p.appendChild(outgrp); }, "exp");
  $("#outHtml").addEventListener("click", () => setTimeout(closePop, 0)); $("#outPdf").addEventListener("click", () => setTimeout(closePop, 0));

  /* saving: one button. Unnamed documents are named first (that creates the project); named ones just save a new version. */
  async function nameIt() {
    if (!A.WS.on) { $("#saveVer").click(); return false; }
    const n = await A.ask("Name this document", "", "It is saved in a project of this name. Type an existing project's name to add it to that project.", "Save"); if (!n) return false;
    await A.startNamed(n); A.asked.add(A.state.type); return true;
  }
  async function copyIt() {
    let hint = "A new project is made with everything on screen and this project's pictures. The original stays as it is.";
    for (let n = A.pname(A.state.project) + " - copy"; ;) {
      n = await A.ask("Make a copy", n, hint, "Make copy"); if (!n) return;
      const made = await A.makeCopy(n); if (made) { A.toast(`Copy made: ${A.pname(made)}. You are now working on the copy.`); return; }
      hint = `There is already a project called "${n}". Choose another name.`;
    }
  }
  async function doSave() { closePop(); if (A.WS.on && A.state.project === A.PH) return nameIt(); $("#saveVer").click(); }
  $("#uiSave").onclick = doSave;
  addEventListener("keydown", e => { if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s" && $("#home").hidden) { e.preventDefault(); doSave(); } });
  const item = (label, sub, fn, dis) => { const b = el("button", "pitem", `<b>${label}</b>${sub ? `<span>${sub}</span>` : ""}`); b.disabled = !!dis; b.onclick = () => { closePop(); fn(); }; return b; };
  async function docMenu(p) {
    const named = A.state.project !== A.PH, on = A.WS.on;
    p.appendChild(el("div", "phead", `<b>${named ? esc(A.pname(A.state.project)) : "Not named yet"}</b><span>${named ? "Saved in source/" + esc(A.state.project) : on ? "Name it to keep it in its own project" : "Connect your folder to save automatically"}</span>`));
    /* the actions, as icons across the top */
    const acts = el("div", "pacts"); p.appendChild(acts);
    const act = (ic, label, title, fn, dis) => { const b = el("button", "pact", `${ICON[ic]}<span>${label}</span>`); b.title = title; b.disabled = !!dis; b.onclick = () => { closePop(); fn(); }; acts.appendChild(b); };
    act("save", named || !on ? "Save" : "Save…", named ? "Save a version (Ctrl/Cmd+S)" : "Name it and save it", named ? doSave : nameIt, !on && named);
    act("dup", "Duplicate", "A new project with this document and its pictures", copyIt, !named || !on);
    act("open", "Open file", "Open a .json save from somewhere else", () => $("#openSaveFile").click());
    act("photo", "Upload photos", "Add photos to this project's media folder", () => $("#upFilesBtn").click(), !named || !on);
    if (named) { const list = el("div", "pvers", `<div class="plab">Recent versions</div><div class="pwait">Loading…</div>`); p.appendChild(list);
      A.savesFor(A.state.project).then(sv => { $(".pwait", list).remove(); if (!sv.length) list.appendChild(el("div", "pwait", "No versions yet"));
        sv.slice(0, 6).forEach(v => { const t = A.typeOfName(v.name), b = el("button", "pver", `${A.tPill(t)}<span>${esc(v.name.replace(/^.* - (\d{1,2} [A-Z][a-z]{2} \d{4} \d{2}\.\d{2}.*)$/, "$1"))}</span><em>${when(v.when)}</em>`); b.title = v.name; b.onclick = () => { closePop(); A.openSave(v); }; list.appendChild(b); }); }); }
    const all = el("button", "pall", `${ICON.hist}<span>Saved versions</span>`); all.title = "Open, delete or tidy up saved versions"; all.disabled = !named || !on; all.onclick = () => { closePop(); $("#manageSaves").click(); }; p.appendChild(all);
  }
  $("#uiSaveMore").onclick = () => openPop(save, docMenu, "doc");
  docBox.onclick = () => openPop(docBox, docMenu, "doc left");

  /* status line under the name: is my work safe? */
  function tick() {
    const s = A.state, T = A.TPL, named = s.project !== A.PH, L = A.LAST, dirty = A.lastMark > L.t;
    $("#dPill").outerHTML = `<i id="dPill">${A.tPill(s.type)}</i>`; $("#dName").textContent = named ? A.pname(s.project) : "Untitled " + T.name.toLowerCase();
    let txt, cls = "";
    if (!A.WS.on) { txt = "Folder not connected: nothing is being saved"; cls = "bad"; }
    else if (!A.blocks && !named) { txt = "Nothing to save yet"; }
    else if (!dirty && L.t) { txt = (L.kind === "save" ? "Saved " : L.kind === "open" ? "Opened " : "Backed up ") + hhmm(Math.min(L.t, Date.now())); cls = "ok"; }
    else if (named) { txt = L.t && L.kind !== "open" ? `Edited since ${hhmm(L.t)}. Backs up every 5 minutes` : "Unsaved changes. Backs up every 5 minutes"; cls = "warn"; }
    else { txt = "Practice: backed up as a WiP file every minute"; cls = "warn"; }
    const st = $("#dStat"); if (st.textContent !== txt) st.textContent = txt; st.className = "dstat " + cls;
    folder.classList.toggle("on", A.WS.on); $("#uiSave").textContent = named || !A.WS.on ? "Save" : "Save…";
  }
  setInterval(tick, 700);
  /* Blank Page: header / footer / end page switches live in the right-hand panel */
  let psSig = "";
  setInterval(() => { const c = A.pageCfg && A.pageCfg(), sig = c ? JSON.stringify(c) : ""; psGrp.hidden = !c; if (sig !== psSig) { psSig = sig; if (c) A.pageSetupInto($("#psSide")); } }, 500);

  /* ============================== home ============================== */
  const home = el("div"); home.id = "home"; home.hidden = true; document.body.appendChild(home);
  home.innerHTML = `<div class="hwrap">
    <header class="hhead"><div class="hbrand"><img alt="GMI" id="hLogo"><div><b>GMI Templater</b><span>Make on-brand documents</span></div></div><div class="hfold" id="hFold"></div></header>
    <div class="hcols">
      <section class="hnew"><h2>Start a new document</h2><div class="hcards" id="hCards"></div>
        <form class="hname" id="hName" hidden><div class="hnh"><i id="hnPill"></i><b>Give it a name</b></div><input id="hnInput" placeholder="e.g. Site induction guide" spellcheck="false" autocomplete="off" list="hnList"><datalist id="hnList"></datalist>
          <p class="hint" id="hnHint">It is saved straight away in a project of this name.</p><div class="hnb"><button type="button" class="mini" id="hnBack">Back</button><button type="button" class="mini" id="hnPractice" title="Carry on without naming it. It is still backed up as a WiP file.">Just practising</button><button type="submit" class="mini prim" id="hnGo">Create</button></div></form></section>
      <section class="hopen"><h2>Carry on with one</h2><div class="hfrow"><div class="elfind hfind">${ICON.find}<input id="hFind" type="search" placeholder="Find a project" autocomplete="off" spellcheck="false"></div><button class="hnf" id="hNewFolder" title="New folder: group your projects (the projects themselves don't move on disk)">${ICON.folder}<span>New folder</span></button></div><div class="hlist" id="hList"></div>
        <button class="hfile" id="hFile">${ICON.file}Open from a file…</button></section>
    </div>
    <footer class="hfoot"><button class="mini" id="hBack" hidden>Back to my document</button><span class="hvr"><button class="hhelp" id="hHelp">Help and Update</button><span id="hVer"></span></span></footer></div>`;
  $("#hLogo").src = ($("#brandLogo") || {}).src || ""; new MutationObserver(() => { $("#hLogo").src = $("#brandLogo").src; }).observe($("#brandLogo"), { attributes: true, attributeFilter: ["src"] });
  $("#hVer").textContent = window.GMI_VERSION || "";
  $("#hCards").innerHTML = TYPES.map(([k, n, d]) => `<button class="hcard" data-t="${k}"><span class="hthumb" data-t="${k}"><i></i><i></i><i></i></span><b>${n}</b><span>${d}</span></button>`).join("");
  let pick = null, rows = [];
  const closeHome = () => { home.hidden = true; pick = null; $("#hName").hidden = true; $("#hCards").hidden = false; };
  const started = () => A.blocks > 0 || A.state.project !== A.PH || !!A.curSave;
  $$(".hcard", home).forEach(b => b.onclick = () => { pick = b.dataset.t; $("#hCards").hidden = true; $("#hName").hidden = false; $("#hnPill").outerHTML = `<i id="hnPill">${A.tPill(pick)}</i>`;
    const on = A.WS.on; $("#hnInput").disabled = $("#hnGo").disabled = !on; $("#hnHint").textContent = on ? "It is saved straight away in a project of this name. Use an existing project's name to add it to that project." : "Connect your folder (top right) to name and save documents. You can still practise without it.";
    $("#hnList").innerHTML = A.projects().filter(p => p !== A.PH && p !== A.WIP).map(p => `<option value="${esc(p)}">`).join(""); $("#hnInput").value = ""; if (on) $("#hnInput").focus(); });
  $("#hnBack").onclick = () => { $("#hName").hidden = true; $("#hCards").hidden = false; };
  const begin = async name => { const t = pick; A.newDoc(t); A.asked.add(t); closeHome(); if (name) { try { await A.startNamed(name); } catch (e) { console.error(e); A.toast("Couldn't create that project"); } } else A.toast("Practice document. It is backed up as you go"); tick(); };
  $("#hnPractice").onclick = () => begin("");
  $("#hName").onsubmit = e => { e.preventDefault(); const n = $("#hnInput").value.trim(); if (!n) return $("#hnInput").focus(); begin(n); };
  $("#hBack").onclick = closeHome; $("#hFile").onclick = () => { closeHome(); $("#openSaveFile").click(); };
  /* folders on the home screen: app-only groups kept in source/_folders.json ({folders:[{name,open}], map:{project:folder}}).
     The project folders on disk never move, so pictures keep working. */
  let FD = { folders: [], map: {} };
  const fdFile = async create => { try { return await A.WS.src.getFileHandle("_folders.json", { create }); } catch (e) { return null; } };
  async function fdLoad() { FD = { folders: [], map: {} }; if (!A.WS.on) return; const h = await fdFile(false); if (!h) return;
    try { const j = JSON.parse(await (await h.getFile()).text()); FD.folders = Array.isArray(j.folders) ? j.folders : []; FD.map = j.map || {}; } catch (e) { console.warn("folders", e); } }
  async function fdSave() { const h = await fdFile(true); if (!h) return; const w = await h.createWritable(); await w.write(JSON.stringify(FD, null, 1)); await w.close(); }
  const fdNames = () => FD.folders.map(f => f.name);
  async function fdAsk(title, val, hint, ok) { for (let h = hint; ;) { const n = await A.ask(title, val, h, ok); if (!n) return null; const t = n.replace(/\s+/g, " ").trim().slice(0, 60);
    if (t && (t === val || !fdNames().some(x => x.toLowerCase() === t.toLowerCase()))) return t; h = `There is already a folder called "${t}".`; val = t; } }
  async function newFolder(thenMove) { const n = await fdAsk("New folder", "", "Groups projects on this screen. Nothing moves on disk.", "Create"); if (!n) return;
    FD.folders.push({ name: n, open: true }); FD.folders.sort((a, b) => a.name.localeCompare(b.name)); if (thenMove) FD.map[thenMove] = n; await fdSave(); drawList(); }
  async function moveTo(p, f) { if (f) FD.map[p] = f; else delete FD.map[p]; await fdSave(); drawList(); }
  function rowMenu(btn, p) { openPop(btn, box => {
      box.appendChild(el("div", "phead", `<b>${esc(A.pname(p))}</b><span>${FD.map[p] ? "In " + esc(FD.map[p]) : "Not in a folder"}</span>`));
      if (FD.folders.length) box.appendChild(el("div", "plab", "Move to folder"));
      FD.folders.forEach(f => { if (FD.map[p] !== f.name) box.appendChild(item(esc(f.name), "", () => moveTo(p, f.name))); });
      if (FD.map[p]) box.appendChild(item("Take out of the folder", "", () => moveTo(p, "")));
      box.appendChild(el("div", "psep")); box.appendChild(item("New folder…", "And put this project in it", () => newFolder(p)));
    }, "left"); }
  function folderMenu(btn, f) { openPop(btn, box => {
      box.appendChild(el("div", "phead", `<b>${esc(f.name)}</b><span>Folder on this screen only</span>`));
      box.appendChild(item("Rename…", "", async () => { const n = await fdAsk("Rename folder", f.name, "", "Rename"); if (!n || n === f.name) return;
        Object.keys(FD.map).forEach(k => { if (FD.map[k] === f.name) FD.map[k] = n; }); f.name = n; FD.folders.sort((a, b) => a.name.localeCompare(b.name)); await fdSave(); drawList(); }));
      box.appendChild(item("Remove folder", "Its projects go back to the main list. Nothing is deleted.", async () => {
        FD.folders = FD.folders.filter(x => x !== f); Object.keys(FD.map).forEach(k => { if (FD.map[k] === f.name) delete FD.map[k]; }); await fdSave(); drawList(); }));
    }, "left"); }
  let dragP = null;
  const projRow = (w, inFolder) => { const r = el("div", "hrow" + (inFolder ? " hin" : ""), `${w.p !== A.WIP ? `<button class="hmv" title="Move to a folder">${ICON.folder}</button>` : `<span class="hmv0"></span>`}<span class="hn"><b>${esc(A.pname(w.p))}</b><em>${when(w.when)} · ${w.n} version${w.n === 1 ? "" : "s"}${!inFolder && FD.map[w.p] && $("#hFind").value.trim() ? " · in " + esc(FD.map[w.p]) : ""}</em></span><span class="ht">${Object.keys(w.by).map(A.tPill).join("")}</span>`); r.tabIndex = 0; r.title = "Open the latest version. Click a coloured label to open the latest of that document type. Drag onto a folder to file it";
    const go = async v => { closeHome(); if (!await A.openSave(v)) openHome(); else tick(); };
    if (w.p !== A.WIP) { const mb = $(".hmv", r); mb.onclick = e => { e.stopPropagation(); rowMenu(mb, w.p); };
      r.draggable = true; r.ondragstart = e => { dragP = w.p; e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", w.p); r.classList.add("drag"); }; r.ondragend = () => { dragP = null; r.classList.remove("drag"); $$(".hdrop", home).forEach(x => x.classList.remove("hdrop")); }; }
    r.onclick = e => { if (e.target.closest(".hmv")) return; const pl = e.target.closest(".tpill"); go(pl ? w.by[pl.dataset.t] : w.latest); }; r.onkeydown = e => { if (e.key === "Enter") go(w.latest); }; return r; };
  const dropOn = (node, f) => { node.ondragover = e => { if (!dragP) return; e.preventDefault(); node.classList.add("hdrop"); }; node.ondragleave = () => node.classList.remove("hdrop");
    node.ondrop = e => { e.preventDefault(); node.classList.remove("hdrop"); if (dragP && (FD.map[dragP] || "") !== f) moveTo(dragP, f); }; };
  const drawList = () => { const q = $("#hFind").value.trim().toLowerCase(), L = $("#hList"), on = A.WS.on, shown = rows.filter(w => !q || A.pname(w.p).toLowerCase().includes(q) || (FD.map[w.p] || "").toLowerCase().includes(q));
    $("#hNewFolder").hidden = !on;
    if (!on) { L.innerHTML = `<div class="hempty"><b>Connect your folder to see your projects</b><span>Your documents are kept in a folder on this computer. Connect it once and it is remembered.</span></div>`; return; }
    if (!shown.length && !(FD.folders.length && !q)) { L.innerHTML = `<div class="hempty"><b>${rows.length ? "No project matches that" : "No saved projects yet"}</b><span>${rows.length ? "Try a different word." : "Start a new document on the left and it will appear here."}</span></div>`; return; }
    L.innerHTML = "";
    if (q) { shown.forEach(w => L.appendChild(projRow(w, false))); return; }   // searching: one flat list
    const known = new Set(fdNames());
    FD.folders.forEach(f => { const inside = shown.filter(w => FD.map[w.p] === f.name), last = inside.length ? Math.max(...inside.map(w => w.when)) : 0;
      const h = el("div", "hfold-row" + (f.open ? " open" : ""), `<span class="hfi">${ICON.chev}</span>${ICON.folder}<span class="hn"><b>${esc(f.name)}</b><em>${inside.length} project${inside.length === 1 ? "" : "s"}${last ? " · " + when(last) : ""}</em></span>`);
      const mb = el("button", "hmore", "&middot;&middot;&middot;"); mb.title = "Rename or remove this folder"; mb.onclick = e => { e.stopPropagation(); folderMenu(mb, f); }; h.appendChild(mb);
      h.tabIndex = 0; h.onclick = async e => { if (e.target.closest(".hmore")) return; f.open = !f.open; drawList(); await fdSave(); }; h.onkeydown = e => { if (e.key === "Enter") h.click(); };
      dropOn(h, f.name); L.appendChild(h);
      if (f.open) { if (!inside.length) L.appendChild(el("div", "hfempty", "Empty. Drag a project here, or use the folder button on its row.")); inside.forEach(w => L.appendChild(projRow(w, true))); } });
    const loose = shown.filter(w => !FD.map[w.p] || !known.has(FD.map[w.p]));
    if (FD.folders.length && loose.length) { const d = el("div", "hloose", "Not in a folder"); dropOn(d, ""); L.appendChild(d); }
    loose.forEach(w => L.appendChild(projRow(w, false))); };
  $("#hFind").oninput = drawList; $("#hNewFolder").onclick = () => newFolder();
  const drawFold = () => { const on = A.WS.on, pend = !on && A.WS.pending, f = $("#hFold");
    f.innerHTML = on ? `<span class="hok"><i></i>Saving to <b>${esc(A.WS.root.name)}</b></span><button class="mini" id="hConn">Change folder</button>` : `<span class="hwarn"><i></i>${pend ? `Reconnect to <b>${esc(pend)}</b> to see and save your work` : "No folder connected, so nothing can be saved"}</span><button class="mini prim" id="hConn">${pend ? "Reconnect" : "Connect folder"}</button>`;
    $("#hConn").onclick = async () => { await A.connect(); refresh(); }; };
  async function refresh() { drawFold(); rows = []; drawList(); if (A.WS.on) { $("#hList").innerHTML = `<div class="hempty"><span>Looking for your projects…</span></div>`; try { rows = await A.projectRows(); await fdLoad(); } catch (e) { console.error(e); } drawList(); } }
  function openHome() { closePop(); $("#hBack").hidden = !started(); home.hidden = false; $("#hFind").value = ""; refresh(); }
  homeBtn.onclick = openHome;
  addEventListener("keydown", e => { if (e.key === "Escape" && !home.hidden && started() && $("#choose").hidden && $("#ask").hidden) closeHome(); });
  /* the folder can connect a moment after start-up (remembered permission): keep the home screen in step */
  let wasOn = A.WS.on; setInterval(() => { if (A.WS.on !== wasOn) { wasOn = A.WS.on; if (!home.hidden) refresh(); } }, 600);
  /* ============================== updates ==============================
     The latest version number lives in a small public file (russparks/templater-releases/latest.json, written on every release).
     If this copy is older, the home screen shows a banner; Help & updates explains, step by step, how to swap in the new copy. */
  const REL = "https://raw.githubusercontent.com/russparks/templater-releases/main/", ZIP = REL + "GMI-Templater-App.zip";
  const vnum = v => { const m = String(v || "").match(/v?1\.(\d+)/); return m ? +m[1] : 0; };
  let LATEST = null, checked = false;
  async function checkUpdate() { try { const r = await fetch(REL + "latest.json?t=" + Date.now(), { cache: "no-store" }); if (r.ok) LATEST = await r.json(); } catch (e) { LATEST = null; } checked = true; showUpd(); }
  const newer = () => LATEST && vnum(LATEST.version) > vnum(window.GMI_VERSION);
  const ban = el("div", "hupd", ""); ban.hidden = true; $(".hwrap", home).insertBefore(ban, $(".hcols", home));
  function showUpd() { ban.hidden = !newer(); if (newer()) { ban.innerHTML = `<span><b>A new version is ready: ${esc(LATEST.version)}</b> (you have ${esc(window.GMI_VERSION || "?")}). It takes a couple of minutes and your projects are not touched.</span><button class="mini prim" id="hUpd">How to update</button>`; $("#hUpd").onclick = openHelp; }
    $("#hHelp").classList.toggle("dot", !!newer()); }
    const STEPS = {
    win: [["Download", "Click <b>Download</b> below, wait for <b>GMI-Templater-App.zip</b> to appear in your <b>Downloads</b> folder."],
          ["Unzip Properly", "Open <b>Downloads</b>, <b>right-click</b> on GMI-Templater-App.zip and choose <b>Extract All…</b>, then <b>Extract</b>.<em>Don't just double-click into the zip: the app won't work from inside it.</em>"],
          ["Move It", "Drag the new <b>GMI Templater App</b> folder to where the old one is (e.g. Documents).<br>If Windows asks, choose <b>Replace the files</b>."],
          ["Open It", "Double-click into that newly placed <b>GMI Templater App</b> folder, and double-click <b>Open GMI Templater</b>.<br>Use Chrome or Edge."],
          ["Connect Your Folder (if asked)", "Click <b>Connect Folder</b> and choose your GMI Templater folder, your projects stay exactly where they are."]],
    mac: [["Download", "Click <b>Download</b> below, wait for <b>GMI-Templater-App.zip</b> to appear in your <b>Downloads</b> folder."],
          ["Unzip It", "Open <b>Downloads</b> in Finder and double-click GMI-Templater-App.zip. A <b>GMI Templater App</b> folder appears next to it."],
          ["Move It", "Drag the new <b>GMI Templater App</b> folder to where the old one is (e.g. Documents).<br>If your Mac asks, choose <b>Replace</b>."],
          ["Open It", "Double-click into that newly placed <b>GMI Templater App</b> folder, and double-click <b>Open GMI Templater</b>.<br>Use Chrome or Edge: if it opens in Safari, right-click it and choose <b>Open With</b> > Google Chrome."],
          ["Connect Your Folder (if asked)", "Click <b>Connect Folder</b> and choose your GMI Templater folder, your projects stay exactly where they are."]] };
  const OSI = { win: '<svg viewBox="0 0 20 20"><rect x="2.5" y="3.5" width="15" height="10" rx="1.2"/><path d="M7 16.5h6M10 13.5v3"/></svg>',
    mac: '<svg viewBox="0 0 20 20"><rect x="4" y="4" width="12" height="8.500" rx="1.2"/><path d="M2 15.500h16l-1.500-3h-13z"/></svg>' };
  const upd = el("div", "", ""); upd.id = "updDlg"; upd.hidden = true; document.body.appendChild(upd);
  function drawHelp(os) {
    const st = STEPS[os], cur = window.GMI_VERSION || "?", lat = LATEST ? LATEST.version : null;
    const state = !checked ? "Checking for a newer version…" : !LATEST ? "Couldn't check for a newer version (are you online?). You can still download the latest copy below." : newer() ? `A new version is ready: <b>${esc(lat)}</b>. You have <b>${esc(cur)}</b>.` : `You have the latest version (<b>${esc(cur)}</b>).`;
    upd.innerHTML = `<div class="ubox"><div class="ustate ${newer() ? "new" : ""}">${state}</div><div class="uin"><div class="uhead"><b>Help and Update</b><button class="mini" id="uClose">Close</button></div>
      <div class="uos"><button class="mini${os === "win" ? " on" : ""}" data-os="win">${OSI.win}Windows</button><button class="mini${os === "mac" ? " on" : ""}" data-os="mac">${OSI.mac}Mac</button></div>
      <ol class="usteps">${st.map(([t, d], i) => `<li><span class="un">${i + 1}</span><div><b>${t}</b><p>${d}</p></div></li>`).join("")}</ol>
      <p class="unew"><b>New install?</b> Just follow the steps above; there is nothing to replace or overwrite.</p>
      <div class="uact"><a class="mini prim" id="uDl" href="${ZIP}" download>Download</a><span>Only the app is in the download. Your projects live in your own folder and are never replaced.</span></div></div></div>`;
    $("#uClose").onclick = () => { upd.hidden = true; }; $$("[data-os]", upd).forEach(b => b.onclick = () => { osPick = b.dataset.os; drawHelp(osPick); });
  }
  let osPick = "win";   // Windows first; Mac is one click away
  function openHelp() { drawHelp(osPick); upd.hidden = false; if (!checked) checkUpdate().then(() => { if (!upd.hidden) drawHelp(osPick); }); }
  $("#hHelp").onclick = openHelp; upd.onclick = e => { if (e.target === upd) upd.hidden = true; };
  addEventListener("keydown", e => { if (e.key === "Escape" && !upd.hidden) upd.hidden = true; });
  checkUpdate(); setInterval(checkUpdate, 6 * 60 * 60 * 1000);

  tick(); openHome();
})();
