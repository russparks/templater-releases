/* Training - A3 landscape, built on the Documentation engine (same pages, elements, Layout panel and toolbars; everything in
   template-documentation.js is shared). Differences from Documentation:
   - paper: A3 landscape (TPL.paper), so every page is 420 x 297 mm and prints / exports on A3
   - header: the common GMI header (sub-title TRAINING, title, logo with the month-year), logo moved to the right-hand edge
   - footer: the categorised banner from Alert (Safety / Quality / Environment / Delivery, chosen with the buttons above the front page)
   - like Alert: no identifier row, no GMI end page, no reference / page-number footer
   Styles live in css/dc.css under "Training". */
window.TEMPLATES = window.TEMPLATES || {};
(function () {
  const D = window.TEMPLATES.documentation, A = window.TEMPLATES.alert;
  const wide = () => !window.GMI_A3 || window.GMI_A3();   // A3 landscape unless the Portrait button has switched this document to A4
  const a3 = h => h.replace(/<section /, wide() ? '<section data-paper="a3" ' : "<section ").replace('class="d-spread', 'class="d-spread dc-trn' + (wide() ? " dc-a3" : ""));
  window.TEMPLATES.training = Object.assign({}, D, {
    name: "Training",
    desc: "A3 landscape or A4 portrait &middot; flowing pages",
    file: "training",
    landscape: false,
    paper: { name: "A3 landscape", alt: "A4 portrait" },   // the Portrait / Landscape buttons choose A4 portrait or A3 landscape
    identifier: false, endPage: false,
    /* wider page: more side-by-side copies, more steps per row and in total, more glance items */
    limits: { steps: 16, stepsRow: 8, glance: 10,
      across: { para: 6, list: 6, ltitle: 6, lsub: 6, heading: 6, sub: 6, url: 6, moreinfo: 6, map: 4, qr: 4, medialink: 4, mediatext: 2, callout: 2, inhere: 2,
        "ch-pie": 4, "ch-pie2": 4, "ch-sun": 4, "ch-kpi": 4, "ch-gauge": 4, "ch-lines": 4, "ch-radar": 4 } },
    cats: A.cats, footer: A.footer, footFromSub: true,   // the footer banner repeats the header's sub-title (e.g. PROJECT QUALITY)
    page: kind => a3(A.page(kind)),
    html(style) {
      return `
<section ${wide() ? 'data-paper="a3" ' : ""}class="d-spread nl dc dc-first dc-trn${wide() ? " dc-a3" : ""} dc-ab" id="dc-top" data-style="${style}" data-pages="1">
  ${gmiHeader({ sub: "TRAINING", title: "TRAINING TITLE", date: monYY(), sync: true })}
  <div class="dc-flow"></div>
  ${this.footer("safety")}
</section>`;
    }
  });
})();
