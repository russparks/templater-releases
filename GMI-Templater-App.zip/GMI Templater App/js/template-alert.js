/* Alert - A4 portrait, built on the Documentation engine: same pages, elements, Layout panel and toolbars (everything in
   template-documentation.js is shared). Differences:
   - front page: title only in the header (about 32pt, wraps over two lines), "Shared learning" with an info icon in the footer, no revision record or identifier row, an Introduction heading + text to start, and a coloured category banner at the foot (Safety, Quality, Environment or Delivery; chosen with the buttons above the page, stored as data-cat on .gf)
   - no GMI end page, and content pages have no reference / page-number footer
   Styles live in css/dc.css under "Alert". */
window.TEMPLATES = window.TEMPLATES || {};
(function () {
  const D = window.TEMPLATES.documentation, ce = 'contenteditable="true" spellcheck="false"';
  /* every Alert starts with an Introduction heading and a paragraph of text, ready to overwrite */
  const LOREM = "lorem ipsum dolor sit amet consectetur adipiscing elit maxime excepturi elit omnis culpa quis et veniam at dignissimos facilis culpa sed minim maxime autem est est dolor culpa eligendi do quod exercitation corrupti id tempor assumenda velit omnis repellendus iusto nam non nulla voluptas est dolore cupidatat nulla excepteur occaecat";
  const starter = () => D.blocks.heading.html("s0").replace(/>Heading</, ">Introduction / Sub-title<") + D.blocks.para.html("s1").replace(/<p>[^<]*<\/p>/, `<p>${LOREM}</p>`);
  const INFO = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11.5" fill="currentColor"/><path d="M12 10.8v6.2M12 7.2v.2" stroke="#fff" stroke-width="2.5" stroke-linecap="round" fill="none"/></svg>';
  const foot = (cat = "safety") => `<div class="gf" data-cat="${cat}"><i class="gf-3"></i><i class="gf-2"></i><i class="gf-1"></i><div class="gf-sl">${INFO}<span>Shared learning</span></div><div class="gf-t">${cat.toUpperCase()}</div></div>`;
  window.TEMPLATES.alert = Object.assign({}, D, {
    name: "Alert",
    landscape: false,
    identifier: false, endPage: false,   // no identifier row (alert reference / date / region), no GMI end page
    desc: "A4 portrait &middot; flowing pages",
    file: "alert",
    cats: [["safety", "Safety"], ["quality", "Quality"], ["environment", "Environment"], ["delivery", "Delivery"]],
    /* every page ends with the category banner (kept in step with the front page by alertFoot in app.js); no reference / page-number footer */
    page: kind => { let h = D.page(kind); if (kind === "mid") h = h.replace(/<div class="dc-foot">[\s\S]*?<\/div>/, ""); return h.replace('class="d-spread', 'class="d-spread dc-ab').replace(/<\/section>\s*$/, foot() + "</section>"); },
    footer: foot,
    html(style) {
      return `
<section class="d-spread nl dc dc-first dc-alert" id="dc-top" data-style="${style}" data-pages="1">
  ${gmiHeader({ sub: "", title: "ALERT TITLE", date: monYY(), sync: true }).replace(/<div class="ed gh-sub"[^>]*>[^<]*<\/div>/, "")}
  <div class="dc-flow">${starter()}</div>
  ${this.footer("safety")}
</section>`;
    }
  });
})();
