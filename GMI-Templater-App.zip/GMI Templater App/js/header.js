/* Shared document header (all .nl templates): red stepped panel with sub-title + title, GMI Exceptional Delivery logo on the right.
   gmiHeader({ sub, title, date, p2, sync })  - p2: page-2 copy (adds .p2, mirrors page 1 via data-sync-of)
   Geometry and colours live in css/nl.css (.gh*). */
window.gmiHeader = function ({ sub, title, date, p2 = false, sync = false }) {
  const ce = 'contenteditable="true" spellcheck="false"', c = p2 ? " p2" : "";
  const txt = (cls, role, key, html) => p2 && sync ? `<div class="${cls}" data-sync-of="${key}">${html}</div>`
    : `<div class="ed ${cls}" data-role="${role}"${sync ? ` data-sync="${key}"` : ""} ${ce}>${html}</div>`;
  return `
  <div class="gh${c}"><i class="gh-l3"></i><i class="gh-l2"></i><i class="gh-l1"></i>
    ${txt("gh-sub", "sub", "sub", sub)}
    ${txt("gh-title d-mast", "mast", "title", title)}
  </div>
  <div class="gh-logo${c}"><img class="d-logo" data-logo="ed-colour" alt="GMI Exceptional Delivery">${date ? `<div class="ed d-date" data-role="date" ${ce}>${date}</div>` : ""}</div>`;
};
