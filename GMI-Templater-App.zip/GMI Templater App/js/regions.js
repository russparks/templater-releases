/* GMI regional offices. The Region selector (left panel) picks one; templates read it through regionContact() / regionOf().
   Add or edit offices here. REGION is kept up to date by app.js. */
window.REGIONS = [
  { key: "yorkshire", name: "Yorkshire",  lines: ["Middleton House", "Westland Road", "Leeds, LS11 5UH"], tel: "0113 276 0505" },
  { key: "northwest", name: "North West", lines: ["Carvers Warehouse", "77 Dale Street", "Manchester, M1 2HG"], tel: "0161 302 4503" },
  { key: "midlands",  name: "Midlands",   lines: ["Crosby Court", "28 George Street", "Birmingham, B3 1QG"], tel: "0121 389 2519" },
  { key: "northeast", name: "North East", lines: ["Cavendish House", "Prince's Wharf, Thornaby", "Stockton on Tees, TS17 6QY"], tel: "01642 044 797" }
];
window.REGION = "yorkshire";
window.regionOf = k => window.REGIONS.find(r => r.key === (k || window.REGION)) || window.REGIONS[0];
window.regionContact = k => { const r = window.regionOf(k); return r.lines.join("<br>") + "<br><br>" + r.tel + "<br>www.gmi.co.uk"; };
window.monYY = () => { const d = new Date(); return ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][d.getMonth()] + "-" + String(d.getFullYear()).slice(2); };   /* e.g. Oct-26 */
