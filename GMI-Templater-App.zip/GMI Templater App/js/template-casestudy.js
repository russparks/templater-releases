/* Case study template - 2 spreads = 4 x A4 portrait pages.
   Built only from shared primitives (see css/doc.css) so every style system applies.
   COPY IS PLACEHOLDER: bracketed prompts tell the author what to write. */
window.TEMPLATES = window.TEMPLATES || {};
window.TEMPLATES.casestudy = {
  name: "Case study",
  desc: "A4 portrait &middot; 2 spreads &middot; 4 pages",
  file: "case-study",
  pages: 4,
  /* which image goes in which slot by default, per project (falls back to first N images) */
  defaultSlots: {
    "Foss Island PBSA": { hero:"foss-island-pbsa-03", p3main:"foss-island-pbsa-01", p3small:"foss-island-pbsa-04",
                           p4a:"foss-island-pbsa-07", p4b:"foss-island-pbsa-05", p4c:"foss-island-pbsa-02" }
  },
  slotOrder: ["hero","p3main","p3small","p4a","p4b","p4c"],
  slotLabels: { hero:"Cover image", p3main:"Main image", p3small:"Supporting image", p4a:"Page 4 - top", p4b:"Page 4 - middle", p4c:"Page 4 - tall" },
  html(style){
    const fig = (cls, slot) => `<div class="d-fig ${cls}" data-slot="${slot}"><div class="in"><img alt=""></div></div>`;
    return `
<section class="d-spread sp1" data-style="${style}" data-spread="1">
  ${fig("hero","hero")}
  <div class="d-accent a-bar"></div>
  <div class="d-panel p-title">
    <div class="ed d-title" data-role="title" contenteditable="true" spellcheck="false">PROJECT NAME<br>LOCATION</div>
  </div>
  <div class="ed d-kicker" data-role="kicker" contenteditable="true" spellcheck="false">Project spotlight</div>
  <div class="d-rule r-kick"></div>
  <div class="ed d-sector" data-role="sector" contenteditable="true" spellcheck="false">SECTOR</div>
  <div class="d-h1wrap"><div class="ed d-h1" data-role="h1" contenteditable="true" spellcheck="false"><div>Key delivery</div><div class="acc">Highlights</div></div></div>
  <ul class="ed d-list" data-role="list" contenteditable="true">
    <li>[Contract value] [procurement route] project for [client]</li>
    <li>[Size] [building type] in [location]</li>
    <li>[Standout feature of the building]</li>
    <li>[How the design, services or fit-out met the client's brief]</li>
    <li>[A constraint we managed: site, logistics, live environment]</li>
    <li>[Repeat client, new partner, or framework route]</li>
  </ul>
  <div class="d-rule r-br"></div>
  <div class="d-pno pn1">1</div><div class="d-pno pn2">2</div>
</section>

<section class="d-spread sp2" data-style="${style}" data-spread="2">
  ${fig("p3main","p3main")}
  <div class="ed d-head2" data-role="h2" contenteditable="true" spellcheck="false"><div>Project name</div><div class="acc">Location</div></div>
  <div class="d-rule r-head2"></div>
  <div class="ed d-tag" data-role="tag" contenteditable="true" spellcheck="false">NEW<br>PARTNER</div>
  <div class="d-panel p-quote">
    <div class="ed d-quote" data-role="quote" contenteditable="true" spellcheck="false">[One strong sentence on what makes this kind of project hard, and how we get it right.]</div>
    <div class="d-rule r-q"></div>
    <div class="ed d-facts" data-role="fact" contenteditable="true" spellcheck="false">
      <div class="fact"><b>Client:</b><span>[Client name]</span></div>
      <div class="fact"><b>Value:</b><span>[£0.0m]</span></div>
      <div class="fact"><b>Programme:</b><span>[00 weeks]</span></div>
      <div class="fact"><b>Size:</b><span>[00,000 sq ft]</span></div>
      <div class="fact"><b>Location:</b><span>[Site, Town]</span></div>
    </div>
  </div>

  <div class="ed d-flow flow1" data-flow="1" contenteditable="true">
    <p>[Two sentences: what we built, where, and for whom. Lead with the outcome and write as 'we'.]</p>
    <p>[One sentence of context: the client's aims and who will use the building.]</p>
    <h3>[What made this project distinctive]</h3>
    <p>[The main challenge and what we did about it. Short sentences. Name materials, systems or numbers.]</p>
    <ul><li>[Key point one]</li><li>[Key point two]</li><li>[Key point three]</li></ul>
    <p>[Who we worked with and how the team came together day to day.]</p>
    <h3>[What the client valued most]</h3>
    <p>[The part of the delivery the client talks about when they recommend us.]</p>
    <ul><li>[Quality, speed or communication]</li><li>[Keeping a live site running]</li><li>[A third thing they valued]</li></ul>
    <p>[What this meant for the finished building.]</p>
  </div>
  <div class="ed d-flow flow2" data-flow="2" contenteditable="true">
    <h3>[The technical story]</h3>
    <p>[The detail that proves capability: coordination between design, services and fit-out, or a tricky interface.]</p>
    <p>[Say what was at stake and how we protected it.]</p>
    <ul><li>[Proof point one]</li><li>[Proof point two]</li></ul>
    <h3>[Programme and handover]</h3>
    <p>[How the programme ran, and how handover and aftercare went.]</p>
    <ul><li>[Programme milestone]</li><li>[Handover or aftercare detail]</li></ul>
    <p>[A closing line on what the client now has.]</p>
    <h3>[Lessons for the next scheme]</h3>
    <p>[One thing we would do the same again, and why it worked.]</p>
  </div>
  ${fig("p3small","p3small")}
  <div class="d-accent a-bar2"></div>

  ${fig("p4a","p4a")}
  <div class="ed d-frame f4a" data-frame="a" contenteditable="true">
    <h3>[Delivering within a constraint]</h3>
    <p>[Describe the site, access or programme constraint, and what it demanded of the team.]</p>
    <p>We put a structured plan in place to manage:</p>
    <ul><li>[Constraint one]</li><li>[Constraint two]</li><li>[Constraint three]</li><li>[Constraint four]</li></ul>
    <p>[What this protected: quality, safety, neighbours or programme.]</p>
    <p>[A short example of the plan working on site.]</p>
  </div>
  <div class="ed d-frame f4b" data-frame="b" contenteditable="true">
    <h3>[The client relationship]</h3>
    <p>[Repeat client, framework win or first project together? Say what the relationship looks like and why it matters.]</p>
    <p>[Link it to how we consistently deliver for clients like this one.]</p>
    <p>[A line on what the client has said about working with us.]</p>
  </div>
  ${fig("p4b","p4b")}
  <div class="d-panel p-cta">
    <div class="ed d-cta" data-role="cta" contenteditable="true">
      <h3>A delivery partner for [sector] projects</h3>
      <p>[Speak to the next client in this sector. What do projects like this really need from a contractor?]</p>
      <p>At [project name], we [what we did that mattered most].</p>
      <ul><li>[Proof point one]</li><li>[Proof point two]</li></ul>
      <p>[Another thing sector clients should know before they appoint a contractor.]</p>
      <p>[For clients in this sector: why early involvement makes the difference.]</p>
    </div>
  </div>
  ${fig("p4c","p4c")}
  <div class="d-accent a-bar3"></div>
  <div class="ed d-frame f4res" data-frame="r" contenteditable="true">
    <h3>The result</h3>
    <p>[State the outcome plainly: the completed building, who it serves, and what it changed.]</p>
    <p>[Back it up with one or two measurable results or client comments.]</p>
    <ul><li>[Measurable result one]</li><li>[Measurable result two]</li></ul>
    <p>[End on what this project shows about GMI's ability. Short, confident, no hype.]</p>
  </div>
  <div class="d-rule r-br"></div>
  <div class="d-pno pn3">3</div><div class="d-pno pn4">4</div>
</section>`;
  }
};
