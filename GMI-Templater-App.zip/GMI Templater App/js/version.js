window.GMI_VERSION = "v1.96";
