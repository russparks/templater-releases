window.GMI_VERSION = "v1.97";
