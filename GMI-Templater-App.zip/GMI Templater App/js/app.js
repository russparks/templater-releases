/* GMI Templating Platform - prototype v0.2 (case study, newsletter, local workspace) */
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  let TPL = window.TEMPLATES.documentation;
  /* A3 landscape pages: templates with TPL.paper. If the template also has paper.alt (Training) the orientation buttons choose: Landscape = A3 landscape, Portrait = A4 portrait */
  const a3 = () => !!TPL.paper && state.paper === "a3";   // Training on A3 (size for the whole document; each page has its own orientation)
  window.GMI_A3 = a3;
  /* A4 landscape pages (Documentation): the Landscape button turns every page into 297 x 210 mm (class dc-lnd) */
  const ls = () => !!TPL.landscape && state.orient === "landscape";
  /* Blank Page: A4 or A3 (Output), portrait or landscape; the size in mm is written on every page */
  const bl = () => !!TPL.blank;
  /* Documentation and Training: paper size (A4 / A3) for the whole document, portrait or landscape page by page (data-or="p" / "l" on each page;
     paperApply writes data-pw / data-ph in mm and the --pw / --ph custom properties, as on Blank Page) */
  const pp = () => !TPL.blank && (!!TPL.landscape || !!(TPL.paper && TPL.paper.alt));
  const pageOr = sp => sp.dataset.or === "l" ? "landscape" : sp.dataset.or === "p" ? "portrait" : state.orient;
  const sizeOf = (paper, or) => { const [w, h] = paper === "a3" ? [297, 420] : [210, 297]; return or === "landscape" ? [h, w] : [w, h]; };
  const blankSize = () => { const [w, h] = state.paper === "a3" ? [297, 420] : [210, 297]; return state.orient === "landscape" ? [h, w] : [w, h]; };
  const LIB = [];          // images: from source/<project>/media when a folder is connected, else the bundled sample library
  const byId = id => LIB.find(i => i.id === id);
  function addBuiltins() {               // brand logos are always available (project info logo strip etc.)
    [["colour", "GMI logo"], ["black", "GMI logo (black)"], ["ed-colour", "Exceptional Delivery"], ["ccs", "Considerate Constructors - registered site"]].forEach(([k, label]) => {
      if (byId("logo:" + k) || !window.LOGO_DATA[k]) return;
      const e = { id: "logo:" + k, project: "_Logos", file: label, src: window.LOGO_DATA[k], w: 0, h: 0 }; LIB.push(e);
      const im = new Image(); im.onload = () => { e.w = im.naturalWidth; e.h = im.naturalHeight; }; im.src = e.src;
    });
  }

  /* ------------------------------------------------------------------ fonts + logo */
  (function injectFonts() {
    const css = Object.entries(window.FONT_DATA).map(([w, b64]) =>
      `@font-face{font-family:Gilroy;font-weight:${w};font-style:normal;src:url(data:font/otf;base64,${b64}) format("opentype")}`).join("\n");
    const st = document.createElement("style"); st.id = "fontStyle"; st.textContent = css; document.head.appendChild(st);
    $("#brandLogo").src = window.LOGO_DATA.colour;
  })();

  /* ------------------------------------------------------------------ state */
  const GMI = { main: "#D20A11", light: "#E73331", dark: "#BC1413", mixl: "#DC2326", mixd: "#AE1410" };
  const APP_VERSION = window.GMI_VERSION || "dev";   // readable version, v1.<commit count> (js/version.js, written by the pre-commit hook)
  const STYLES = ["s1", "s3"];          // GMI base (red) and Monolith (same layout, black)
  const state = { region: "yorkshire", type: "documentation", style: "s1", project: "Placeholders", orient: "portrait", paper: "a4", slots: {}, focus: {}, main: GMI.main, zoom: "fit", view: "single" };
  const isDoc = () => !!(TPL && TPL.blocks);   // any template made of blocks on flowing pages shares one editor (pages, elements, Layout panel, toolbars); a template only describes itself (see "Template settings" in template-documentation.js)
  let uid = 0, curBlk = null;                // curBlk: selected documentation block

  /* ------------------------------------------------------------------ colour engine */
  const hex2rgb = h => { h = h.replace("#", ""); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)); };
  const rgb2hex = a => "#" + a.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("").toUpperCase();
  const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
  function family(mainHex) {
    if (mainHex.toUpperCase() === GMI.main) return Object.assign({}, GMI);       // exact brand values
    const m = hex2rgb(mainHex), light = mix(m, [255, 255, 255], .16), dark = mix(m, [0, 0, 0], .11);
    return { main: mainHex.toUpperCase(), light: rgb2hex(light), dark: rgb2hex(dark),
             mixl: rgb2hex(mix(m, light, .5)), mixd: rgb2hex(dark.map(v => v * .93)) };
  }
  function applyColour(mainHex) {
    state.main = mainHex.toUpperCase();
    const f = family(state.main), r = document.documentElement.style;
    r.setProperty("--c-main", f.main); r.setProperty("--c-light", f.light); r.setProperty("--c-dark", f.dark);
    r.setProperty("--c-mixl", f.mixl); r.setProperty("--c-mixd", f.mixd);
    r.setProperty("--c-main-rgb", hex2rgb(f.main).join(",")); r.setProperty("--c-light-rgb", hex2rgb(f.light).join(","));
    r.setProperty("--c-dark-rgb", hex2rgb(f.dark).join(","));
  }

  /* ------------------------------------------------------------------ build / layout */
  const doc = $("#doc");
  function build() {
    resetHistory();
    doc.innerHTML = TPL.html(state.style);
    decorate();
    $("#docTitle").innerHTML = `${TPL.name} <small>${APP_VERSION}</small>`;
    if (typeof setOrient === "function") setOrient(state.orient);
    $$("#doc > .d-spread").forEach(sp => {
      const w = document.createElement("div"); w.className = "spread-wrap"; sp.parentNode.insertBefore(w, sp); w.appendChild(sp);
    });
    layout();
    fillFromProject(state.project);
    document.fonts.ready.then(() => { $$(".d-title").forEach(fitTitle); reflow(); dcFlow(); markOverflow(); wordCount(); });
  }
  function decorate() {
    $$(".d-logo", doc).forEach(i => { i.src = window.LOGO_DATA[i.dataset.logo || "colour"]; });
    $$(".d-icon", doc).forEach(i => { i.innerHTML = (window.ICONS || {})[i.dataset.icon] || ""; });
    $$(".d-qr", doc).forEach(renderQR);
    $$("[data-sync]", doc).forEach(syncFrom);
    $$("[data-chart]", doc).forEach(renderChart);
    $$(".gh-title", doc).forEach(fitHeader);
    mapFix(); specFix(); listFix(); listColsFix(); endFix(); revFix();
    dcNumber(); applyRegion();
  }
  /* Region: the selector in the left panel. Fills the region name (Alert More Info) and the office address on Documentation's end page
     (only while that address is still one of the standard ones, so typed-over text is never replaced). Emails are first.last@gmi.co.uk from the name. */
  const normH = h => h.replace(/<br\s*\/?>/gi, "\n").replace(/\s+/g, " ").trim();
  function applyRegion(chosen) {
    const r = regionOf(state.region);
    $$(".dc-mil[data-region-name]", doc).forEach(e => { e.textContent = r.name; });
    const known = new Set(window.REGIONS.map(x => normH(regionContact(x.key))).concat(normH("Office address<br>Town, Postcode<br><br>01234 345 456<br>www.gmi.co.uk")));
    $$(".dc-fcontact", doc).forEach(e => { if (!e.dataset.edited && (chosen || known.has(normH(e.innerHTML)))) e.innerHTML = regionContact(state.region); });   // choosing a region fills the address unless it was typed over
    $$(".dc-mi", doc).forEach(mailFix);
  }
  function mailFix(mi) {
    const m = $(".dc-mimail", mi), n = $(".dc-min", mi); if (!m || !n || m.dataset.manual) return;
    const w = n.textContent.trim().split(/\s+/).map(x => x.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z-]/g, "")).filter(Boolean);
    const a = w.length > 1 ? w[0] + "." + w[w.length - 1] : (w[0] || "name");
    m.dataset.href = `mailto:${a}@gmi.co.uk`; m.title = `${a}@gmi.co.uk (made from the name). Click to type a different address`;
  }
  doc.addEventListener("input", e => { const n = e.target.closest && e.target.closest(".dc-min"); if (n) mailFix(n.closest(".dc-mi")); const a = e.target.closest && e.target.closest(".dc-fcontact"); if (a && e.isTrusted) a.dataset.edited = "1"; });
  function setRegion(k, quiet) { if (!window.REGIONS.some(r => r.key === k)) k = "yorkshire"; state.region = window.REGION = k; $("#regionSel").value = k; applyRegion(!quiet); }
  $("#regionSel").innerHTML = window.REGIONS.map(r => `<option value="${r.key}">${r.name}</option>`).join(""); $("#regionSel").value = state.region;
  $("#regionSel").onchange = e => { remember(); setRegion(e.target.value); toast("Region: " + regionOf().name); };
  /* revision record (front-page details from older versions become its first entry). It sits at the foot of the page holding the
     Contents (or the front page) and that page's flow is shortened to stop above it. */
  function revFix() {
    const first = $(".dc-first", doc); if (!first || TPL.identifier === false) return;   // templates can opt out of the identifier row
    const old = $(":scope > .dc-meta", first);
    if (first.dataset.norev) { $$(".dc-revs", doc).forEach(x => x.remove()); if (old) old.remove(); return; }   // revision record switched off for this document
    if (!$(".dc-revs", doc)) {
      const v = old ? $$("span", old).map(s => s.innerHTML) : [];
      first.insertAdjacentHTML("beforeend", `<div class="dc-revs"><div class="dc-rvh">Revision record</div>${TPL.revEntry(...(v.length ? [v[0], v[1], v[2], v[3], "First issue."] : []))}</div>`);
    }
    if (old) old.remove();
  }
  function revPlace() {
    const rv = $(".dc-revs", doc); if (!rv) return;
    const toc = $(".dc-toc", doc), host = (toc && toc.closest(".d-spread")) || $(".dc-first", doc); if (!host) return;
    if (rv.parentNode !== host) host.appendChild(rv);
    $$(".dc-flow", doc).forEach(f => f.style.removeProperty("height"));
    const f = $(".dc-flow", host); if (f) f.style.height = Math.max(40, rv.offsetTop - f.offsetTop - 14) + "px";
  }
  function revAdd() {
    const rv = $(".dc-revs", doc), top = rv && $(".dc-rv", rv); if (!top) return; remember();
    const v = s => ($(s, top) || {}).innerHTML || "", r = v(".dc-rvrev").trim(), d = new Date();
    const next = /^\d+$/.test(r) ? String(+r + 1) : /^[A-Y]$/i.test(r) ? String.fromCharCode(r.charCodeAt(0) + 1) : /^(.*?)(\d+)$/.test(r) ? r.replace(/(\d+)$/, n => +n + 1) : r;
    $(".dc-rvh", rv).insertAdjacentHTML("afterend", TPL.revEntry(v(".dc-rvref"), next, `${String(d.getDate()).padStart(2, "0")}-${MON[d.getMonth()]}-${String(d.getFullYear()).slice(2)}`, v(".dc-rvown"), "What changed in this revision."));
    dcNumber(); dcFlow(); toast("Revision " + next + " added");
  }
  function revDel() { const rv = $$(".dc-revs .dc-rv", doc); if (rv.length < 2) return toast("The record keeps at least one revision"); remember(); rv[0].remove(); dcNumber(); dcFlow(); }
  /* end page from an older version (mini header + black footer band): swap in the new header, shapes and contact block, keeping its content and contact text */
  function endFix() {
    $$(".dc-last", doc).forEach(p => { $$(":scope > .gh, :scope > .gh-logo", p).forEach(x => x.remove());      // the end page has no header
      if ($(".dc-endart", p)) { if (!$(".dc-elogo", p)) { const t = htmlEl(TPL.page("last")); p.appendChild($(".dc-elogo", t)); $$(".d-logo", p).forEach(i => { i.src = window.LOGO_DATA[i.dataset.logo || "colour"]; }); } return; }
      const t = htmlEl(TPL.page("last")), oc = $(".dc-fcontact", p);
      $$(".dc-mini, .dc-mlogo, .dc-final", p).forEach(x => x.remove());
      const flow = $(".dc-flow", p); [...t.children].forEach(c => { if (c.classList.contains("dc-flow")) return; if (c.classList.contains("dc-fcontact") && oc) c.innerHTML = oc.innerHTML; flow ? (c.classList.contains("gh") || c.classList.contains("gh-logo") ? flow.before(c) : p.appendChild(c)) : p.appendChild(c); });
      $$(".d-logo", p).forEach(i => { i.src = window.LOGO_DATA[i.dataset.logo || "colour"]; });
    });
  }
  /* lists: keep sub-items tidy - a stray nested list (e.g. made by the browser) goes inside the item above it, nothing deeper than one level,
     and sub-lists use the same type (numbers / bullets) as the list they sit in */
  function listFix(root = doc) {
    let changed = false;
    $$(".dc-list ol, .dc-list ul", root).forEach(s => { if (s.parentElement.tagName === "LI") return; changed = true;
      const prev = s.previousElementSibling; if (prev && prev.tagName === "LI") prev.appendChild(s); else { const li = document.createElement("li"); s.before(li); li.appendChild(s); } });
    $$(".dc-list li li li", root).reverse().forEach(li => { changed = true; const host = li.parentElement.closest("li"); host.after(li); });
    $$(".dc-list li", root).forEach(li => { const subs = [...li.children].filter(c => /^(OL|UL)$/.test(c.tagName)); subs.slice(1).forEach(x => { while (x.firstChild) subs[0].appendChild(x.firstChild); x.remove(); changed = true; }); });
    $$(".dc-list li > ol, .dc-list li > ul", root).forEach(s => { if (!s.children.length) { s.remove(); changed = true; return; } const tag = s.closest(".dc-list").tagName;
      if (s.tagName !== tag) { const m = document.createElement(tag); while (s.firstChild) m.appendChild(s.firstChild); s.replaceWith(m); changed = true; } });
    return changed;
  }
  /* Product List: certification pills from before they became links get converted to "Compliance" link pills */
  function specFix() {
    $$(".dc-sp-b:not([data-link])", doc).forEach(b => { const t = b.textContent.trim(); b.classList.remove("ed"); b.removeAttribute("contenteditable"); b.removeAttribute("spellcheck");
      b.dataset.link = "sc" + newUid(); if (t && !/^(Certification|Certificate|Compliance)$/.test(t)) b.title = t; });
    $$(".dc-sp-b", doc).forEach(b => { if (!$(".dc-sp-bi", b)) b.innerHTML = `<i class="dc-sp-bi">${TPL.icons.link}</i>Verified`; });
    $$(".dc-sp-r > .dc-sp-p", doc).forEach(p => { const w = htmlEl(`<div class="dc-sp-pw" data-link="sp${newUid()}"><i class="dc-sp-li" title="Click to add a link to the product">${TPL.icons.link}</i></div>`); p.before(w); w.appendChild(p); });
  }
  /* map elements: older saves have no .dc-mapu wrapper or directions caption; add them so widths and the directions link work */
  function mapFix() {
    $$('.dc-blk[data-blk="map"]', doc).forEach(b => {
      if (!$(".dc-mapu", b)) { const w = document.createElement("div"); w.className = "dc-mapu"; while (b.firstChild) w.appendChild(b.firstChild); b.appendChild(w); }
      if (!$(".dc-mapside", b)) b.insertAdjacentHTML("beforeend", `<div class="dc-mtext dc-mapside"><div class="ed dc-sh" data-role="dcsh" contenteditable="true" spellcheck="false">Getting here</div><div class="ed dc-p dc-rich" contenteditable="true" spellcheck="false"><p>Site address, parking, the gate to use and any delivery or access restrictions.</p></div></div>`);
      $$(".dc-mapu", b).forEach(u => {
        let cp = $(".dc-mapcap", u);
        if (!cp) { u.insertAdjacentHTML("beforeend", `<div class="dc-mapcap"><i>${(TPL.icons || {}).link || ""}</i>Click for Directions</div>`); cp = $(".dc-mapcap", u); }
        const f = $(".d-fig", u); if (f && f.dataset.href) cp.dataset.href = f.dataset.href; else delete cp.dataset.href;
      });
    });
  }
  /* header title shrinks (29pt down to 14pt) so long names stay on the solid red panel */
  function fitHeader(el) {
    const max = 110 * 96 / 25.4; el.style.removeProperty("--fit");
    const al = !!el.closest(".dc-alert");   // Alert: bigger start size, and the title may wrap over two lines before it shrinks
    for (let pt = al ? 32 : 29; pt > 14 && (el.scrollWidth > max || (al && el.scrollHeight > 27 * 96 / 25.4)); pt--) el.style.setProperty("--fit", pt - 1 + "pt");
  }
  function renderQR(el) {
    if (!window.qrcode) return;
    try { const q = window.qrcode(0, "M"); q.addData(el.dataset.href || " "); q.make();
      const n = q.getModuleCount(); let d = "";
      for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c} ${r}h1v1h-1z`;
      el.innerHTML = `<svg viewBox="-2 -2 ${n + 4} ${n + 4}" shape-rendering="crispEdges"><rect x="-2" y="-2" width="${n + 4}" height="${n + 4}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
    } catch (e) { el.innerHTML = ""; }
  }
  function syncFrom(src) { $$(`[data-sync-of="${src.dataset.sync}"]`, doc).forEach(t => { t.innerHTML = src.innerHTML; ["size", "bold", "italic", "color"].forEach(k => { if (src.dataset[k]) t.dataset[k] = src.dataset[k]; else delete t.dataset[k]; }); const f = src.style.getPropertyValue("--fit"); if (f) t.style.setProperty("--fit", f); else t.style.removeProperty("--fit"); }); }
  const SPREAD_PX = 420 * 96 / 25.4, SPREAD_H = 297 * 96 / 25.4;
  function layout() {
    const stage = $("#stage");
    const pws = $$(".d-spread[data-pw]", doc).map(p => +p.dataset.pw), maxW = pws.length ? Math.max(...pws) * 96 / 25.4 : 0;
    const unit = doc.classList.contains("dc-mode") ? (maxW ? maxW : a3() ? SPREAD_PX : ls() ? SPREAD_PX * 297 / 420 : bl() ? blankSize()[0] * 96 / 25.4 : SPREAD_PX / 2) : SPREAD_PX, per = state.view === "multi" ? 2 : 1;
    let s = state.zoom === "fit" ? Math.min(1.6, (stage.clientWidth - 60 - 26 * (per - 1)) / (unit * per)) : state.zoom;
    s = Math.max(.25, s); state.scale = s;
    $$(".spread-wrap").forEach(w => {
      const pg = w.firstElementChild, wide = pg.dataset.paper ? 1 : pg.classList.contains("dc-lnd") ? 297 / 420 : pg.dataset.pages === "1" ? .5 : 1;
      w.style.width = (pg.dataset.pw ? +pg.dataset.pw * 96 / 25.4 : SPREAD_PX * wide) * s + "px"; w.style.height = (pg.dataset.ph ? +pg.dataset.ph * 96 / 25.4 : SPREAD_H * (pg.classList.contains("dc-lnd") ? 210 / 297 : 1)) * s + "px";
      w.firstElementChild.style.transform = `scale(${s})`;
    });
    if (curBlk) drawBar();
  }
  window.addEventListener("resize", () => { if (state.zoom === "fit") layout(); });
  $("#zIn").onclick = () => { state.zoom = Math.min(2, (state.scale || 1) * 1.15); layout(); };
  $("#zOut").onclick = () => { state.zoom = Math.max(.25, (state.scale || 1) / 1.15); layout(); };
  $("#zFit").onclick = () => { state.zoom = "fit"; layout(); };
  /* view: one page (or spread) per row, or two side by side */
  function setView(v) { state.view = v; doc.classList.toggle("multi", v === "multi"); $("#vSingle").classList.toggle("on", v === "single"); $("#vMulti").classList.toggle("on", v === "multi"); state.zoom = "fit"; layout(); }
  $("#vSingle").classList.add("on");
  $("#vSingle").onclick = () => setView("single"); $("#vMulti").onclick = () => setView("multi");

  /* ------------------------------------------------------------------ document type */
  /* each document type keeps its own working copy (text, photos, style, project) while you switch between them */
  const DOCS = {};
  function stashDoc() {
    DOCS[state.type] = { nodes: $$(".d-spread", doc), slots: Object.assign({}, state.slots), focus: Object.assign({}, state.focus),
                         project: state.project, style: state.style, orient: state.orient };
  }
  function syncUI() {
    $$(".type[data-type]").forEach(x => x.classList.toggle("on", x.dataset.type === state.type));
    dcPanel();
    $$("#styleTiles .stile").forEach(x => x.classList.toggle("on", x.dataset.style === state.style));
    fillProjectSelect(); setOrient(state.orient); renderSaves();
  }
  function switchType(t, fresh) {
    if (!window.TEMPLATES[t]) t = "documentation";   // saves of document types that no longer exist open as Documentation
    if (t === state.type && !fresh) return;
    { const sp = $("#savedPill"); if (sp) sp.remove(); }
    if (!fresh) { curSave = ""; wipName = ""; renderSaves(); }
    resetHistory(); setTimeout(wordCount, 50);
    stashDoc(); state.type = t; TPL = window.TEMPLATES[t]; if (TPL.paper && TPL.paper.alt) { state.orient = "landscape"; state.paper = "a3"; } else if (TPL.landscape) { state.orient = "portrait"; state.paper = "a4"; } else if (TPL.blank) { state.orient = "portrait"; state.paper = "a4"; }
    const d = !fresh && DOCS[t];
    if (!d) { state.slots = {}; state.focus = {}; if (!fresh) { syncUI(); build(); } return; }
    state.slots = {}; state.focus = Object.assign({}, d.focus); state.style = STYLES.includes(d.style) ? d.style : "s1"; state.orient = d.orient;
    state.project = projects().includes(d.project) ? d.project : PH;
    doc.innerHTML = "";
    d.nodes.forEach(sp => { const w = document.createElement("div"); w.className = "spread-wrap"; w.appendChild(sp); doc.appendChild(w); });
    $("#docTitle").innerHTML = `${TPL.name} <small>${APP_VERSION}</small>`;
    syncOrient(); syncUI(); layout(); decorate();
    for (const [k, id] of Object.entries(d.slots)) setSlot(k, id === "ph" || byId(id) ? id : "ph", d.focus[k]);
    if (d.refill) { delete d.refill; fillFromProject(state.project); }
    syncUI();
    requestAnimationFrame(() => { $$(".d-title").forEach(fitTitle); markOverflow(); });
  }
  $$(".type[data-type]").forEach(b => b.onclick = () => {
    if (b.disabled || state.type === b.dataset.type) return;
    switchType(b.dataset.type); toast(TPL.name);
  });
  function choose(title, hint, options) {
    return new Promise(res => {
      $("#chTitle").textContent = title; $("#chHint").textContent = hint; const box = $("#chBtns"); box.innerHTML = "";
      options.forEach((o, i) => { const b = document.createElement("button"); b.className = "mini" + (i === options.length - 1 ? " on" : ""); b.textContent = o;
        b.onclick = () => { $("#choose").hidden = true; res(i); }; box.appendChild(b); });
      $("#choose").hidden = false;
    });
  }

  /* ------------------------------------------------------------------ styles */
  $$("#styleTiles .stile").forEach(b => b.onclick = () => {
    state.style = b.dataset.style;
    $$("#styleTiles .stile").forEach(x => x.classList.toggle("on", x === b));
    $$(".d-spread", doc).forEach(sp => sp.dataset.style = state.style);
    requestAnimationFrame(() => { $$(".d-title").forEach(fitTitle); reflow(); markOverflow(); });
  });

  /* ------------------------------------------------------------------ images */
  const PH = "Placeholders";
  const LAST = { t: 0, kind: "", name: "" };   // when and how this document was last written (save / auto / wip), for the status line
  const WIP = "WiP", asked = new Set(); let wipName = "";   // unsaved documents are backed up as WiP files; asked: document types already offered New / Load / Practice
  const projects = () => [PH, ...(WS.on ? WS.projects : Array.from(new Set(LIB.map(i => i.project))).filter(p => p !== "Uploaded"))];
  const pname = p => p.replace(/^_/, "");
  const esc = t => t.replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const phSrc = label => (label = esc(label), "data:image/svg+xml;utf8," + encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice"><rect width="400" height="300" fill="#e3e4e8"/><path d="M0 0L400 300M400 0L0 300" stroke="#cfd1d7" stroke-width="2"/><rect x="150" y="105" width="100" height="90" rx="6" fill="#fff" stroke="#b9bcc4" stroke-width="3"/><circle cx="178" cy="132" r="9" fill="#b9bcc4"/><path d="M158 186l30-34 22 22 14-14 18 26z" fill="#b9bcc4"/><text x="200" y="228" font-family="Arial,sans-serif" font-size="10" font-weight="700" fill="#8d9099" text-anchor="middle">${label}</text></svg>`));
  const sel = $("#projectSel");
  function fillProjectSelect() { sel.innerHTML = projects().map(p => `<option value="${p}">${p === PH ? "Blank Template" : p}</option>`).join(""); sel.value = state.project; }
  sel.onchange = async () => {
    const p = sel.value; curSave = ""; fillFromProject(p); await renderSaves(); markOverflow();    // choosing a project fills this document's photos
    // ...and opens its most recent save of this document type, if there is one
    for (const v of SAVES) { try { const j = JSON.parse(await (await v.fh.getFile()).text()); if (j.type === state.type) { await restore(j); break; } } catch (e) {} }
    const others = Object.keys(DOCS).filter(k => k !== state.type && DOCS[k].project !== p);
    if (p === PH || !others.length) return;
    const names = others.map(k => window.TEMPLATES[k].name).join(", ");
    const c = await choose(`Use \u201c${pname(p)}\u201d for\u2026`,
      `You also have ${names} open on a different project. Switching them refills their photos from ${pname(p)}; their text stays as it is.`,
      [`This ${TPL.name.toLowerCase()} only`, "All open documents"]);
    if (c === 1) { others.forEach(k => { DOCS[k].project = p; DOCS[k].refill = true; }); toast("All open documents now use " + pname(p)); }
  };

  const slotEl = name => $(`.d-fig[data-slot="${name}"]`, doc);
  function slotAspect(name) { const f = slotEl(name); return f.offsetWidth / f.offsetHeight; }
  function cropFrac(imgEntry, aspect) { if (!imgEntry.w || !imgEntry.h) return .5; const ia = imgEntry.w / imgEntry.h; return 1 - Math.min(ia / aspect, aspect / ia); }
  function setSlot(name, id, focus) {
    const f = slotEl(name); if (!f) return; const img = $("img", f);
    setTimeout(() => $$(`[data-mirror-slot="${name}"] img`, doc).forEach(m => { m.src = img.src; m.style.objectPosition = img.style.objectPosition; }), 0);
    if (id === "ph") { img.src = phSrc((TPL.slotLabels[name] || f.dataset.label || name).toUpperCase()); state.slots[name] = "ph"; img.style.objectPosition = "50% 50%"; return; }
    const e = byId(id); if (!e) return;
    img.src = e.src; state.slots[name] = id;
    if (focus) state.focus[name] = focus;
    img.style.objectPosition = state.focus[name] || "50% 50%";
  }
  /* template slots + any added in the page (documentation blocks), in page order */
  const slotNames = () => [...new Set([...TPL.slotOrder, ...$$(".d-fig[data-slot]:not([data-mapslot])", doc).map(f => f.dataset.slot)])];
  function fillFromProject(project) {
    state.project = project; sel.value = project;
    if (project === PH) { slotNames().forEach(n => { const fx = TPL.fixedSlots && TPL.fixedSlots[n]; setSlot(n, fx && fx !== "ph" && byId(fx) ? fx : "ph"); }); return; }
    const pool = LIB.filter(i => i.project === project);
    const pre = TPL.defaultSlots[project], used = new Set();
    for (const name of slotNames()) {
      const fx = TPL.fixedSlots && TPL.fixedSlots[name];
      if (fx) { setSlot(name, fx === "ph" || !byId(fx) ? "ph" : fx); continue; }
      let id = pre && pre[name]; if (id && !byId(id)) id = null;
      if (!id) {
        const a = slotAspect(name), pk = TPL.slotPool && TPL.slotPool[name];
        const src = pk ? LIB.filter(i => pname(i.project).startsWith(pk)) : pool;
        const cands = src.filter(i => !used.has(i.id)); const list = cands.length ? cands : pool;
        list.sort((x, y) => cropFrac(x, a) - cropFrac(y, a)); id = cands.length ? list[0].id : null;
      }
      if (id) { used.add(id); state.focus[name] = "50% 50%"; setSlot(name, id); } else setSlot(name, "ph");
    }
  }

  /* image picker modal */
  let pickSlot = null, pickFilter = state.project !== PH ? "p:" + state.project : "All";
  doc.addEventListener("click", async e => {
    const ppe = e.target.closest(".ppe-i");
    if (ppe) { const order = ["req", "rams", "off"]; ppe.dataset.state = order[(order.indexOf(ppe.dataset.state) + 1) % 3]; return; }
    const tk = e.target.closest(".dc-tick");
    if (tk) { remember(); const st = tk.closest(".dc-step"); if (st.dataset.done === "x") delete st.dataset.done; else st.dataset.done = st.dataset.done ? "x" : "1"; return; }
    const up = e.target.closest(".dc-up");
    if (up) { e.preventDefault(); const f = $("#dc-top"); if (f) f.parentNode.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    const te = e.target.closest(".dc-te, .dc-ce");
    if (te) { e.preventDefault(); const tg = doc.querySelector(te.getAttribute("href")); if (tg) { tg.scrollIntoView({ behavior: "smooth", block: "center" }); selectBlk(tg); } return; }
    const plb = e.target.closest(".pl-bar"), plm = e.target.closest(".pl-months");
    if (plb) return editPipeBar(plb.closest("li"));
    if (plm) return editPipeStart(plm.closest(".pl"));
    const sd = e.target.closest(".dc-sign tbody td:nth-child(3)"); if (sd) return pickDate(sd);
    const mcap = e.target.closest(".dc-mapcap");
    if (mcap) { if (mcap.dataset.href) window.open(mcap.dataset.href, "_blank", "noopener"); else toast("Set the map location first: click the map"); return; }
    let lk = e.target.closest("[data-link]");
    if (lk && lk.classList.contains("dc-sp-pw") && !e.target.closest(".dc-sp-li")) lk = null;      // product name: the text is edited; only the icon opens the link
    if (lk && !lk.classList.contains("dc-url")) return editLink(lk);     // documentation links: "Edit link" on the block toolbar
    const f = e.target.closest(".d-fig"); if (!f) return;
    if (f.closest(".dc-blk")) { $$(".d-fig.sel", doc).forEach(x => x.classList.remove("sel")); f.classList.add("sel"); curFig = f; drawBar(); if (f.dataset.mapslot) openMap(f.dataset.slot); return; }   // documentation: select (maps open the map); change images via the toolbar or double-click
    if (f.dataset.mapslot) return openMap(f.dataset.slot);
    if (f.dataset.mirrorSlot) { const src = slotEl(f.dataset.mirrorSlot); if (!src) return; pickSlot = f.dataset.mirrorSlot; src.classList.add("sel"); openPicker(); return; }
    pickSlot = f.dataset.slot; $$(".d-fig.sel").forEach(x => x.classList.remove("sel")); f.classList.add("sel"); openPicker();
  });
  let curFig = null;
  doc.addEventListener("dblclick", e => { const ch = e.target.closest("[data-chart]"); if (ch) return editChart(ch); const f = e.target.closest(".dc-blk .d-fig"); if (f) changeImage(f); });
  function changeImage(f) {
    if (!f) return; if (f.dataset.mapslot) return openMap(f.dataset.slot);
    pickSlot = f.dataset.slot; $$(".d-fig.sel", doc).forEach(x => x.classList.remove("sel")); f.classList.add("sel"); curFig = f; openPicker();
  }
  function openPicker() {
    pickFilter = state.project !== PH ? "p:" + state.project : "All"; $("#modal").hidden = false;
    drawChips(); drawGrid(); drawFocus();
    // link box: images that carry a link (webcams), and any documentation image (optional link)
    const f = slotEl(pickSlot), hasLink = f && !f.dataset.mapslot && (f.dataset.href !== undefined || !!f.closest(".dc-blk"));
    $("#mLinkRow").hidden = !hasLink; if (hasLink) $("#mLink").value = f.dataset.href || "";
  }
  $("#mLink").addEventListener("input", e => {
    const f = slotEl(pickSlot); if (!f) return; let v = e.target.value.trim();
    if (v && !/^[a-z]+:/i.test(v)) v = "https://" + v;
    if (!v && f.closest(".dc-blk")) delete f.dataset.href; else f.dataset.href = v;
  });
  function closePicker() { $("#modal").hidden = true; $$(".d-fig.sel").forEach(x => x.classList.remove("sel")); }
  $("#mClose").onclick = closePicker; $("#modal").addEventListener("mousedown", e => { if (e.target.id === "modal") closePicker(); });
  document.addEventListener("keydown", e => { if (e.key !== "Escape") return; if (!$("#modal").hidden) closePicker(); if (!$("#mapModal").hidden) $("#mapModal").hidden = true; });
  /* picker filters: this project first, then All / People / Branding */
  const isPeople = i => /^people/i.test(pname(i.project || ""));
  const isBrand = i => i.project === "_Logos" || String(i.id).startsWith("logo:");
  const isProj = i => !isPeople(i) && !isBrand(i) && !["Saved", "Maps", "Uploaded"].includes(i.project) && !String(i.project).startsWith("_");
  const PICK = { project: i => i.project === state.project, All: () => true, Projects: isProj, People: isPeople, Branding: isBrand };
  function drawChips() {
    const chip = (k, label, cls = "") => `<button class="chipb ${cls} ${k === pickFilter ? "on" : ""}" data-p="${k}">${chEsc(label)}</button>`;
    const projs = [...new Set(LIB.filter(isProj).map(i => i.project))];
    if (state.project !== PH && !projs.includes(state.project)) projs.unshift(state.project);
    $("#mChips").innerHTML = `<div class="crow">${chip("All", "All")}${chip("People", "People")}${chip("Branding", "Branding")}</div>`;
    $("#mProj").innerHTML = projs.length ? `<div class="crow sub">${projs.map(p => chip("p:" + p, pname(p))).join("")}</div>` : "";
    $("#mProj").hidden = !projs.length;
    $$("#mChips .chipb, #mProj .chipb").forEach(b => b.onclick = () => { pickFilter = b.dataset.p; drawChips(); drawGrid(); });
  }
  function drawGrid() {
    const a = slotAspect(pickSlot), cur = state.slots[pickSlot], g = $("#mGrid"); g.innerHTML = "";
    const pb = document.createElement("button"); pb.className = "mi" + (cur === "ph" ? " cur" : ""); pb.innerHTML = `<img src="${phSrc("PLACEHOLDER")}" alt=""><span class="bd">Placeholder</span>`;
    pb.onclick = () => { remember(); setSlot(pickSlot, "ph"); closePicker(); }; g.appendChild(pb);
    const flt = pickFilter.startsWith("p:") ? (i => i.project === pickFilter.slice(2)) : pickFilter === "Projects" ? (i => isProj(i) && i.project !== state.project) : PICK[pickFilter] || PICK.All;
    LIB.filter(flt).forEach(i => {
      const c = cropFrac(i, a), b = document.createElement("button"); b.className = "mi" + (i.id === cur ? " cur" : "");
      const cls = c < .18 ? "" : c < .4 ? "mid" : "bad", txt = c < .18 ? "Good fit" : c < .4 ? `Crops ${Math.round(c * 100)}%` : `Heavy crop ${Math.round(c * 100)}%`;
      b.innerHTML = `<img src="${i.src}" alt="" loading="lazy"><span class="bd ${cls}">${txt}</span>`; b.title = pname(i.project) + (i.file ? " / " + i.file : "");
      b.onclick = () => { remember(); setSlot(pickSlot, i.id, "50% 50%"); closePicker(); markOverflow(); };
      g.appendChild(b);
    });
  }
  function drawFocus() {
    const cur = state.focus[pickSlot] || "50% 50%", box = $("#focusGrid"); box.innerHTML = "";
    ["0% 0%", "50% 0%", "100% 0%", "0% 50%", "50% 50%", "100% 50%", "0% 100%", "50% 100%", "100% 100%"].forEach(p => {
      const b = document.createElement("button"); if (p === cur) b.className = "on"; b.title = p;
      b.onclick = () => { state.focus[pickSlot] = p; $("img", slotEl(pickSlot)).style.objectPosition = p; drawFocus(); };
      box.appendChild(b);
    });
  }
  $("#mFile").addEventListener("change", async e => {
    const file = e.target.files[0]; if (!file) return;
    if (WS.on && state.project !== PH) {
      e.target.value = "";
      try { await writeFile(await subDir(state.project, "media"), file.name, file); await scanSource(); const id = `${state.project}/${file.name}`;
            await dimsReady(); setSlot(pickSlot, id, "50% 50%"); closePicker(); toast(`Added to ${state.project}/media`); }
      catch (err) { toast("Couldn't save the image to the project folder"); }
      return;
    }
    const fr = new FileReader();
    fr.onload = () => {
      const im = new Image();
      im.onload = () => {
        const sc = Math.min(1, 2200 / Math.max(im.width, im.height)), c = document.createElement("canvas");
        c.width = Math.round(im.width * sc); c.height = Math.round(im.height * sc); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
        const entry = { id: "upload-" + (++uid), project: "Uploaded", w: c.width, h: c.height, src: encodeCanvas(c), embed: true };
        LIB.push(entry); fillProjectSelect(); setSlot(pickSlot, entry.id, "50% 50%"); closePicker(); toast("Image added");
      };
      im.src = fr.result;
    };
    fr.readAsDataURL(file); e.target.value = "";
  });

  /* ------------------------------------------------------------------ text editing */
  document.execCommand("defaultParagraphSeparator", false, "p");
  const SZ = [-3, -2, -1, 0, 1, 2];
  const ROLES = {
    title:   { label: "Project title",  size: [-3, 3], italic: 1, align: ["left", "right"], colors: ["white", "black", "main"] },
    kicker:  { label: "Label",          size: [-3, 3], italic: 1, colors: ["black", "main", "white"] },
    sector:  { label: "Sector heading", size: [-3, 3], italic: 1, colors: ["main", "black", "white"] },
    h1:      { label: "Section heading",size: [-3, 3], italic: 1, colors: ["black", "main", "white"] },
    h2:      { label: "Page heading",   size: [-3, 3], italic: 1, colors: ["black", "main"] },
    tag:     { label: "Side tag",       size: [-3, 3], italic: 1, colors: ["black", "main"] },
    quote:   { label: "Pull quote",     size: [-3, 3], bold: 1, italic: 1, align: ["left", "right"], colors: ["white", "black"] },
    fact:    { label: "Key fact",       size: [-3, 3], italic: 1, colors: ["white", "black", "main"] },
    list:    { label: "Highlight",      size: [-3, 3], italic: 1, bold: 1, colors: ["black", "main", "white"] },
    heading: { label: "Subheading",     size: [-3, 3], bold: 1, italic: 1, colors: ["main", "dark", "black", "white"] },
    mast:    { label: "Title", size: [-3, 3], italic: 1, colors: ["white", "black"] },
    addr:    { label: "Address",        size: [-3, 3], italic: 1, colors: ["white", "black"] },
    date:    { label: "Issue date",     size: [-3, 3], bold: 1, italic: 1, colors: ["black", "main"] },
    sechead: { label: "Section heading",size: [-3, 3], italic: 1, colors: ["black", "main"] },
    pipe:    { label: "Pipeline project (colour = status)", size: [-3, 3], italic: 1, colors: ["go", "mid", "early"] },
    plname:  { label: "Pipeline project", size: [-3, 3], italic: 1, colors: [] },
    pldesc:  { label: "Pipeline note",  size: [-3, 3], bold: 1, colors: [] },
    dclt:    { label: "Large title",    size: [-3, 3], italic: 1, colors: ["black", "main", "grey"] },
    dcls:    { label: "Large sub-title", size: [-3, 3], italic: 1, colors: ["main", "black", "grey"] },
    dcsect:  { label: "Section title", size: [-3, 3], italic: 1, colors: ["black", "main", "grey"] },
    dch:     { label: "Heading",        size: [-3, 3], italic: 1, colors: ["black", "main", "grey"] },
    dcsh:    { label: "Sub-heading",    size: [-3, 3], italic: 1, colors: ["main", "black", "grey"] },
    dcst:    { label: "Step title",     size: [-3, 3], italic: 1, colors: ["black", "main", "grey"] },
    legend:  { label: "Status key",     size: [-3, 3], italic: 1, colors: ["black"] },
    pname:   { label: "Name and role",  size: [-3, 3], italic: 1, colors: ["black", "main"] },
    caption: { label: "Caption",        size: [-3, 3], italic: 1, colors: ["black", "white"] },
    sub:     { label: "Sub-title", size: [-3, 3], italic: 1, colors: ["white", "black"] },
    statl:   { label: "Key fact label", size: [-3, 3], italic: 1, colors: ["black", "main"] },
    statv:   { label: "Key fact",       size: [-3, 3], italic: 1, colors: ["black", "main"] },
    contact: { label: "Contact line",   size: [-3, 3], bold: 1, italic: 1, colors: ["black", "main", "white"] },
    ptag:    { label: "Project name",   size: [-3, 3], italic: 1, colors: ["black", "main", "white"] },
    body:    { label: "Body text",      size: [-3, 3], bold: 1, italic: 1, align: ["left", "justify"], colors: ["black", "main", "grey"] }
  };
  const COLOR_HEX = () => { const f = family(state.main); return { main: f.main, dark: f.dark, light: f.light, black: "#000000", white: "#FFFFFF", grey: "#8a8a90", go: "#119b24", mid: "#ff8c2a", early: "#f5b971" }; };
  let target = null;                                      // {el, role}

  function targetFor(node) {
    if (node && node.nodeType === 3) node = node.parentNode;
    const ed = node && node.closest && node.closest(".ed"); if (!ed) return null;
    const role = ed.dataset.role;
    if (role === "fact") { const f = node.closest(".fact"); return { el: f || ed, role: "fact" }; }
    if (role && role !== "cta") return { el: ed, role };
    // flowing copy frames and the call-to-action panel
    let n = node; while (n && n.parentNode !== ed && n !== ed) n = n.parentNode;
    if (!n || n === ed) return { el: ed.firstElementChild || ed, role: "body" };
    if (n.tagName === "H3") return { el: n, role: ed.closest(".s-pipe") ? "pipe" : "heading" };
    if (n.tagName === "UL") { const li = node.closest("li"); return { el: li || n, role: "body" }; }
    return { el: n, role: "body" };
  }
  function syncPanel() {
    const t = target, cap = t && ROLES[t.role];
    $("#tsRole").textContent = cap ? cap.label : "Click some text";
    const set = (id, on, active) => { const b = $(id); b.disabled = !on; b.classList.toggle("on", !!active); };
    const sz = t ? parseInt(t.el.dataset.size || "0", 10) : 0;
    set("#tsSmaller", cap && cap.size && sz > cap.size[0], false); set("#tsLarger", cap && cap.size && sz < cap.size[1], false);
    $("#tsPt").textContent = cap ? (Math.round(parseFloat(getComputedStyle(t.el).fontSize) * 7.5) / 10) + " pt" : "";
    $("#tsSize").textContent = cap ? (sz > 0 ? "+" + sz : String(sz)) : "";
    set("#tsBold", cap && cap.bold, t && t.el.dataset.bold === "1"); set("#tsItalic", cap && cap.italic, t && t.el.dataset.italic === "1");
    $$("#textStyle [data-al]").forEach(b => {
      const ok = cap && cap.align && cap.align.includes(b.dataset.al); b.disabled = !ok; b.classList.toggle("on", !!(ok && t.el.dataset.align === b.dataset.al));
    });
    const box = $("#tsColors"); box.innerHTML = "";
    if (cap) { const hx = COLOR_HEX(); cap.colors.forEach(c => {
      const s = document.createElement("span"); s.className = "chip" + (t.el.dataset.color === c ? " on" : ""); s.style.background = hx[c]; s.title = c;
      s.onmousedown = e => e.preventDefault(); s.onclick = () => { t.el.dataset.color = c; syncPanel(); }; box.appendChild(s); }); }
    $("#tsHint").textContent = cap ? "Options shown are the ones that suit this text." : "Only the options that suit the selected text are available.";
  }
  const noFocusSteal = b => b.addEventListener("mousedown", e => e.preventDefault());
  $$("#textStyle button").forEach(noFocusSteal);
  function step(dir) {
    const cap = ROLES[target && target.role]; if (!cap || !cap.size) return;
    const cur = parseInt(target.el.dataset.size || "0", 10), n = Math.max(cap.size[0], Math.min(cap.size[1], cur + dir));
    if (n === 0) delete target.el.dataset.size; else target.el.dataset.size = String(n);
    if (target.role === "title") fitTitle(target.el);
    if (target.el.classList.contains("gh-title")) fitHeader(target.el);
    if (target.el.dataset.sync) syncFrom(target.el);
    markOverflow(); syncPanel();
  }
  $("#tsSmaller").onclick = () => step(-1); $("#tsLarger").onclick = () => step(1);
  function toggleFmt(cmd, attr) {
    if (!target) return;
    const sel = window.getSelection();
    if (target.role === "body" && sel && !sel.isCollapsed && target.el.contains(sel.anchorNode)) { document.execCommand(cmd); }
    else { if (target.el.dataset[attr] === "1") delete target.el.dataset[attr]; else target.el.dataset[attr] = "1"; }
    syncPanel();
  }
  $("#tsBold").onclick = () => toggleFmt("bold", "bold"); $("#tsItalic").onclick = () => toggleFmt("italic", "italic");
  $$("#textStyle [data-al]").forEach(b => b.onclick = () => {
    if (!target) return; if (target.el.dataset.align === b.dataset.al) delete target.el.dataset.align; else target.el.dataset.align = b.dataset.al; syncPanel();
  });

  function updateTarget() { const s = window.getSelection(); const t = s && s.anchorNode ? targetFor(s.anchorNode) : null; if (t) { target = t; syncPanel(); } }
  doc.addEventListener("focusin", updateTarget);
  doc.addEventListener("click", e => { if (!e.target.closest(".d-fig")) setTimeout(updateTarget, 0); });
  doc.addEventListener("keyup", updateTarget);

  doc.addEventListener("paste", e => {
    if (!e.target.closest(".ed")) return; e.preventDefault();
    const txt = (e.clipboardData || window.clipboardData).getData("text/plain"); document.execCommand("insertText", false, txt);
  });
  const SINGLE = new Set(["kicker", "sector", "date", "caption", "sub", "statl", "plname", "pldesc", "dcsect", "dch", "dcsh", "dcst", "dcls"]), BREAK = new Set(["dclt", "title", "h1", "h2", "tag", "quote", "mast", "addr", "ptag", "sechead", "pname", "statv", "contact"]);
  /* lists: sub-items (one level). Tab / Shift+Tab, or "→ Sub" / "← Out" on the toolbar, act on the line the cursor is in */
  function liAtCaret(root) { const s = getSelection(); if (!s.rangeCount) return null; let n = s.anchorNode; n = n && (n.nodeType === 1 ? n : n.parentNode); const li = n && n.closest && n.closest("li"); return li && root.contains(li) && li.closest(".dc-list,.dc-dd") ? li : null; }
  function liMove(root, dir) {
    const li = liAtCaret(root); if (!li) return toast("Click in the list line first");
    const s = getSelection(), keep = s.rangeCount ? [s.anchorNode, s.anchorOffset] : null, top = li.parentNode.classList.contains("dc-list") || li.parentNode.classList.contains("ed");
    if (dir > 0) {
      const prev = li.previousElementSibling; let dep = 0; for (let x = li.parentNode; x && x !== root.parentNode; x = x.parentNode) if (/^(OL|UL)$/.test(x.tagName)) dep++;
      if (dep >= 3 || !prev) return toast(dep >= 3 ? "Lists go three levels deep" : "The first line can't be a sub-item");
      let sub = [...prev.children].find(c => /^(OL|UL)$/.test(c.tagName)); if (!sub) { sub = document.createElement(li.parentNode.tagName); prev.appendChild(sub); }
      sub.appendChild(li); const own = [...li.children].find(c => /^(OL|UL)$/.test(c.tagName)); if (own) { while (own.firstChild) sub.appendChild(own.firstChild); own.remove(); }
    } else {
      if (top) return; const sub = li.parentNode, pli = sub.parentNode, after = [...sub.children].slice([...sub.children].indexOf(li) + 1);
      pli.after(li); if (after.length) { const ns = document.createElement(sub.tagName); after.forEach(a => ns.appendChild(a)); li.appendChild(ns); } if (!sub.children.length) sub.remove();
    }
    if (keep && doc.contains(keep[0])) { try { s.collapse(keep[0], keep[1]); } catch (e) {} }
  }
  doc.addEventListener("keydown", e => {
    if (e.key === "Tab" && e.target.closest && e.target.closest(".dc-list,.dc-dd ul")) { const b = e.target.closest(".dc-blk"); if (b && liAtCaret(b)) { e.preventDefault(); remember(); liMove(b, e.shiftKey ? -1 : 1); dcFlow(); return; } }
    const ed = e.target.closest && e.target.closest(".ed"); if (!ed || e.key !== "Enter") return;
    const role = ed.dataset.role;
    if (SINGLE.has(role)) e.preventDefault();
    else if (BREAK.has(role)) { e.preventDefault(); document.execCommand("insertLineBreak"); }
  });
  /* In Here: no more than 100 words (flagged in the app, never in exports) */
  function ihCount(t) { const n = (t.innerText.trim().match(/\S+/g) || []).length, box = t.closest(".dc-inhere");
    if (n > 100) box.dataset.over = n + " / 100 words"; else delete box.dataset.over; }
  let tmr, dcT; doc.addEventListener("input", e => {
    const ed = e.target.closest(".ed"); if (!ed) return;
    if (ed.classList.contains("d-title")) fitTitle(ed);
    if (ed.classList.contains("gh-title")) fitHeader(ed);
    if (ed.closest(".dc-flow")) { clearTimeout(dcT); dcT = setTimeout(dcFlow, 450); }
    if (ed.dataset.sync) syncFrom(ed);
    if (ed.classList.contains("gh-sub")) { alertFoot(); footTag(); }   // footer banners that repeat the minor title (Training, Blank Page)
    if (ed.classList.contains("dc-iht")) ihCount(ed);
    if (ed.classList.contains("dc-list")) { if ($("ol ol, ol ul, ul ul, ul ol, li li li", ed)) listFix(ed.parentNode); listCont(); }
    if (ed.classList.contains("dc-ctitle")) { clearTimeout(dcT); dcT = setTimeout(dcFlow, 450); }
    clearTimeout(tmr); tmr = setTimeout(markOverflow, 120); wordCount();
  });
  doc.addEventListener("focusout", e => {
    const ed = e.target.closest && e.target.closest(".ed"); if (!ed) return;
    normalise(ed); if (ed.classList.contains("d-flow")) reflow(); markOverflow();
  });
  function normalise(ed) {        // stray <div> blocks -> <p>; strip pasted inline styles
    if (!(ed.classList.contains("d-flow") || ed.classList.contains("d-frame") || ed.classList.contains("d-cta") || ed.classList.contains("d-body") || ed.classList.contains("dc-p") || ed.classList.contains("dc-ctext"))) return;
    $$("div", ed).forEach(d => { if (d.parentNode === ed && !d.classList.contains("d-fig")) { const p = document.createElement("p"); p.innerHTML = d.innerHTML; d.replaceWith(p); } });
    $$("[style]", ed).forEach(n => { if (!n.closest(".d-fig")) n.removeAttribute("style"); });
    $$("p:empty", ed).forEach(p => { if (ed.children.length > 1) p.remove(); });
  }

  /* title auto-fit (vertical title shrinks until it fits the panel) */
  function fitTitle(el) {
    if (getComputedStyle(el).writingMode === "horizontal-tb") {
      const max = parseFloat(getComputedStyle(el).getPropertyValue("--fitmax")) || 0;
      el.style.removeProperty("--fit"); if (!max) return;
      for (let pt = max; pt >= 16; pt -= 1) { el.style.setProperty("--fit", pt + "pt"); if (el.scrollWidth <= el.clientWidth + 1 && el.scrollHeight <= el.clientHeight + 1) break; }
      return;
    }
    for (let pt = 66; pt >= 28; pt -= 2) {
      el.style.setProperty("--fit", pt + "pt");
      if (el.scrollWidth <= el.clientWidth + 1 && el.scrollHeight <= el.clientHeight + 1) break;
    }
  }

  /* threaded copy: flow1 -> flow2 at paragraph level */
  const over = el => el.scrollHeight > el.clientHeight + 1;
  function reflow() {
    const a = $(".flow1", doc), b = $(".flow2", doc); if (!a || !b) return;
    while (b.firstElementChild && !over(a)) { const n = b.firstElementChild; a.appendChild(n); if (over(a)) { b.insertBefore(n, b.firstChild); break; } }
    while (over(a) && a.children.length > 1) b.insertBefore(a.lastElementChild, b.firstChild);
    while (a.lastElementChild && a.lastElementChild.tagName === "H3" && a.children.length > 1) b.insertBefore(a.lastElementChild, b.firstChild);
  }
  /* offline stand-in for AI summarising: drop the last sentence / bullet / paragraph until the box fits */
  function trimToFit(el) {
    let guard = 60;
    while (over(el) && guard--) {
      const last = el.lastElementChild; if (!last || el.children.length < 2 && last.tagName !== "UL" && last.tagName !== "P") break;
      if (last.tagName === "UL" && last.children.length > 1) { last.lastElementChild.remove(); continue; }
      if (last.tagName === "P") {
        const parts = last.textContent.match(/[^.!?]+[.!?]+\s*|[^.!?]+$/g) || [];
        if (parts.length > 1) { last.textContent = parts.slice(0, -1).join("").trim(); continue; }
      }
      if (el.children.length > 1) last.remove(); else break;
      while (el.lastElementChild && el.lastElementChild.tagName === "H3" && el.children.length > 1) el.lastElementChild.remove();
    }
  }
  function trimAll() { $$(".d-flow,.d-frame,.d-cta,.d-list,.d-body", doc).forEach(el => { if (over(el)) trimToFit(el); }); markOverflow(); }
  $("#trimBtn").onclick = () => { trimAll(); toast("Text trimmed to fit"); };
  /* the status pill: when something is too full, clicking it jumps to the next problem (cycling through them) */
  let overI = -1;
  $("#status").onclick = () => { const o = $$(".over,[data-over]", doc); if (!o.length) return; overI = (overI + 1) % o.length; o[overI].scrollIntoView({ behavior: "smooth", block: "center" }); toast(`Problem ${overI + 1} of ${o.length}`); };
  function markOverflow() {
    let n = 0;
    $$(".d-flow,.d-frame,.d-cta,.d-list,.d-body,.dc-flow", doc).forEach(el => { const o = over(el); el.classList.toggle("over", o); if (o) n++; });
    const st = $("#status"); st.className = n ? "warn" : "ok";
    $("#trimBtn").hidden = !n || isDoc();
    st.textContent = n ? `${n} text box${n > 1 ? "es" : ""} too full (orange outline)` : "All text fits"; st.title = n ? "Click to jump to the problem" : ""; st.style.cursor = n ? "pointer" : "";
  }

  /* ------------------------------------------------------------------ exports */
  function cleanClone(sp) {
    $$("[contenteditable]", sp).forEach(n => n.removeAttribute("contenteditable"));
    $$("[spellcheck]", sp).forEach(n => n.removeAttribute("spellcheck"));
    $$(".ed", sp).forEach(n => n.classList.remove("ed", "over")); $$(".sel", sp).forEach(n => n.classList.remove("sel")); $$(".dc-step.on, .dc-fc.on", sp).forEach(n => n.classList.remove("on"));
    $$("[data-autolink]", sp).forEach(el => {
      const t = el.textContent.trim(); if (!t || (el.dataset.autolink === "tel" && !/\d{5}/.test(t.replace(/\s/g, "")))) return;
      const href = el.dataset.autolink === "tel" ? "tel:" + t.replace(/[^\d+]/g, "") : el.dataset.autolink === "mail" ? "mailto:" + t : /^[a-z]+:/i.test(t) ? t : "https://" + t.replace(/^\/+/, "");
      el.innerHTML = `<a href="${href.replace(/"/g, "&quot;")}" target="_blank" rel="noopener">${el.innerHTML}</a>`;
    });
    $$(".dc-dir tbody tr", sp).forEach(r => {
      const em = r.children[3], tel = r.children[4];
      const addr = em && (em.textContent.match(/[\w.+-]+@[\w-]+(\.[\w-]+)+/) || [])[0];
      if (addr && addr !== "name@company.co.uk") em.innerHTML = `<a href="mailto:${addr}">${em.innerHTML}</a>`;
      if (tel && /\d{5}/.test(tel.textContent.replace(/\s/g, "")) && !/^\[|^01234 567890$/.test(tel.textContent.trim())) tel.innerHTML = `<a href="tel:${tel.textContent.replace(/[^\d+]/g, "")}">${tel.innerHTML}</a>`;
    });
    $$("[data-href]:not(.d-fig)", sp).forEach(el => { const a = document.createElement("a"); a.className = "d-href"; a.href = el.dataset.href; a.target = "_blank"; a.rel = "noopener"; el.appendChild(a); });
    $$(".d-fig[data-href]", sp).forEach(f => {
      const a = document.createElement("a"); a.className = "d-href"; a.href = f.dataset.href; a.target = "_blank"; a.rel = "noopener"; f.appendChild(a);
      const cap = f.dataset.cap && sp.querySelector("." + f.dataset.cap);
      if (cap) cap.innerHTML = `<a class="d-caplink" href="${f.dataset.href.replace(/"/g, "&quot;")}" target="_blank" rel="noopener">${cap.innerHTML}</a>`;
    });
    sp.style.transform = ""; return sp;
  }
  const land = () => state.orient === "landscape" && !TPL.paper;   // templates with their own paper (A3 landscape) ignore the orientation buttons
  const PAPER = () => pp() ? (([w, h]) => ({ css: `${w}mm ${h}mm`, w, h, pt: [w * 72 / 25.4, h * 72 / 25.4] }))(sizeOf(state.paper, (() => { const f = $(".d-spread.dc", doc); return f ? pageOr(f) : state.orient; })())) : bl() ? (([w, h]) => ({ css: `${state.paper.toUpperCase()} ${state.orient}`, w, h, pt: [w * 72 / 25.4, h * 72 / 25.4] }))(blankSize()) : a3() ? { css: "A3 landscape", w: 420, h: 297, pt: [1190.55, 841.89] } : land() ? { css: "A4 landscape", w: 297, h: 210, pt: [841.89, 595.28] } : { css: "A4 portrait", w: 210, h: 297, pt: [595.28, 841.89] };
  const pageCount = () => $$(".d-spread", doc).reduce((n, sp) => n + (sp.dataset.pages === "1" ? 1 : 2), 0) || TPL.pages;
  function pageWindows() {
    const frag = document.createDocumentFragment();
    $$(".d-spread", doc).forEach(sp => (land() || sp.dataset.pages === "1" ? [0] : [0, 1]).forEach(k => {
      const pw = document.createElement("div"); pw.className = "pw" + (sp.dataset.pw ? "" : sp.dataset.paper ? " pa3" : land() ? " pl" : k ? " r" : ""); if (sp.dataset.pw) { pw.style.width = sp.dataset.pw + "mm"; pw.style.height = sp.dataset.ph + "mm"; pw.dataset.mm = sp.dataset.pw + "x" + sp.dataset.ph; } pw.appendChild(cleanClone(sp.cloneNode(true))); frag.appendChild(pw);
    }));
    return frag;
  }
  /* print: one named @page per paper size, so a document can mix portrait and landscape pages */
  function pageRules(root) {
    const sizes = new Set(); $$(".pw[data-mm]", root).forEach(p => { sizes.add(p.dataset.mm); p.style.page = "s" + p.dataset.mm; });
    return `@page{size:${PAPER().css};margin:0}` + [...sizes].map(k => { const [w, h] = k.split("x"); return `@page s${k}{size:${w}mm ${h}mm;margin:0}`; }).join("");
  }
  let paperLast;
  function paperApply() {
    if (pp()) {
      let key = state.paper + ":";
      $$(".d-spread.dc", doc).forEach(sp => {
        if (!sp.dataset.or) sp.dataset.or = state.orient === "landscape" ? "l" : "p";
        const [w, h] = sizeOf(state.paper, pageOr(sp));
        sp.dataset.pw = w; sp.dataset.ph = h; sp.style.setProperty("--pw", w + "mm"); sp.style.setProperty("--ph", h + "mm");
        sp.classList.add("dc-pp"); sp.classList.remove("dc-lnd"); delete sp.dataset.paper;
        sp.classList.toggle("dc-a3", w >= 400);          // the wide A3 landscape page keeps its wide-page layouts
        if (TPL.paper) sp.classList.add("dc-trn");
        key += sp.dataset.or;
      });
      if (paperLast !== undefined && paperLast !== key) {
        if (isDoc()) { const two = state.paper === "a4" && dcPages().every(p => p.dataset.or !== "l"); if (two !== doc.classList.contains("multi")) setView(two ? "multi" : "single"); }
        layout(); requestAnimationFrame(() => { if (isDoc()) dcFlow(); });
      }
      paperLast = key; return;
    }
    if (bl()) {
      const [w, h] = blankSize(), key = w + "x" + h;
      $$(".d-spread.dc", doc).forEach(sp => { sp.dataset.pw = w; sp.dataset.ph = h; sp.style.setProperty("--pw", w + "mm"); sp.style.setProperty("--ph", h + "mm"); sp.classList.add("dc-blank"); sp.classList.toggle("dc-port", h > w); });
      if (paperLast !== undefined && paperLast !== key) { layout(); requestAnimationFrame(() => { if (isDoc()) dcFlow(); }); }
      paperLast = key; return;
    }
    const alt = !!(TPL.paper && TPL.paper.alt); if (!alt && !TPL.landscape) return;
    const on = alt ? a3() : ls();
    $$(".d-spread.dc", doc).forEach(sp => {
      if (alt) { sp.classList.add("dc-trn"); sp.classList.toggle("dc-a3", on); if (on) sp.dataset.paper = "a3"; else delete sp.dataset.paper; }
      else sp.classList.toggle("dc-lnd", on); });
    if (paperLast !== undefined && paperLast !== on) { if (isDoc()) setView(on ? "single" : "multi"); layout(); requestAnimationFrame(() => { if (isDoc()) dcFlow(); }); }
    paperLast = on;
  }
  const syncOrient = () => { const f = $(".d-spread.dc", doc); if (!f) return;
    if (pp()) { const alt = !!(TPL.paper && TPL.paper.alt);
      $$(".d-spread.dc", doc).forEach(sp => { if (sp.dataset.or) return;            // older saves: one orientation for the whole document
        sp.dataset.or = alt ? (sp.dataset.paper ? "l" : "p") : sp.classList.contains("dc-lnd") ? "l" : "p"; });
      state.paper = f.dataset.pw ? (Math.max(+f.dataset.pw, +f.dataset.ph) > 300 ? "a3" : "a4") : alt && f.dataset.paper ? "a3" : "a4";
      state.orient = pageOr(f); return; }
    if (bl()) { const w = +f.dataset.pw || 210, h = +f.dataset.ph || 297; state.orient = w > h ? "landscape" : "portrait"; state.paper = Math.max(w, h) > 300 ? "a3" : "a4"; return; } if (TPL.paper && TPL.paper.alt) state.orient = f.dataset.paper ? "landscape" : "portrait"; else if (TPL.landscape) state.orient = f.classList.contains("dc-lnd") ? "landscape" : "portrait"; };
  const setOrient = (o, all) => { if (pp() && all) $$(".d-spread.dc", doc).forEach(sp => { sp.dataset.or = o === "landscape" ? "l" : "p"; });
    const alt = !!(TPL.paper && TPL.paper.alt) || !!TPL.landscape || bl(); $("#paperSeg").hidden = !bl() && !pp(); $("#pA4").classList.toggle("on", state.paper !== "a3"); $("#pA3").classList.toggle("on", state.paper === "a3"); if (!alt && (TPL.portraitOnly || TPL.paper)) o = "portrait"; $("#oLand").disabled = $("#oPort").disabled = !alt && (!!TPL.paper || !!TPL.portraitOnly); state.orient = o; $("#oPort").classList.toggle("on", o === "portrait"); $("#oLand").classList.toggle("on", o === "landscape");
    $("#oPort").title = alt ? "A4 portrait" : ""; $("#oLand").title = alt ? (TPL.landscape || bl() ? "Landscape" : "A3 landscape") : ""; if (bl()) $("#oPort").title = "Portrait";
    if (pp()) { $("#oPort").disabled = $("#oLand").disabled = true; $("#oPort").title = $("#oLand").title = "Set portrait or landscape above each page, or use All pages under the page"; const ors = dcPages().map(p => p.dataset.or || (o === "landscape" ? "l" : "p")), mixed = ors.some(x => x !== ors[0]);
      $("#oPort").classList.toggle("on", !mixed && ors[0] !== "l"); $("#oLand").classList.toggle("on", !mixed && ors[0] === "l"); }
    paperApply();
    if (pp()) { const n = dcPages().length, nl = dcPages().filter(p => p.dataset.or === "l").length, sz = state.paper.toUpperCase();
      $("#oHint").textContent = `${n} page${n === 1 ? "" : "s"}, ${sz} ${!nl ? "portrait" : nl === n ? "landscape" : `(${n - nl} portrait, ${nl} landscape)`}.`; return; }
    $("#oHint").textContent = bl() ? `${pageCount()} page${pageCount() === 1 ? "" : "s"}, ${PAPER().css}.` : TPL.landscape ? `${pageCount()} page${pageCount() === 1 ? "" : "s"}, ${o === "landscape" ? "A4 landscape" : "A4 portrait"}.` : TPL.paper ? `${pageCount()} page${pageCount() === 1 ? "" : "s"}, ${a3() ? TPL.paper.name : TPL.paper.alt}.` : o === "portrait" ? `${pageCount()} page${pageCount() === 1 ? "" : "s"}, A4 portrait.` : `${TPL.pages / 2} page${TPL.pages > 2 ? "s" : ""}, A4 landscape. Each page is a full spread, so text prints smaller.`; };
  $("#pA4").onclick = () => { if (pp()) remember(); state.paper = "a4"; setOrient(state.orient); }; $("#pA3").onclick = () => { if (pp()) remember(); state.paper = "a3"; setOrient(state.orient); };
  $("#oPort").onclick = () => { remember(); setOrient("portrait", true); }; $("#oLand").onclick = () => { remember(); setOrient("landscape", true); };
  $("#outPdf").onclick = async () => {
    if (WS.on && state.project !== PH) {
      const b = $("#outPdf"); b.disabled = true; toast("Building archive PDF\u2026");
      try { const name = outName(), pdf = await buildPdf();
            await writeFile(await subDir(state.project, "PDF outputs"), name + ".pdf", pdf);
            await writeFile(await subDir(state.project, "PDF outputs"), name + ".save.json", JSON.stringify(await snapshot(true, name)));
            toast(`Archive PDF saved to ${state.project}/PDF outputs`); }
      catch (err) { console.error(err); toast("Couldn't build the archive PDF (the print dialog still works)"); }
      b.disabled = false;
    }
    const root = $("#printRoot"); root.replaceChildren(pageWindows()); await inlineImgs(root);
    let ps = $("#pageSize"); if (!ps) { ps = document.createElement("style"); ps.id = "pageSize"; document.head.appendChild(ps); }
    ps.textContent = pageRules(root);
    const done = () => { root.replaceChildren(); window.removeEventListener("afterprint", done); };
    const keep = document.title; document.title = docTitle();          // also becomes the suggested PDF file name
    window.addEventListener("afterprint", () => { document.title = keep; }, { once: true });
    window.addEventListener("afterprint", done); setTimeout(() => window.print(), 60);
  };
  async function buildHtml() {
    const css = $("#docStyle").textContent + "\n" + $("#fontStyle").textContent;
    const r = document.documentElement.style, vars = ["--c-main", "--c-light", "--c-dark", "--c-mixl", "--c-mixd", "--c-main-rgb", "--c-light-rgb", "--c-dark-rgb"]
      .map(v => `${v}:${r.getPropertyValue(v) || getComputedStyle(document.documentElement).getPropertyValue(v)}`).join(";");
    const PW = PAPER().w, PH_ = PAPER().h;
    const holder = document.createElement("div"); holder.appendChild(pageWindows()); await inlineImgs(holder); const rules = pageRules(holder);
    const dims = $$(".pw", holder).map(p => p.dataset.mm ? p.dataset.mm.split("x").map(Number) : [PW, PH_]), maxW = Math.max(...dims.map(d => d[0])), same = dims.every(d => d[0] === dims[0][0] && d[1] === dims[0][1]);
    const pages = $$(".pw", holder).map((p, i) => `<div class="pg" style="--pw:${dims[i][0]}mm;--ph:${dims[i][1]}mm${p.dataset.mm ? ";page:s" + p.dataset.mm : ""}">${p.outerHTML}</div>`).join("\n");
    const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${docTitle().replace(/&/g, "&amp;").replace(/</g, "&lt;")}</title><base target="_blank"><style>${css}
:root{${vars}}
html,body{margin:0;background:#e6e6e9}
.wrap{display:flex;flex-wrap:wrap;justify-content:center;margin:0 auto;padding:12px 0;width:var(--ww,100%)}
.pg{width:calc(var(--pw)*var(--s,1));height:calc(var(--ph)*var(--s,1));position:relative;flex:none;box-shadow:0 2px 14px rgba(0,0,0,.18);margin:0}
.pg>.pw{position:absolute;left:0;top:0;transform:scale(var(--s,1));transform-origin:0 0;page-break-after:auto}
@media print{${rules}html,body{background:#fff}.wrap{display:block;width:auto;padding:0}.pg{width:var(--pw);height:var(--ph);box-shadow:none;break-after:page}.pg>.pw{transform:none}}
</style></head><body><div class="wrap" id="wrap">
${pages}
</div><script>
(function(){var px=${maxW}*96/25.4;function fit(){var w=innerWidth,two=w>=px*2*.8&&${!same || maxW > 210 || land() || TPL.paper || bl() ? "false" : "true"},n=two?2:1,s=Math.min(1.5,(w-(two?32:20))/(px*n));
document.documentElement.style.setProperty('--s',s);document.documentElement.style.setProperty('--ww',(px*s*n)+'px');}
fit();addEventListener('resize',fit);})();
<\/script></body></html>`;
    return html;
  }
  $("#outHtml").onclick = async () => {
    const html = await buildHtml(), name = outName();
    download(new Blob([html], { type: "text/html" }), name + ".html");
    if (WS.on && state.project !== PH) {
      try { const d = await subDir(state.project, "HTML outputs"); await writeFile(d, name + ".html", html);
            await writeFile(d, name + ".save.json", JSON.stringify(await snapshot(true, name))); toast(`HTML downloaded and copied to ${state.project}/HTML outputs`); }
      catch (err) { toast("HTML downloaded (couldn't copy it to the project folder)"); }
    } else toast("HTML downloaded");
  };
  /* document title for exports, e.g. "Dakota Hotel - Pre-site Info" */
  function docTitle() {
    const t = el => { const e = $(el, doc); return e ? e.innerText.replace(/[ \t]+/g, " ").trim() : ""; };
    const tidy = s => { s = s.replace(/^\[|\]$/g, "").trim(); return s === s.toUpperCase() ? s.toLowerCase().replace(/(^|[\s\-\/(])([a-z])/g, (m, a, b) => a + b.toUpperCase()) : s; };
    let name, kind;
    if (isDoc()) { name = t(".gh-title"); kind = t(".gh-sub"); }
    else { name = t(".d-title").split(/\n/)[0]; kind = "Case Study"; }
    name = tidy((name || pname(state.project)).replace(/\s*\n\s*/g, " ")); kind = kind.replace(/\s*\n\s*/g, " "); kind = tidy(kind || TPL.name);
    return name ? `${name} - ${kind}` : kind;
  }
  function download(blob, name) { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }
  function outName() { const d = new Date(), pad = n => String(n).padStart(2, "0");
    return safeName(`${state.project === PH ? "Untitled" : pname(state.project)} - ${TPL.name} - ${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}${pad(d.getMinutes())}`); }

  /* ================================================================== local workspace
     <platform folder>/source/<Project>/media | info | saves | PDF outputs | HTML outputs
     Uses Chrome/Edge folder access. Folder handle is remembered (IndexedDB); permission is re-confirmed each session. */
  const WS = { root: null, src: null, on: false, projects: [] };
  const SUBS = ["media", "info", "saves", "PDF outputs", "HTML outputs"];
  const IMG_RX = /\.(jpe?g|png|webp|gif|jfif|avif)$/i, INFO_RX = /\.(pdf|txt|md|rtf|doc|docx|csv|xls|xlsx|ppt|pptx|odt)$/i;
  const safeName = s => String(s).replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, " ").trim().slice(0, 90) || "untitled";
  const idb = (mode, fn) => new Promise((res, rej) => {
    const rq = indexedDB.open("gmi-templating", 1); rq.onupgradeneeded = () => rq.result.createObjectStore("kv"); rq.onerror = () => rej(rq.error);
    rq.onsuccess = () => { const tx = rq.result.transaction("kv", mode), q = fn(tx.objectStore("kv")); tx.oncomplete = () => res(q && q.result); tx.onerror = () => rej(tx.error); };
  });
  const kvGet = k => idb("readonly", st => st.get(k)).catch(() => null);
  const kvSet = (k, v) => idb("readwrite", st => st.put(v, k)).catch(() => null);
  const fsOK = () => "showDirectoryPicker" in window;
  async function projDir(p) { return WS.src.getDirectoryHandle(p, { create: true }); }
  async function subDir(p, sub) { return (await projDir(p)).getDirectoryHandle(sub, { create: true }); }
  async function listFiles(dir, rx) { const out = []; for await (const [n, h] of dir.entries()) if (h.kind === "file" && !n.startsWith(".") && (!rx || rx.test(n))) out.push(h); return out; }
  async function writeFile(dir, name, data) { const fh = await dir.getFileHandle(name, { create: true }), w = await fh.createWritable(); await w.write(data); await w.close(); }
  /* nothing is ever deleted outright: files and projects removed in the app are first copied into <connected folder>/trash, and only then removed from where they were */
  const trashStamp = () => { const d = new Date(), z = n => String(n).padStart(2, "0"); return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())} ${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}`; };
  async function freeName(dir, name) { if (!await existsAny(dir, name)) return name; const i = name.lastIndexOf("."), b = i > 0 ? name.slice(0, i) : name, e = i > 0 ? name.slice(i) : ""; return `${b} (deleted ${trashStamp()})${e}`; }
  async function existsAny(dir, name) { try { await dir.getFileHandle(name); return true; } catch (e) { try { await dir.getDirectoryHandle(name); return true; } catch (e2) { return false; } } }
  async function copyDir(from, to) { for await (const [n, h] of from.entries()) { if (h.kind === "file") await writeFile(to, n, await h.getFile()); else await copyDir(h, await to.getDirectoryHandle(n, { create: true })); } }
  async function trashFile(dir, name, project, sub) {
    const t = await (await (await WS.root.getDirectoryHandle("trash", { create: true })).getDirectoryHandle(project || "_loose", { create: true })).getDirectoryHandle(sub || "files", { create: true });
    await writeFile(t, await freeName(t, name), await (await dir.getFileHandle(name)).getFile());      // copy first; if this throws, the original is left alone
    await dir.removeEntry(name);
  }
  async function trashProject(p) {
    const t = await WS.root.getDirectoryHandle("trash", { create: true }), to = await t.getDirectoryHandle(await freeName(t, p), { create: true });
    await copyDir(await WS.src.getDirectoryHandle(p), to);
    await WS.src.removeEntry(p, { recursive: true });
  }
  async function exists(dir, name) { try { await dir.getFileHandle(name); return true; } catch (e) { return false; } }

  async function useRoot(h) {
    WS.root = h; WS.src = await h.getDirectoryHandle("source", { create: true }); WS.on = true;
    await scanSource(); if (!WS.projects.includes(state.project)) state.project = PH;
    fillProjectSelect(); renderWS(); renderSaves(); build();
  }
  async function scanSource() {
    // keep existing image URLs alive (pages, saved working copies and exports still point at them); only new or changed files get a new URL
    const old = new Map(LIB.filter(e => e.fs).map(e => [e.id, e])); LIB.length = 0;
    const names = []; for await (const [n, h] of WS.src.entries()) if (h.kind === "directory" && !n.startsWith(".")) names.push(n);
    names.sort((a, b) => a.localeCompare(b));
    for (const p of names) {
      for (const sub of SUBS) await subDir(p, sub);           // make sure every project has the full structure
      for (const fh of await listFiles(await subDir(p, "media"), IMG_RX)) {
        const f = await fh.getFile(), id = `${p}/${fh.name}`, prev = old.get(id);
        if (prev && prev.mod === f.lastModified && prev.size === f.size) { LIB.push(prev); continue; }
        LIB.push({ id, project: p, file: fh.name, src: URL.createObjectURL(f), w: 0, h: 0, fs: true, mod: f.lastModified, size: f.size });
      }
    }
    WS.projects = names.filter(n => !n.startsWith("_")); addBuiltins();
    for (const [slot, id] of Object.entries(state.slots)) { const e = id !== "ph" && byId(id); if (e && slotEl(slot) && $("img", slotEl(slot)).src !== e.src) setSlot(slot, id, state.focus[slot]); }
    WS.dims = Promise.all(LIB.map(e => e.w ? 0 : new Promise(res => { const im = new Image(); im.onload = () => { e.w = im.naturalWidth; e.h = im.naturalHeight; res(); }; im.onerror = res; im.src = e.src; })));
  }
  const dimsReady = () => WS.dims || Promise.resolve();
  async function connectFolder() {
    if (!fsOK()) { toast("Folder access needs Chrome or Edge"); return; }
    try { const h = await window.showDirectoryPicker(Object.assign({ id: "gmi-templating", mode: "readwrite" }, WS.on && WS.root ? { startIn: WS.root } : {})); await kvSet("root", h); await useRoot(h); toast("Connected to " + h.name); }
    catch (e) { if (e.name !== "AbortError") { console.error(e); toast("Couldn't open that folder"); } }
  }
  async function reconnect() {
    const h = await kvGet("root"); if (!h) return connectFolder();
    try { if (await h.requestPermission({ mode: "readwrite" }) === "granted") { await useRoot(h); toast("Reconnected to " + h.name); } } catch (e) { connectFolder(); }
  }
  function renderWS() {
    const pend = !WS.on && WS.pending;
    $("#wsTop").className = "wstop " + (WS.on ? "on" : pend ? "pend" : "off");
    $("#wsLbl").textContent = WS.on ? "Connected" : pend ? `Reconnect “${WS.pending}”` : "Connect folder…";
    $("#wsBtn").title = WS.on ? `Connected to the “${WS.root.name}” folder. Click to browse it, or pick a different folder` : pend ? `Click to reconnect to the “${WS.pending}” folder you used last time` : "Choose the platform folder. Projects, photos and saves are kept in its source folder";
    $("#wsOther").hidden = !pend;
    $("#newProj").disabled = $("#upFilesBtn").disabled = !WS.on; $("#upFilesBtn").hidden = !WS.on;
  }
  $("#wsBtn").onclick = () => (!WS.on && WS.pending ? reconnect() : connectFolder());
  $("#wsOther").onclick = () => connectFolder();

  /* pipeline Gantt: bar dates/status + first month of the chart */
  const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const plStart = pl => parseInt(pl.dataset.m0 || "9", 10);
  const plCols = li => { const s = parseInt(li.style.getPropertyValue("--s") || "1", 10), n = parseInt(li.style.getPropertyValue("--n") || "12", 10); return [s, Math.min(12, s + n - 1)]; };
  const plSet = (li, s, e) => { li.style.setProperty("--s", s); li.style.setProperty("--n", e - s + 1); };
  function pipeDialog({ title, startLabel, cols, start, end, status }) {
    return new Promise(res => {
      const box = $("#pipeDlg"), S = $("#pipeS"), E = $("#pipeE");
      $("#pipeTitle").textContent = title; $("#pipeSLabel").textContent = startLabel;
      S.innerHTML = E.innerHTML = ""; cols.forEach((m, i) => { S.add(new Option(m, i + 1)); E.add(new Option(m, i + 1)); });
      S.value = start; E.value = end || 12;
      $("#pipeERow").hidden = !end; $("#pipeStRow").hidden = !status;
      let st = status; $$("#pipeStRow [data-st]").forEach(b => { b.classList.toggle("on", b.dataset.st === st); b.onclick = () => { st = b.dataset.st; $$("#pipeStRow [data-st]").forEach(x => x.classList.toggle("on", x === b)); }; });
      S.onchange = () => { if (end && +E.value < +S.value) E.value = S.value; };
      E.onchange = () => { if (+E.value < +S.value) S.value = E.value; };
      const done = v => { box.hidden = true; $("#pipeForm").onsubmit = null; $("#pipeCancel").onclick = null; res(v); };
      $("#pipeForm").onsubmit = ev => { ev.preventDefault(); done({ start: +S.value, end: +E.value, status: st }); };
      $("#pipeCancel").onclick = () => done(null);
      box.hidden = false;
    });
  }
  async function editPipeBar(li) {
    const pl = li.closest(".pl"), m0 = plStart(pl), cols = Array.from({ length: 12 }, (_, i) => MONTHS[(m0 + i) % 12]);
    const [s, e] = plCols(li), name = ($(".pl-name", li) || li).innerText.trim();
    const v = await pipeDialog({ title: name || "Pipeline project", startLabel: "Starts", cols, start: s, end: e, status: li.dataset.st || "go" });
    if (!v) return; plSet(li, v.start, Math.max(v.start, v.end)); li.dataset.st = v.status; toast("Pipeline updated");
  }
  async function editPipeStart(pl) {
    const m0 = plStart(pl), v = await pipeDialog({ title: "Pipeline months", startLabel: "Chart starts in", cols: MONTHS, start: m0 + 1 });
    if (!v) return; const n0 = v.start - 1, d = ((n0 - m0) % 12 + 12) % 12, shift = d > 6 ? d - 12 : d;   // keep bars on the same calendar months
    pl.dataset.m0 = n0; $$(".pl-months span", pl).forEach((sp, i) => sp.textContent = MONTHS[(n0 + i) % 12]);
    $$(".pl-rows li", pl).forEach(li => { let [s, e] = plCols(li); s = Math.min(12, Math.max(1, s - shift)); e = Math.min(12, Math.max(s, e - shift)); plSet(li, s, e); });
    toast("Pipeline months updated");
  }


  /* ------------------------------------------------------------------ charts (bulletin)
     Each [data-chart] holds its data as JSON; renderChart draws it, editChart opens a small table to change values and colours.
       bars:  { min, max, hi, lo, cg, ca, cr, d:[[label, value]...] }   colour by value: >= hi green, >= lo amber, else red
       line:  { h: title, c: colour, d:[[label, value]...] }
       donut: { v: percent, c: colour, l: label } */
  const chEsc = x => String(x).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const chData = el => { try { return JSON.parse(el.dataset.chart); } catch (e) { return null; } };
  const fmt = v => (Math.round(v * 10) / 10).toString();
  function renderChart(el) {
    const c = chData(el); if (!c) return;
    if (c.t === "gantt") return renderGantt(el, c);
    if (PLUS[c.t]) return renderPlus(el, c);
    if (c.t === "donut") {
      const v = Math.max(0, Math.min(100, +c.v || 0));
      el.innerHTML = `<div class="ch-ring" style="background:conic-gradient(${c.c} ${v}%, #e3e4e8 0)"><b>${fmt(v)}%</b></div><div class="ch-lab">${chEsc(c.l || "")}</div>`;
    } else if (c.t === "line") {
      const vs = c.d.map(r => +r[1] || 0), lo = Math.min(...vs), hi = Math.max(...vs), pad = (hi - lo || Math.abs(hi) || 1) * .35;
      const y = v => 30 - ((v - (lo - pad)) / ((hi + pad) - (lo - pad))) * 26 - 2, x = i => (i + .5) * 100 / vs.length;
      const pts = vs.map((v, i) => `${x(i)},${y(v)}`).join(" ");
      el.innerHTML = `<div class="ch-h">${chEsc(c.h || "")}</div><svg viewBox="0 0 100 30" preserveAspectRatio="none"><polyline points="${pts}" fill="none" stroke="${c.c}" stroke-width="1.4" vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg>`
        + `<div class="ch-x">${c.d.map(r => `<span><b style="color:${c.c};font-size:1.25em">${fmt(+r[1] || 0)}</b><br>${chEsc(r[0])}</span>`).join("")}</div>`;
      // dots drawn in the svg so they stay round under preserveAspectRatio=none
      const svg = $("svg", el), box = svg.getBoundingClientRect(), ar = box.width && box.height ? (box.width / box.height) / (100 / 30) : 1;
      svg.insertAdjacentHTML("beforeend", vs.map((v, i) => `<ellipse cx="${x(i)}" cy="${y(v)}" rx="${1.6 / ar}" ry="1.6" fill="#fff" stroke="${c.c}" stroke-width="1.2" vector-effect="non-scaling-stroke"/>`).join(""));
    } else if (c.t === "bars") {
      const span = c.max - c.min || 1, pc = v => Math.max(0, Math.min(100, (v - c.min) / span * 100));
      const col = v => v >= c.hi ? c.cg : v >= c.lo ? c.ca : c.cr;
      const ticks = []; for (let t = c.min; t <= c.max + 1e-9; t += span > 30 ? 10 : 5) ticks.push(t);
      el.style.setProperty("--n", c.d.length);
      el.innerHTML = `<div class="ch-key"><span style="--k-c:${c.cg}">${fmt(c.hi)}% and above</span><span style="--k-c:${c.ca}">${fmt(c.lo)}&ndash;${fmt(c.hi)}%</span><span style="--k-c:${c.cr}">Below ${fmt(c.lo)}%</span></div>`
        + `<div class="ch-plot">${ticks.map(t => `<i style="bottom:${pc(t)}%"><b>${fmt(t)}%</b></i>`).join("")}`
        + `<i class="th" style="bottom:${pc(c.lo)}%;border-color:${c.cr}99"></i><i class="th" style="bottom:${pc(c.hi)}%;border-color:${c.cg}99"></i>`
        + `<div class="ch-cols">${c.d.map(r => { const v = +r[1] || 0; return `<div class="ch-col"><span class="ch-val" style="color:${col(v)}">${fmt(v)}%</span><span class="ch-bar" style="height:max(.6mm, ${pc(v)}%);background:${col(v)}"></span></div>`; }).join("")}</div></div>`
        + `<div class="ch-months">${c.d.map(r => `<span>${chEsc(r[0])}</span>`).join("")}</div>`;
    }
  }
  /* timeline (gantt): dates are stored as yyyy-mm-dd, shown as dd-Mmm; durations are working days (Mon-Fri) */
  const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const dOf = s => { const d = new Date((s || "") + "T00:00:00"); return isNaN(d) ? null : d; };
  const ddmmm = d => d ? String(d.getDate()).padStart(2, "0") + "-" + MON[d.getMonth()] : "";
  const workDays = (a, b) => { if (!a || !b || b < a) return 0; let n = 0; for (const d = new Date(a); d <= b; d.setDate(d.getDate() + 1)) if (d.getDay() % 6) n++; return n; };
  function renderGantt(el, c) {
    const rows = c.d.map(r => ({ n: r[0], s: dOf(r[1]), e: dOf(r[2]), col: r[3] || c.c })).map(r => (r.s && r.e && r.e < r.s ? { ...r, s: r.e, e: r.s } : r));
    const ok = rows.filter(r => r.s && r.e);
    if (!ok.length) { el.innerHTML = `<div class="gt-empty">Double-click to add timeline items</div>`; return; }
    const a0 = new Date(Math.min(...ok.map(r => r.s))), b0 = new Date(Math.max(...ok.map(r => r.e)));
    // the chart runs from one week before the first start to one week after the last end
    const A = new Date(a0.getFullYear(), a0.getMonth(), a0.getDate() - 7), B = new Date(b0.getFullYear(), b0.getMonth(), b0.getDate() + 7);
    const span = (B - A) / 864e5 + 1, pct = d => Math.max(0, Math.min(100, ((d - A) / 864e5) / span * 100));
    const months = []; for (let m = new Date(A.getFullYear(), A.getMonth(), 1); m <= B; m = new Date(m.getFullYear(), m.getMonth() + 1, 1)) months.push(m);
    const multiYear = A.getFullYear() !== B.getFullYear();
    const mlab = (m, i) => MON[m.getMonth()] + (multiYear && (m.getMonth() === 0 || i === 0) ? " " + String(m.getFullYear()).slice(2) : "");
    const lines = months.filter(m => m > A).map(m => `<i style="left:${pct(m)}%"></i>`).join("");
    const cols = months.map((m, i) => { const l = pct(m < A ? A : m), r = pct(new Date(m.getFullYear(), m.getMonth() + 1, 1)), w = (m.getMonth() === B.getMonth() && m.getFullYear() === B.getFullYear() ? 100 : r) - l;
      return `<span style="left:${l}%;width:${w}%">${w >= 6 ? mlab(m, i) : ""}</span>`; }).join("");
    const T = new Date(); T.setHours(0, 0, 0, 0); const showNow = c.now !== 0 && T >= A && T <= B;   // today marker (on unless switched off)
    const nc = c.nc || "", nowI = showNow ? `<i class="gt-now" style="left:${pct(T)}%${nc ? ";border-color:" + nc : ""}"></i>` : "";
    el.innerHTML = `<div class="gt-row gt-head"><span>Item</span><span>Start</span><span>End</span><span class="gt-d">Days*</span><div class="gt-track gt-months">${cols}${lines}</div></div>`
      + rows.map(r => `<div class="gt-row"><span class="gt-n">${chEsc(r.n || "")}</span><span>${ddmmm(r.s)}</span><span>${ddmmm(r.e)}</span><span class="gt-d">${workDays(r.s, r.e) || ""}</span><div class="gt-track">${lines}${r.s && r.e ? `<b class="gt-bar" style="left:${pct(r.s)}%;width:${Math.max(.8, ((r.e - r.s) / 864e5 + 1) / span * 100)}%;background:${r.col}"></b>` : ""}${nowI}</div></div>`).join("")
      + (showNow ? `<div class="gt-row gt-nowrow"><span></span><span></span><span></span><span></span><div class="gt-track">${nowI}<em class="gt-nowl" style="left:${pct(T)}%${nc ? ";background:" + nc : ""}">Today ${ddmmm(T)}</em></div></div>` : "")
      + `<div class="gt-note">*Working days (Monday to Friday).</div>`;
  }
  function editGantt(el, c) {
    const box = $("#chartDlg"), body = $("#cdBody"); $("#cdTitle").textContent = "Timeline";
    const draw = () => {
      $("#cdExtra").innerHTML = `<label class="cd-c"><input type="checkbox" id="gtNow" ${c.now !== 0 ? "checked" : ""}> Today marker</label><label class="cd-c">Marker colour<input type="color" id="gtNc" value="${chEsc(c.nc || "#d20a11")}"></label>`;
      body.innerHTML = `<div class="cd-gt"><b>Item</b><b>Start</b><b>End</b><b>Bar</b><b>Days</b><b></b>${c.d.map((r, i) => `<input data-g="${i}" data-f="0" value="${chEsc(r[0])}"><input data-g="${i}" data-f="1" type="date" value="${r[1] || ""}"><input data-g="${i}" data-f="2" type="date" value="${r[2] || ""}"><input data-g="${i}" data-f="3" type="color" class="cd-gc" value="${chEsc(r[3] || c.c)}" title="Colour of this bar"><span class="cd-days">${workDays(dOf(r[1]), dOf(r[2])) || "–"}</span><span class="cd-mv"><button type="button" class="mini" data-up="${i}" title="Move up"${i ? "" : " disabled"}>↑</button><button type="button" class="mini" data-dn="${i}" title="Move down"${i < c.d.length - 1 ? "" : " disabled"}>↓</button><button type="button" class="mini" data-del="${i}" title="Remove">✕</button></span>`).join("")}</div>
        <button type="button" class="mini" id="gtAdd">+ Add item</button>`;
      $$("[data-g]", body).forEach(i => i.oninput = () => { c.d[+i.dataset.g][+i.dataset.f] = i.value; const r = c.d[+i.dataset.g]; i.parentNode.querySelectorAll(".cd-days")[+i.dataset.g].textContent = workDays(dOf(r[1]), dOf(r[2])) || "–"; });
      $$("[data-up]", body).forEach(b => b.onclick = () => { const i = +b.dataset.up; c.d.splice(i - 1, 0, c.d.splice(i, 1)[0]); draw(); });
      $$("[data-dn]", body).forEach(b => b.onclick = () => { const i = +b.dataset.dn; c.d.splice(i + 1, 0, c.d.splice(i, 1)[0]); draw(); });
      $("#gtNow").onchange = e => { c.now = e.target.checked ? 1 : 0; };
      $("#gtNc").oninput = e => { c.nc = e.target.value; };
      $$("[data-del]", body).forEach(b => b.onclick = () => { c.d.splice(+b.dataset.del, 1); draw(); });
      $("#gtAdd").onclick = () => { const last = c.d[c.d.length - 1], s = last ? dOf(last[2]) : new Date(); if (s) s.setDate(s.getDate() + 1); const iso = d => d.toISOString().slice(0, 10), e = new Date(s); e.setDate(e.getDate() + 13);
        c.d.push(["New item", iso(new Date(s.getTime() - s.getTimezoneOffset() * 6e4)), iso(new Date(e.getTime() - e.getTimezoneOffset() * 6e4))]); draw(); };
    };
    draw(); box.hidden = false;
    const done = () => { box.hidden = true; $("#cdExtra").innerHTML = ""; $("#cdForm").onsubmit = null; $("#cdCancel").onclick = null; };
    $("#cdCancel").onclick = done;
    $("#cdForm").onsubmit = ev => { ev.preventDefault(); remember(); el.dataset.chart = JSON.stringify(c); renderChart(el); done(); dcFlow(); toast("Timeline updated"); };
  }
  function editChart(el) {
    const c0 = chData(el); if (!c0) return;
    if (c0.t === "gantt") return editGantt(el, JSON.parse(JSON.stringify(c0)));
    if (PLUS[c0.t]) return editPlus(el, JSON.parse(JSON.stringify(c0)));
    const c = c0;
    const box = $("#chartDlg"), body = $("#cdBody");
    const inp = (k, v, type = "text", w = "") => `<input data-k="${k}" type="${type}" value="${chEsc(v)}" ${type === "number" ? 'step="any"' : ""} ${w ? `style="width:${w}"` : ""}>`;
    const rows = (lbl) => `<div class="cd-rows"><b>${lbl}</b><b>Value</b>${c.d.map((r, i) => inp("d" + i + "l", r[0]) + inp("d" + i + "v", r[1], "number")).join("")}</div>`;
    let html = "";
    if (c.t === "donut") { $("#cdTitle").textContent = "Donut chart"; html = `<label>Label${inp("l", c.l)}</label><div class="cd-2"><label>Value (%)${inp("v", c.v, "number")}</label><label>Colour${inp("c", c.c, "color")}</label></div>`; }
    if (c.t === "line") { $("#cdTitle").textContent = "Line chart"; html = `<label>Title${inp("h", c.h)}</label><label class="cd-c">Colour${inp("c", c.c, "color")}</label>${rows("Month")}`; }
    if (c.t === "bars") {
      $("#cdTitle").textContent = "Score chart";
      html = `${rows("Month")}<div class="cd-band"><span>Green from</span>${inp("hi", c.hi, "number", "64px")}%${inp("cg", c.cg, "color")}<span>Amber from</span>${inp("lo", c.lo, "number", "64px")}%${inp("ca", c.ca, "color")}<span>Red below amber</span>${inp("cr", c.cr, "color")}</div>`
        + `<div class="cd-band"><span>Axis from</span>${inp("min", c.min, "number", "64px")}%<span>to</span>${inp("max", c.max, "number", "64px")}%</div>`;
    }
    body.innerHTML = html; box.hidden = false;
    const done = () => { box.hidden = true; $("#cdForm").onsubmit = null; $("#cdCancel").onclick = null; };
    $("#cdCancel").onclick = done;
    $("#cdForm").onsubmit = ev => {
      ev.preventDefault();
      $$("[data-k]", body).forEach(i => {
        const k = i.dataset.k, val = i.type === "number" ? (i.value === "" ? 0 : +i.value) : i.value, m = k.match(/^d(\d+)([lv])$/);
        if (m) c.d[+m[1]][m[2] === "l" ? 0 : 1] = val; else c[k] = val;
      });
      if (c.t === "bars" && c.max <= c.min) c.max = c.min + 10;
      remember(); el.dataset.chart = JSON.stringify(c); renderChart(el); done(); toast("Chart updated");
    };
  }

  /* ------------------------------------------------------------------ chart elements (Documentation "Charts" group)
     Each .dc-chart[data-chart] holds JSON; click a chart (or "Edit chart" on the toolbar) to change titles, values and colours.
       pie:   { h, cl: centre label, cv: centre value ("" = total), u: unit before, d:[[label, value, colour]...] }
       kpi:   { h, c, u, d:[[label, value]...], k:[[label, text, "up"|"down"]...] }        bars + KPI stats below
       gauge: { h, v, max, u: before, s: after, c }                                         semicircle progress to target
       lines: { h, a: shade 0/1, x:[month...], s:[[name, colour, [values]]...] }           multi-series line / area
       radar: { h, max, c, d:[[axis, value]...] }
       track: { h, s, n ("" = today), g, e: yyyy-mm-dd, ls, ln, lg, le: labels, c, ca, cb } programme position bar */
  const PAL = ["#d20a11", "#1d1d1b", "#8a8a90", "#f08a8d", "#ff8c2a", "#119b24"];
  const PLUS = { pie: "Donut chart", pie2: "Double donut chart", sun: "Sunburst chart", kpi: "Bars and KPIs", gauge: "Gauge", lines: "Line chart", radar: "Radar chart", track: "Progress bar" };
  const num = v => (+v || 0).toLocaleString("en-GB", { maximumFractionDigits: 1 });
  const nice = m => { const p = 10 ** Math.floor(Math.log10(m || 1)), f = m / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; };
  const c2h = c => c.h ? `<div class="c2-h">${chEsc(c.h)}</div>` : "";
  const ARR = up => `<svg class="c2-arr ${up ? "up" : "dn"}" viewBox="0 0 12 12"><path d="${up ? "M6 1.5 11 7.5H7.8V11H4.2V7.5H1z" : "M6 10.5 1 4.5h3.2V1h3.6v3.5H11z"}"/></svg>`;
  const dlong = d => d ? ddmmm(d) + "-" + String(d.getFullYear()).slice(2) : "";
  let cuid = 0;
  function renderPlus(el, c) {
    const u = chEsc(c.u || ""), s = chEsc(c.s || "");
    if (c.t === "pie") {
      const d = c.d.map(r => [r[0], Math.max(0, +r[1] || 0), r[2]]), sum = d.reduce((a, r) => a + r[1], 0), tot = sum || 1;
      const R = 40, C = 2 * Math.PI * R, gap = d.filter(r => r[1] > 0).length > 1 ? 1.4 : 0; let off = 0;
      const segs = d.map(r => { const len = r[1] / tot * C, o = off; off += len;
        return r[1] ? `<circle cx="50" cy="50" r="${R}" fill="none" stroke="${r[2]}" stroke-width="13" stroke-dasharray="${Math.max(.01, len - gap)} ${C}" stroke-dashoffset="${-o}" transform="rotate(-90 50 50)"/>` : ""; }).join("");
      const pk = c.cs !== undefined && c.cs !== "" && d[+c.cs] ? d[+c.cs] : null;
      const cv = pk ? u + num(pk[1]) : c.cv !== undefined && String(c.cv).trim() !== "" ? chEsc(c.cv) : u + num(sum);
      el.innerHTML = c2h(c) + `<div class="c2-pie"><div class="c2-ring"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="${R}" fill="none" stroke="#eceef1" stroke-width="13"/>${segs}</svg>`
        + `<div class="c2-pc"><span>${chEsc(pk ? pk[0] : c.cl || "")}</span><b>${cv}</b></div></div>`
        + `<div class="c2-leg">${d.map(r => `<span class="c2-dot" style="background:${r[2]}"></span><span>${chEsc(r[0])}</span><b>${u}${num(r[1])}</b><em>${Math.round(r[1] / tot * 100)}%</em>`).join("")}</div></div>`;
    } else if (c.t === "pie2") {
      /* two rings sharing the same segments: inner = series 1 (r[1]), outer = series 2 (r[2]); percentages are within each ring */
      const rows = c.d.map(r => ({ n: r[0], a: Math.max(0, +r[1] || 0), b: Math.max(0, +r[2] || 0), col: r[3] }));
      const P = (r, a) => [50 + r * Math.sin(a), 50 - r * Math.cos(a)].map(v => v.toFixed(3)).join(" ");
      const ring = (key, r0, r1) => {
        const sum = rows.reduce((t, r) => t + r[key], 0) || 1; let a0 = 0;
        return rows.map(r => { const f = r[key] / sum; if (!f) return ""; let a1 = a0 + f * 2 * Math.PI; const am = (a0 + a1) / 2, full = f > .9999; if (full) a1 = a0 + 2 * Math.PI - .0001;
          const big = a1 - a0 > Math.PI ? 1 : 0, d = `M${P(r1, a0)} A${r1} ${r1} 0 ${big} 1 ${P(r1, a1)} L${P(r0, a1)} A${r0} ${r0} 0 ${big} 0 ${P(r0, a0)}Z`, mid = (r0 + r1) / 2;
          const t = f >= .04 ? `<text x="${(50 + mid * Math.sin(am)).toFixed(2)}" y="${(50 - mid * Math.cos(am)).toFixed(2)}" text-anchor="middle" dominant-baseline="central" fill="#fff" font-weight="700" font-size="${r1 - r0 > 14 ? 5.4 : 4.6}">${Math.round(f * 100)}%</text>` : "";
          a0 += f * 2 * Math.PI; return `<path d="${d}" fill="${r.col}" stroke="#fff" stroke-width=".7" stroke-linejoin="round"/>` + t; }).join("");
      };
      const ck = c.cs !== undefined && c.cs !== "" && rows[+c.cs] ? rows[+c.cs] : null, sb = rows.reduce((t, r) => t + r.b, 0) || 1;
      const mid2 = ck ? `<text x="50" y="47.5" text-anchor="middle" font-weight="700" font-size="9" fill="#1d1d1b">${Math.round(ck.b / sb * 100)}%</text><text x="50" y="55" text-anchor="middle" font-size="3.6" fill="#666">${chEsc(ck.n)}</text>` : "";
      el.innerHTML = c2h(c) + `<div class="c2-p2"><svg viewBox="0 0 100 100">${ring("a", 19, 33)}${ring("b", 34.5, 49)}${mid2}</svg>`
        + `<div class="c2-p2g"><div class="c2-p2l">${rows.map(r => `<span><i style="background:${r.col}"></i>${chEsc(r.n)}</span>`).join("")}</div>`
        + (c.i || c.o ? `<div class="c2-p2k">${c.i ? `<span>Inner: ${chEsc(c.i)}</span>` : ""}${c.o ? `<span>Outer: ${chEsc(c.o)}</span>` : ""}</div>` : "") + `</div></div>`;
    } else if (c.t === "sun") {
      /* three rings: category (inner), sub (middle), sub-sub (outer). Sub and sub-sub are two different splits of the same category,
         so each ring's slices are scaled to fill the category's arc; the editor warns when the two totals differ. */
      const dp = c.dp === undefined || c.dp === "" ? 2 : Math.max(0, Math.min(4, +c.dp || 0));
      const fv = v => u + (+v || 0).toLocaleString("en-GB", { maximumFractionDigits: dp });
      const hex = h => { const m = /^#?([0-9a-f]{6})$/i.exec(h || ""); const n = m ? parseInt(m[1], 16) : 0x8a8a90; return [n >> 16, (n >> 8) & 255, n & 255]; };
      const mix = (h, f) => "#" + hex(h).map(v => Math.round(v + (255 - v) * f).toString(16).padStart(2, "0")).join("");
      const dark = h => { const [r, g, b] = hex(h); return (.299 * r + .587 * g + .114 * b) < 150; };
      const cats = c.d.map(k => { const a = (k[2] || []).map(r => [String(r[0] || ""), Math.max(0, +r[1] || 0), r[2]]), b = (k[3] || []).map(r => [String(r[0] || ""), Math.max(0, +r[1] || 0), r[2]]);
        const sa = a.reduce((t, r) => t + r[1], 0), sb = b.reduce((t, r) => t + r[1], 0); return { n: String(k[0] || ""), col: k[1], show: k[4] !== 0, a, b, sa, sb, tot: sa || sb }; }).filter(k => k.tot > 0);
      const grand = cats.reduce((t, k) => t + k.tot, 0) || 1;
      const P = (r, a) => [50 + r * Math.sin(a), 50 - r * Math.cos(a)];
      const f2 = v => v.toFixed(2);
      const RG = [[10, 24], [25.4, 38], [39.4, 50]];
      let paths = "", inner = "", calls = []; const CW = .62;
      const place = (ri, a0, a1, fill, name, val, dk, show) => {
        const [r0, r1] = RG[ri], full = a1 - a0 > 2 * Math.PI - .001; if (full) a1 = a0 + 2 * Math.PI - .0001;
        const big = a1 - a0 > Math.PI ? 1 : 0, p = (r, a) => P(r, a).map(f2).join(" ");
        paths += `<path d="M${p(r1, a0)} A${r1} ${r1} 0 ${big} 1 ${p(r1, a1)} L${p(r0, a1)} A${r0} ${r0} 0 ${big} 0 ${p(r0, a0)}Z" fill="${fill}" stroke="#fff" stroke-width=".7" stroke-linejoin="round"/>`;
        const am = (a0 + a1) / 2, rm = (r0 + r1) / 2, t = r1 - r0, da = a1 - a0, arc = da * r0, sn = Math.abs(Math.sin(am)), cs = Math.abs(Math.cos(am)), col = dk ? "#fff" : "#1d1d1b";
        const top = Math.cos(am) >= 0, L = Math.max(name.length, val.length), NL = val ? 2 : 1;
        const flat = F => { const w = L * F * CW + 1, h = F * (NL > 1 ? 2.3 : 1.3), [cx, cy] = P(rm, am), TP = 2 * Math.PI;
          return [-1, 0, 1].every(ix => [-1, 0, 1].every(iy => { const dx = cx + ix * w / 2 - 50, dy = cy + iy * h / 2 - 50, r = Math.hypot(dx, dy), an = ((Math.atan2(dx, -dy) - a0) % TP + TP) % TP;
            return r >= r0 + .4 && r <= r1 - .4 && an >= .01 && an <= da - .01; })); };
        const bend = F => da * (rm - 1.1 * F) * .9 >= L * F * CW + 1 && t >= F * (NL > 1 ? 2.3 : 1.3) + .8;
        const draw = (F, mode) => {
          if (mode === "flat") { const [x, y] = full ? [50, 50 - rm] : P(rm, am);
            inner += `<text x="${f2(x)}" y="${f2(y - (val ? F * .58 : 0))}" text-anchor="middle" dominant-baseline="central" fill="${col}" font-weight="700" font-size="${F}">${chEsc(name)}</text>`
              + (val ? `<text x="${f2(x)}" y="${f2(y + F * .62)}" text-anchor="middle" dominant-baseline="central" fill="${col}" font-size="${F}">${chEsc(val)}</text>` : ""); return; }
          const arcP = (r, id) => { const b = da > Math.PI ? 1 : 0, p = (q, a) => P(q, a).map(f2).join(" ");
            return top ? `<path id="${id}" d="M${p(r, a0)} A${r} ${r} 0 ${b} 1 ${p(r, a1)}" fill="none"/>` : `<path id="${id}" d="M${p(r, a1)} A${r} ${r} 0 ${b} 0 ${p(r, a0)}" fill="none"/>`; };
          const n1 = "c2a" + (++cuid), n2 = "c2a" + (++cuid), rn = !val ? rm - (top ? .35 : -.35) * F : top ? rm + .225 * F : rm - .225 * F, rv = top ? rm - .975 * F : rm + .975 * F;
          inner += arcP(rn, n1) + (val ? arcP(rv, n2) : "")
            + `<text fill="${col}" font-weight="700" font-size="${F}" text-anchor="middle"><textPath href="#${n1}" startOffset="50%">${chEsc(name)}</textPath></text>`
            + (val ? `<text fill="${col}" font-size="${F}" text-anchor="middle"><textPath href="#${n2}" startOffset="50%">${chEsc(val)}</textPath></text>` : ""); };
        const F0 = ri === 0 ? 4 : 3.7, tries = [[F0, "flat"], [F0, "bend"], [F0 * .88, "flat"], [F0 * .88, "bend"]];
        const hit = !show ? null : full ? [F0, "flat"] : tries.find(([F, m]) => (m === "flat" ? flat(F) : bend(F)));
        if (hit) draw(hit[0], hit[1]);
      };
      let a0 = 0; const TAU = 2 * Math.PI;
      cats.forEach((k, ki) => {
        const ka = k.tot / grand * TAU, a1 = a0 + ka;
        place(0, a0, a1, k.col, k.n, "", dark(k.col), k.show);
        [["a", 1, .34, .5], ["b", 2, .66, .8]].forEach(([key, ri, m0, m1]) => { const rows = k[key], sum = rows.reduce((t, r) => t + r[1], 0) || 1; let x0 = a0;
          rows.forEach((r, j) => { if (!r[1]) return; const x1 = x0 + r[1] / sum * ka, fill = mix(k.col, j % 2 ? m1 : m0); place(ri, x0, x1, fill, r[0], c.sv === 0 ? "" : fv(r[1]), dark(fill), r[2] !== 0); x0 = x1; }); });
        a0 = a1; });
      const minX = 0, maxX = 100, co = "";
      const vw = maxX - minX, rn = [c.r1, c.r2, c.r3].filter(x => x && String(x).trim());
      el.innerHTML = c2h(c) + `<div class="c2-p2 c2-sun"><svg viewBox="${f2(minX - 1)} -3 ${f2(vw + 2)} 106" style="width:min(100%,${Math.round((vw + 2) * 1)}mm)">${paths}${inner}${co}</svg>`
        + (rn.length ? `<div class="c2-p2k"><span>Rings, inside out: ${rn.map(chEsc).join(" &rsaquo; ")}</span></div>` : "") + `</div>`;
    } else if (c.t === "kpi") {
      /* KPIs are shaded sections on the grey back bar (darkest = lowest value), with the value in small type beside the bar; each bar has its own colour and can be faded */
      const vs = c.d.map(r => +r[1] || 0), ks = (c.k || []).map(k => ({ l: k[0], v: parseFloat(k[1]) })).filter(k => k.v > 0).sort((a, b) => b.v - a.v);
      const mx = nice(Math.max(...vs, ...ks.map(k => k.v), 0) || 1), last = vs.length - 1;
      const band = (k, j) => `<em class="c2-kb" style="height:${Math.min(100, k.v / mx * 100)}%;background:rgba(29,29,27,${(.08 + .07 * j).toFixed(2)})"></em>`;
      const tag = k => `<span class="c2-kt" style="bottom:${Math.min(100, k.v / mx * 100)}%" title="${chEsc(k.l)}">${u}${num(k.v)}</span>`;
      el.innerHTML = c2h(c) + `<div class="c2-bars kp" style="--n:${vs.length}">${c.d.map((r, i) => `<div class="c2-bc hi${r[3] ? " fade" : ""}"><span class="c2-bv">${u}${num(vs[i])}</span><span class="c2-bw"><span class="c2-bt">${ks.map(band).join("")}<i style="height:${Math.max(0, vs[i]) / mx * 100}%;background:${r[2] || c.c}"></i></span>${i === last ? ks.map(tag).join("") : ""}</span><span class="c2-bl">${chEsc(r[0])}</span></div>`).join("")}</div>`
        + (ks.length ? `<div class="c2-kleg">${ks.slice().reverse().map(k => `<span>${chEsc(k.l)} <b>${u}${num(k.v)}</b></span>`).join("")}</div>` : "");
    } else if (c.t === "gauge") {
      const mx = +c.max || 1, v = +c.v || 0, p = Math.max(0, Math.min(1, v / mx)), a = Math.PI * (1 - p);
      const x = 50 + 40 * Math.cos(a), y = 50 - 40 * Math.sin(a), arc = "M10 50 A40 40 0 0 1 90 50";
      /* optional colour bands: the colour of the highest band the value has reached (as % of the target) */
      const bands = c.bv ? (c.b || []).map(r => [+r[0], r[1]]).filter(r => r[0] >= 0).sort((q, w) => q[0] - w[0]) : [], hit = bands.filter(r => p * 100 >= r[0]).pop(), gcol = hit ? hit[1] : c.c;
      el.innerHTML = c2h(c) + `<div class="c2-gw"><svg viewBox="0 0 100 56"><path d="${arc}" fill="none" stroke="#eceef1" stroke-width="8" stroke-linecap="round"/>`
        + (p > 0 ? `<path d="${arc}" pathLength="100" fill="none" stroke="${gcol}" stroke-width="8" stroke-linecap="round" stroke-dasharray="${p * 100} 101"/>` : "")
        + `<circle cx="${x}" cy="${y}" r="5.2" fill="#fff" stroke="${gcol}" stroke-width="2.4"/></svg>`
        + `<div class="c2-gc"><b>${u}${num(v)}${s}</b></div></div>`;
    } else if (c.t === "lines") {
      const n = c.x.length, all = c.s.flatMap(r => r[2].slice(0, n).map(v => +v || 0)), mx = nice(Math.max(...all, 1)), W = 300, H = 100, id = "c2g" + (++cuid);
      const PADX = 8, px = i => n > 1 ? PADX + i * (W - 2 * PADX) / (n - 1) : W / 2, py = v => H - Math.max(0, Math.min(1, v / mx)) * H;
      const path = pts => pts.map((p, i) => { if (!i) return `M${p[0]},${p[1]}`; const a = pts[i - 2] || pts[i - 1], b = pts[i - 1], d = pts[i + 1] || p;
        const cl = v => Math.max(0, Math.min(H, v));
        return `C${b[0] + (p[0] - a[0]) / 6},${cl(b[1] + (p[1] - a[1]) / 6)} ${p[0] - (d[0] - b[0]) / 6},${cl(p[1] - (d[1] - b[1]) / 6)} ${p[0]},${p[1]}`; }).join(" ");
      const ticks = [0, .25, .5, .75, 1].map(f => `<i style="bottom:${f * 100}%"><b>${num(mx * f)}</b></i>`).join("");
      const sv = c.s.map((r, j) => { const pts = r[2].slice(0, n).map((v, i) => [px(i), py(+v || 0)]); if (!pts.length) return "";
        const ln = path(pts); return (c.a ? `<path d="${ln} L${px(pts.length - 1)},${H} L${px(0)},${H} Z" fill="url(#${id}-${j})" stroke="none"/>` : "")
          + `<path d="${ln}" fill="none" stroke="${r[1]}" stroke-width="1.6" vector-effect="non-scaling-stroke" stroke-linejoin="round" stroke-linecap="round"/>`; }).join("");
      const defs = c.s.map((r, j) => `<linearGradient id="${id}-${j}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${r[1]}" stop-opacity=".16"/><stop offset="1" stop-color="${r[1]}" stop-opacity="0"/></linearGradient>`).join("");
      el.innerHTML = `<div class="c2-hr">${c2h(c)}<div class="c2-key">${c.s.map(r => `<span><i style="background:${r[1]}"></i>${chEsc(r[0])}</span>`).join("")}</div></div>`
        + `<div class="c2-plot">${ticks}<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><defs>${defs}</defs>${sv}</svg>`
        + c.s.map(r => r[2].slice(0, n).map((v, i) => `<u class="c2-pt" style="left:${px(i) / W * 100}%;top:${py(+v || 0) / H * 100}%;--pc:${r[1]}" title="${chEsc(r[0])} - ${chEsc(c.x[i])}: ${num(+v || 0)}"></u>`).join("")).join("") + `</div>`
        + `<div class="c2-mx abs">${c.x.map((m, i) => `<span style="left:${px(i) / W * 100}%">${chEsc(m)}</span>`).join("")}</div>`;
    } else if (c.t === "radar") {
      const n = c.d.length, mx = +c.max || 10, R = 40, ang = i => -Math.PI / 2 + i * 2 * Math.PI / n;
      const pt = (i, r) => [r * Math.cos(ang(i)), r * Math.sin(ang(i))];
      const rings = [1, 2, 3, 4, 5].map(k => `<circle r="${R * k / 5}" fill="${k % 2 ? "none" : "#f6f6f8"}" stroke="#dfe1e5" stroke-width=".35"/>`).reverse().join("");
      const spokes = c.d.map((_, i) => { const [x, y] = pt(i, R); return `<line x1="0" y1="0" x2="${x}" y2="${y}" stroke="#dfe1e5" stroke-width=".35"/>`; }).join("");
      const P = c.d.map((r, i) => pt(i, Math.max(0, Math.min(1, (+r[1] || 0) / mx)) * R));
      const labs = c.d.map((r, i) => { const co = Math.cos(ang(i)), si = Math.sin(ang(i)), tx = co > .3 ? "0" : co < -.3 ? "-100%" : "-50%", ty = si > .3 ? "0" : si < -.3 ? "-100%" : "-50%";
        return `<span class="c2-rl" style="left:${50 + co * 46}%;top:${50 + si * 46}%;transform:translate(${tx},${ty})">${chEsc(r[0])} <b>${num(r[1])}</b></span>`; }).join("");
      el.innerHTML = c2h(c) + `<div class="c2-rw"><div class="c2-ri"><svg viewBox="-50 -50 100 100">${rings}${spokes}`
        + `<polygon points="${P.map(p => p.join(",")).join(" ")}" fill="${c.c}" fill-opacity=".2" stroke="${c.c}" stroke-width=".9" stroke-linejoin="round"/>`
        + P.map(p => `<circle cx="${p[0]}" cy="${p[1]}" r="1.3" fill="${c.c}"/>`).join("") + `</svg>${labs}</div></div>`;
    } else if (c.t === "track") {
      const today = new Date(); today.setHours(0, 0, 0, 0);
      const S = dOf(c.s), E = dOf(c.e), N = c.n ? dOf(c.n) : today;
      if (!S || !E || E <= S) { el.innerHTML = c2h(c) + `<div class="c2-empty">Double-click to set the start and end dates</div>`; return; }
      /* targets are optional and there can be several (older charts had one: c.g / c.lg) */
      const tg = (c.m || (c.g ? [[c.lg || "Target", c.g]] : [])).map(r => ({ l: r[0] || "Target", d: dOf(r[1]), x: r[2] || "" })).filter(r => r.d);
      const pc = d => Math.max(0, Math.min(100, (d - S) / (E - S) * 100)), pn = N ? pc(N) : 0, pg = tg.length ? Math.max(...tg.map(r => pc(r.d))) : 0;
      /* markers (Now and the targets) are sorted by date and alternate above / below the bar; the triangle points at the bar */
      const mk = (N ? [{ l: c.ln || "Now", d: N, p: pn }] : []).concat(tg.map(r => ({ l: r.l, d: r.d, p: pc(r.d), x: r.x }))).sort((a, b) => a.p - b.p).map((m, i) => Object.assign(m, { up: i % 2 === 1 }));
      /* two markers on the same side that would overlap: the first one is lifted clear of the second */
      [true, false].forEach(sd => { const q = mk.filter(m => m.up === sd); q.forEach((m, i) => { const nx = q[i + 1]; if (nx && !nx.lift && nx.p - m.p < 20) m.lift = true; }); });
      const edge = p => p < 9 ? "0" : p > 91 ? "-100%" : "-50%";
      const pin = m => `<i class="c2-tri ${m.up ? "u" : "d"}" style="left:${m.p}%"></i>${m.lift ? `<i class="c2-lift ${m.up ? "u" : "d"}" style="left:${m.p}%"></i>` : ""}<div class="c2-pin ${m.up ? "u" : "d"}${m.lift ? " lift" : ""}" style="left:${m.p}%;transform:translateX(${edge(m.p)})"><span>${chEsc(m.l)}</span><b>${m.x ? chEsc(m.x) : ddmmm(m.d)}</b></div>`;
      const below = mk.some(m => m.up), above = mk.some(m => !m.up);
      const wk = d => Math.max(0, Math.round((d - S) / (7 * 864e5))), totW = wk(E), nowW = Math.min(totW, wk(N || S));
      /* start and end dates sit above the bar, underlined; Now / target markers alternate above and below it; the elapsed line (optional) sits under the bar */
      const liftA = mk.some(m => !m.up && m.lift), liftB = mk.some(m => m.up && m.lift), se = c.se !== 0;
      const gap = (above ? 13 : 3) + (liftA ? 10 : 0);
      el.innerHTML = (c.th === 0 ? "" : c2h(c)) + `<div class="c2-tw" style="--gap:${gap}mm;--lc:${c.lc || "#1d1d1b"};--sc:${c.sc || c.lc || "#1d1d1b"}">${se ? `<div class="c2-te"><b>${ddmmm(S)}</b><b>${ddmmm(E)}</b></div>` : ""}`
        + `<div class="c2-tr" style="margin-top:${gap}mm">`
        + `<i class="c2-b0" style="background:${tg.length ? c.cb : "#eceef1"}"></i>${tg.length ? `<i class="c2-b1" style="width:${pg}%;background:${c.ca}"></i>` : ""}<i class="c2-b2" style="width:${pn}%;background:${c.c}"></i>`
        + mk.map(pin).join("") + `</div>`
        + `<div class="c2-bz" style="min-height:${(below ? 12 : 0) + (liftB ? 10 : 0)}mm">${c.el === 0 ? "" : `<div class="c2-ts">${nowW} of ${totW}wks (<b>${Math.round(pn)}%</b>)</div>`}</div></div>`;
    }
  }
  function editPlus(el, c) {
    const box = $("#chartDlg"), body = $("#cdBody"); $("#cdTitle").textContent = PLUS[c.t];
    const getP = p => p.split(".").reduce((o, k) => (o == null ? o : o[k]), c);
    const setP = (p, v) => { const k = p.split("."), last = k.pop(); k.reduce((o, x) => o[x], c)[last] = v; };
    const I = (p, type = "text", ph = "") => type === "checkbox" ? `<input data-p="${p}" type="checkbox" ${getP(p) ? "checked" : ""}>`
      : `<input data-p="${p}" type="${type}" value="${chEsc(getP(p) ?? "")}" ${type === "number" ? 'step="any"' : ""} ${ph ? `placeholder="${chEsc(ph)}"` : ""}>`;
    const L = (lab, p, type, ph) => `<label>${lab}${I(p, type, ph)}</label>`;
    const X = (a, i) => `<button type="button" class="mini cd-x" data-del="${a}:${i}" title="Remove">✕</button>`;
    const ADD = (a, lab) => `<button type="button" class="mini" data-add="${a}">${lab}</button>`;
    const G = (cols, html) => `<div class="cd-grid" style="grid-template-columns:${cols}">${html}</div>`;
    const draw = () => {
      let h = L("Title", "h");
      const CS = none => `<label>Centre shows<select data-p="cs"><option value="">${none}</option>${c.d.map((r, i) => `<option value="${i}"${String(c.cs) === String(i) ? " selected" : ""}>${chEsc(r[0])}</option>`).join("")}</select></label>`;
      if (c.t === "pie") h += `<div class="cd-2">${CS("Total / own text")}${L("Centre label", "cl")}${L("Centre value", "cv", "text", "Total")}${L("Unit", "u", "text", "e.g. £")}</div>`
        + G("1fr 90px 46px 30px", `<b>Segment</b><b>Value</b><b></b><b></b>` + c.d.map((r, i) => I(`d.${i}.0`) + I(`d.${i}.1`, "number") + I(`d.${i}.2`, "color") + (c.d.length > 1 ? X("d", i) : "<b></b>")).join("")) + ADD("d", "+ Segment");
      if (c.t === "pie2") h += `<div class="cd-2">${L("Inner ring", "i", "text", "e.g. 2025")}${L("Outer ring", "o", "text", "e.g. 2026")}${CS("Nothing")}</div>`
        + G("1fr 64px 64px 46px 30px", `<b>Segment</b><b>Inner</b><b>Outer</b><b></b><b></b>` + c.d.map((r, i) => I(`d.${i}.0`) + I(`d.${i}.1`, "number") + I(`d.${i}.2`, "number") + I(`d.${i}.3`, "color") + (c.d.length > 1 ? X("d", i) : "<b></b>")).join("")) + ADD("d", "+ Segment");
      if (c.t === "sun") {
        h += `<div class="cd-2">${L("Unit", "u", "text", "e.g. £")}${L("Decimals", "dp", "number")}</div>`
          + `<div class="cd-2">${L("Inner ring", "r1", "text", "e.g. Region")}${L("Middle ring", "r2", "text", "e.g. Severity")}${L("Outer ring", "r3", "text", "e.g. Cause")}</div>`
          + `<label class="cd-c"><input type="checkbox" data-sv${c.sv === 0 ? "" : " checked"}>Show values in the labels</label>`
          + `<div class="cd-note">Sub and Sub-sub are two different splits of the same category, so each should add up to the same total. Labels that do not fit inside their segment are left off; untick Label to hide any others.</div>`;
        const sub = (i, p, lab) => G("1fr 70px 38px 30px", `<b>${lab}</b><b>Value</b><b title="Show this label on the chart">Label</b><b></b>` + c.d[i][p].map((r, j) => I(`d.${i}.${p}.${j}.0`) + I(`d.${i}.${p}.${j}.1`, "number") + `<input type="checkbox" data-sh="d.${i}.${p}.${j}.2"${r[2] === 0 ? "" : " checked"}>` + (c.d[i][p].length > 1 ? X(`d.${i}.${p}`, j) : "<b></b>")).join("")) + ADD(`d.${i}.${p}`, "+ " + lab);
        h += c.d.map((k, i) => `<div class="cd-cat"><div class="cd-cath">${I(`d.${i}.0`)}${I(`d.${i}.1`, "color")}<label class="cd-c" title="Show the category name on the chart"><input type="checkbox" data-sh="d.${i}.4"${k[4] === 0 ? "" : " checked"}>Label</label>${c.d.length > 1 ? X("d", i) : ""}</div>` + sub(i, 2, "Sub") + sub(i, 3, "Sub-sub") + `<div class="cd-note" data-tot="${i}"></div></div>`).join("") + ADD("d", "+ Category");
      }
      if (c.t === "kpi") { c.d.forEach(r => { if (!r[2]) r[2] = c.c; });
        h += `<div class="cd-2">${L("Unit", "u", "text", "e.g. £")}</div>`
        + G("1fr 90px 46px 46px 30px", `<b>Bar</b><b>Value</b><b>Colour</b><b title="Fade this bar so the others stand out">Fade</b><b></b>` + c.d.map((r, i) => I(`d.${i}.0`) + I(`d.${i}.1`, "number") + I(`d.${i}.2`, "color") + I(`d.${i}.3`, "checkbox") + (c.d.length > 1 ? X("d", i) : "<b></b>")).join("")) + ADD("d", "+ Bar")
        + `<div class="cd-sub">KPIs (shaded on the grey bar behind each bar)</div>` + G("1fr 90px 30px", `<b>Label</b><b>Value</b><b></b>` + c.k.map((r, i) => I(`k.${i}.0`) + I(`k.${i}.1`, "number") + X("k", i)).join("")) + (c.k.length < 4 ? ADD("k", "+ KPI") : ""); }
      if (c.t === "gauge") h += `<div class="cd-2">${L("Value", "v", "number")}${L("Target", "max", "number")}</div><div class="cd-2">${L("Unit before", "u", "text", "e.g. £")}${L("Unit after", "s", "text", "e.g. %")}<label class="cd-c">Colour${I("c", "color")}</label></div>`
        + (c.b ? "" : (c.b = [[70, "#d20a11"], [80, "#f0b429"], [90, "#3fae49"]], ""))
        + `<label class="cd-c">${I("bv", "checkbox")}Change colour by how far along it is</label>`
        + G("1fr 90px 46px", `<b>From (% of target)</b><b></b><b>Colour</b>` + c.b.map((r, i) => `<b>Band ${i + 1}</b>` + I(`b.${i}.0`, "number") + I(`b.${i}.1`, "color")).join(""))
        + `<div class="cd-note">With this ticked, the gauge takes the colour of the highest band it has reached. Below the first band it uses the main colour.</div>`;
      if (c.t === "lines") h += `<label class="cd-c">${I("a", "checkbox")}Shade under the lines</label>`
        + G(`72px repeat(${c.s.length}, minmax(0,1fr)) 30px`, `<b>Month</b>` + c.s.map((r, j) => `<div class="cd-sh">${I(`s.${j}.0`)}<div class="cd-shr">${I(`s.${j}.1`, "color")}${c.s.length > 1 ? X("s", j) : ""}</div></div>`).join("") + "<b></b>"
          + c.x.map((m, i) => I(`x.${i}`) + c.s.map((r, j) => I(`s.${j}.2.${i}`, "number")).join("") + (c.x.length > 2 ? X("x", i) : "<b></b>")).join(""))
        + `<div class="cd-btns">${ADD("x", "+ Month")}${c.s.length < 5 ? ADD("s", "+ Series") : ""}</div>`;
      if (c.t === "radar") h += `<div class="cd-2">${L("Scale maximum", "max", "number")}<label class="cd-c">Colour${I("c", "color")}</label></div>`
        + G("1fr 90px 30px", `<b>Axis</b><b>Value</b><b></b>` + c.d.map((r, i) => I(`d.${i}.0`) + I(`d.${i}.1`, "number") + (c.d.length > 3 ? X("d", i) : "<b></b>")).join("")) + (c.d.length < 16 ? ADD("d", "+ Axis") : "");
      if (c.t === "track") { if (!c.m) c.m = c.g ? [[c.lg || "Target", c.g]] : [];
        h += `<label class="cd-c"><input type="checkbox" data-th${c.th === 0 ? "" : " checked"}>Show the title</label>`;
        h += G("1fr 150px 110px 30px", `<b>Marker</b><b>Date</b><b title="Text to show instead of the date">Show instead</b><b></b>` + `<b>Start</b>${I("s", "date")}<b></b><b></b><b>End</b>${I("e", "date")}<b></b><b></b>` + I("ln", "text", "Now") + I("n", "date") + "<b></b><b></b>"
          + c.m.map((r, i) => I(`m.${i}.0`, "text", "Target") + I(`m.${i}.1`, "date") + I(`m.${i}.2`, "text", "date") + X("m", i)).join("")) + ADD("m", "+ Marker")
          + `<div class="cd-note">Leave the Now date blank to use today. Markers are optional and alternate above and below the bar. Type in Show instead to replace a marker's date with your own text.</div>`
          + `<label class="cd-c"><input type="checkbox" data-se${c.se === 0 ? "" : " checked"}>Show the start and end dates</label>`
          + `<label class="cd-c"><input type="checkbox" data-el${c.el === 0 ? "" : " checked"}>Show the elapsed line (weeks and %)</label>`
          + `<div class="cd-2"><label class="cd-c">Elapsed${I("c", "color")}</label><label class="cd-c">To last target${I("ca", "color")}</label><label class="cd-c">Remaining${I("cb", "color")}</label><label class="cd-c">Marker dates and lines${I("lc", "color")}</label><label class="cd-c">Start and end${(c.sc || (c.sc = c.lc || "#1d1d1b"), I("sc", "color"))}</label></div>`; }
      body.innerHTML = `<div class="cd-plus">${h}</div>`;
      const tots = () => $$("[data-tot]", body).forEach(n => { const k = c.d[+n.dataset.tot], sm = a => Math.round(a.reduce((t, r) => t + (+r[1] || 0), 0) * 1e4) / 1e4, A = sm(k[2]), B = sm(k[3]);
        n.textContent = A === B ? `Sub ${A} = Sub-sub ${B}  ✓ totals match` : `Sub adds up to ${A} but Sub-sub adds up to ${B} - they should match`; n.style.color = A === B ? "#119b24" : "#d20a11"; });
      tots();
      $$("[data-sh]", body).forEach(i => i.onchange = () => setP(i.dataset.sh, i.checked ? 1 : 0));
      $$("[data-th]", body).forEach(i => i.onchange = () => { c.th = i.checked ? 1 : 0; });
      $$("[data-el]", body).forEach(i => i.onchange = () => { c.el = i.checked ? 1 : 0; });
      $$("[data-se]", body).forEach(i => i.onchange = () => { c.se = i.checked ? 1 : 0; });
      $$("[data-sv]", body).forEach(i => i.onchange = () => { c.sv = i.checked ? 1 : 0; });
      $$("[data-p]", body).forEach(i => i.oninput = i.onchange = () => { setP(i.dataset.p, i.type === "checkbox" ? (i.checked ? 1 : 0) : i.type === "number" ? (i.value === "" ? 0 : +i.value) : i.value); tots(); });
      $$("[data-del]", body).forEach(b => b.onclick = () => { const [a, i] = b.dataset.del.split(":");
        if (a === "x") { c.x.splice(+i, 1); c.s.forEach(r => r[2].splice(+i, 1)); } else getP(a).splice(+i, 1); draw(); });
      $$("[data-add]", body).forEach(b => b.onclick = () => { const a = b.dataset.add, L = getP(a).length;
        if (c.t === "track") c.m.push(["Target", c.e || "", ""]);
        if (c.t === "sun") { if (a === "d") c.d.push(["Category", PAL[L % PAL.length], [["Item", 1]], [["Item", 1]]]); else getP(a).push(["Item", 1]); }
        if (c.t === "pie") c.d.push(["Segment", 50, PAL[L % PAL.length]]);
        if (c.t === "pie2") c.d.push(["Segment", 25, 25, PAL[L % PAL.length]]);
        if (c.t === "kpi" && a === "d") c.d.push(["Bar " + (L + 1), +(c.d[L - 1] || [])[1] || 0, (c.d[L - 1] || [])[2] || c.c]);
        if (c.t === "kpi" && a === "k") c.k.push(["Target", 0]);
        if (c.t === "lines" && a === "x") { c.x.push(MON[(MON.indexOf(c.x[L - 1]) + 1) % 12] || "New"); c.s.forEach(r => r[2].push(+r[2][r[2].length - 1] || 0)); }
        if (c.t === "lines" && a === "s") c.s.push(["Series " + (L + 1), PAL[L % PAL.length], c.x.map(() => 0)]);
        if (c.t === "radar") c.d.push(["Axis " + (L + 1), (+c.max || 10) / 2]);
        draw(); });
    };
    draw(); box.hidden = false;
    const done = () => { box.hidden = true; $("#cdForm").onsubmit = null; $("#cdCancel").onclick = null; };
    $("#cdCancel").onclick = done;
    $("#cdForm").onsubmit = ev => { ev.preventDefault(); if (c.t === "gauge" && !(+c.max > 0)) c.max = 100; if (c.t === "radar" && !(+c.max > 0)) c.max = 10;
      remember(); el.dataset.chart = JSON.stringify(c); renderChart(el); done(); dcFlow(); toast("Chart updated"); };
  }

  /* Product List: paste "product = X, main use = Y, certification = Z" (one product per line) and it becomes rows.
     Keys are forgiving: product / name, main use / use / application, certification / cert / certificate; ":" works as well as "=".
     Several certifications can be split with ";". */
  function specPaste(b) {
    const box = $("#chartDlg"), body = $("#cdBody"); $("#cdTitle").textContent = "Paste product list";
    body.innerHTML = `<label>One product per line<textarea id="spIn" rows="8" style="font:13px Gilroy,Arial;border:1px solid #cfcfd5;border-radius:7px;padding:8px;resize:vertical" placeholder="product = Kingspan QuadCore, main use = Wall cladding, certification = LPCB LPS 1181; BBA"></textarea></label><label class="cd-c"><input type="checkbox" id="spRep" checked> Replace the rows already there</label><div class="cd-note" id="spMsg"></div>`;
    box.hidden = false; setTimeout(() => $("#spIn").focus(), 30);
    const key = k => /^(product|name|item)/i.test(k) ? "p" : /(use|application|purpose)/i.test(k) ? "u" : /cert/i.test(k) ? "c" : null;
    const done = () => { box.hidden = true; $("#cdForm").onsubmit = null; $("#cdCancel").onclick = null; };
    $("#cdCancel").onclick = done;
    $("#cdForm").onsubmit = ev => {
      ev.preventDefault();
      const rows = $("#spIn").value.split(/\n+/).map(line => { const r = {}; line.split(/,(?=\s*[A-Za-z ]+\s*[=:])/).forEach(part => { const m = part.match(/^\s*([^=:]+?)\s*[=:]\s*(.*?)\s*$/); if (m && key(m[1])) r[key(m[1])] = m[2]; }); return r; }).filter(r => r.p || r.u || r.c);
      if (!rows.length) { $("#spMsg").textContent = "Nothing recognised. Use lines like: product = X, main use = Y, certification = Z"; return; }
      remember(); const sp = $(".dc-spec", b); if ($("#spRep").checked) $$(".dc-sp-r", sp).forEach(r => r.remove());
      rows.forEach(r => sp.appendChild(htmlEl(TPL.specRow(chEsc(r.p || ""), chEsc(r.u || ""), chEsc(r.c || "")))));
      done(); dcFlow(); drawBar(); toast(`${rows.length} product${rows.length > 1 ? "s" : ""} added`);
    };
  }
  /* Signatures: the Date column opens the browser's date picker; the date shows as dd-Mmm-yy (e.g. 15-Oct-26). Clear the picker to empty the cell. */
  function pickDate(td) {
    let inp = $("#sgDate");
    if (!inp) { inp = document.createElement("input"); inp.type = "date"; inp.id = "sgDate"; inp.style.cssText = "position:fixed;opacity:0;pointer-events:none;width:1px;height:1px;border:0;padding:0"; document.body.appendChild(inp); }
    const r = td.getBoundingClientRect(); inp.style.left = r.left + "px"; inp.style.top = r.bottom + "px";
    inp.value = td.dataset.date || new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
    inp.onchange = () => { remember();
      if (!inp.value) { td.textContent = ""; delete td.dataset.date; return; }
      const d = dOf(inp.value); td.dataset.date = inp.value; td.textContent = `${String(d.getDate()).padStart(2, "0")}-${MON[d.getMonth()]}-${String(d.getFullYear()).slice(2)}`; };
    try { inp.showPicker(); } catch (e) { inp.style.pointerEvents = "auto"; inp.style.opacity = "1"; inp.focus(); inp.click(); }
  }
  async function editLink(lk) {
    const cert = lk.classList.contains("dc-sp-b") || lk.classList.contains("dc-sp-pw"), prod = lk.classList.contains("dc-sp-pw");
    const v = await ask(lk.classList.contains("dc-mimail") ? "Email address" : prod ? "Product link" : cert ? "Verified link" : "Link", (lk.dataset.href || "").replace(/^mailto:/i, ""), prod ? "Paste the product's web address. The product name becomes a clickable link in exports. Leave empty to remove it." : cert ? "Paste the web address of the certificate or compliance document (a PDF or web page). The button becomes a clickable link in exports. Leave empty to remove it." : lk.classList.contains("d-qr") ? "The QR code updates to match. Exported PDFs and HTML make it clickable." : "Exported PDFs and HTML make this clickable.", "Update");
    if (v == null) return;
    if (cert && !v.trim()) { remember(); delete lk.dataset.href; return toast("Link removed"); }
    const mail = lk.classList.contains("dc-mimail"), href = mail ? (/^mailto:/i.test(v.trim()) ? v.trim() : "mailto:" + v.trim()) : /^[a-z]+:/i.test(v) ? v : "https://" + v; remember();
    $$(`[data-link="${lk.dataset.link}"]`, doc).forEach(x => {
      x.dataset.href = href; if (x.classList.contains("d-qr")) renderQR(x); if (x.classList.contains("dc-mimail")) x.dataset.manual = "1";
      const t = x.classList.contains("dc-uaddr") ? x : $(".dc-uaddr", x); if (t) t.textContent = href.replace(/^https?:\/\//, "").replace(/\/$/, "");
    });
    toast("Link updated");
  }

  /* ------------------------------------------------------------------ documentation: flowing pages + blocks */
  const KEEP = new Set(["section", "heading", "sub"]);              // never left at the bottom of a page
  const dcPages = () => $$(".d-spread.dc", doc);
  const dcBlocks = () => $$(".dc-flow > .dc-blk", doc);
  const UP = '<svg viewBox="0 0 24 24"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
  function dcNumber() {
    // section numbers: 01, 02... ; inside a numbered chapter they become chapter.section (01.1, 01.2, 02.1...)
    { let ch = 0, chNum = false, inCh = 0, plain = 0; const pad = n => String(n).padStart(2, "0");
      $$('.d-spread.dc', doc).forEach(p => {
        if (p.classList.contains("dc-chap")) { ch++; chNum = !("nonum" in p.dataset); inCh = 0; return; }
        $$(".dc-num", p).forEach(e => { e.textContent = ch && chNum ? `${pad(ch)}.${++inCh}` : pad(++plain); });
      }); }
    const first = dcPages()[0]; if (first) first.id = "dc-top";
    $$(".dc-flowc", doc).forEach(s => s.style.setProperty("--cols", Math.min(+s.dataset.per || 4, s.children.length)));
    $$(".dc-steps", doc).forEach(s => { const per = Math.min(+s.dataset.per || 5, s.children.length); s.style.setProperty("--cols", per); [...s.children].forEach((st, i) => { st.toggleAttribute("data-er", (i + 1) % per === 0 && i < s.children.length - 1); st.toggleAttribute("data-sr", i % per === 0 && i > 0); }); s.style.counterReset = `dcs ${(+s.dataset.start || 1) - 1}`; $$(".dc-step", s).forEach(st => { if (!$(".dc-tick", st)) st.insertAdjacentHTML("afterbegin", '<i class="dc-tick" title="Mark this step complete"></i>'); }); });
    // intermediate footers: the document reference (mirrors page 1) + a back-to-top link
    revPlace();
    $$(".dc-rvref", doc).forEach((r, i) => { if (i) delete r.dataset.sync; else r.dataset.sync = "ref"; });   // the newest revision's reference feeds the page footers
    const ref = $(".dc-rvref", doc);
    $$(".dc-mid .dc-foot", doc).forEach(f => {
      const t = $(".dc-ftitle", f); if (t) { t.dataset.syncOf = "ref"; if (ref) t.innerHTML = ref.innerHTML; }
      if (!$(".dc-up", f)) f.insertAdjacentHTML("beforeend", `<a class="dc-up" href="#dc-top" target="_self" title="Back to the start">${UP}</a>`);
    });
    dcChapters(); dcToc(); listCont(); alertFoot(); footTag();
    $$("svg.dc-dur-i", doc).forEach(v => { if (!$("rect", v)) v.innerHTML = '<rect x="7" y="10" width="34" height="31" rx="4"/><path d="M7 20h34M16 5v9M32 5v9"/>'; });
    // the end page is mandatory: older saves without one get it back
    if (dcPages().length && TPL.endPage !== false && !$(".dc-last", doc) && dcPages()[0].parentNode.classList.contains("spread-wrap")) { dcNewPage("last"); layout(); }
    const ps = dcPages(); ps.forEach((sp, i) => $$(".dc-pn", sp).forEach(e => { e.textContent = `Page ${i + 1} of ${ps.length}`; }));
    if (ps.length) { setOrient(state.orient); dcControls(); }
  }
  /* chapter pages: numbered 01, 02...; each lists the sections and headings that follow it, up to the next chapter page */
  function dcChapters() {
    const ps = dcPages(); let n = 0, s = 0, h = 0, cur = null; const lists = new Map();
    ps.forEach((p, pi) => {
      if (p.classList.contains("dc-chap")) {
        if (!$(".dc-cbox", p)) {                        // chapter page from an older version: move any content on, add / wrap the layout
          const f = $(".dc-flow", p), nx = ps.slice(pi + 1).map(x => $(".dc-flow", x)).find(Boolean);
          if (f) { if (nx) while (f.lastElementChild) nx.insertBefore(f.lastElementChild, nx.firstChild); f.remove(); }
          const box = $(".dc-cbox", htmlEl(TPL.page("chap"))), oh = $(".dc-chead", p);
          if (oh) { box.innerHTML = ""; box.appendChild(oh); box.appendChild($(".dc-clist", p) || htmlEl('<div class="dc-clist"></div>')); }
          p.appendChild(box);
        }
        p.style.setProperty("--cy", (+p.dataset.y || 66) + "mm");
        n++; cur = p; const hd = $(".dc-chead", p); hd.id = "dcc-" + n; $(".dc-cnum", p).textContent = String(n).padStart(2, "0"); lists.set(p, []); return;
      }
      $$('.dc-blk[data-blk="section"], .dc-blk[data-blk="heading"]', p).forEach(b => {
        const sec = b.dataset.blk === "section"; b.id = sec ? "dcs-" + (++s) : "dch-" + (++h);
        if (cur) lists.get(cur).push({ sec, id: b.id, n: sec ? ($(".dc-num", b) || {}).textContent || "" : "", txt: ($(sec ? ".dc-stitle" : ".dc-h", b) || b).textContent.replace(/\s+/g, " ").trim(), pg: pi + 1 });
      });
    });
    lists.forEach((items, p) => { $(".dc-clist", p).innerHTML = items.length
      ? items.map(i => `<a class="dc-ce${i.sec ? "" : " l2"}" href="#${i.id}" target="_self">${i.sec ? `<span class="n">${i.n}</span>` : ""}<span class="t">${chEsc(i.txt)}</span><span class="p">${i.pg}</span></a>`).join("")
      : `<div class="dc-cempty">The sections and headings that follow this page are listed here.</div>`; });
  }
  /* contents: rebuilt from the section titles (and headings when data-lv="2"); each entry links to its block */
  function dcToc() {
    const tocs = $$(".dc-toc", doc); if (!tocs.length) return;
    const ps = dcPages(), pageOf = el => ps.indexOf(el.closest(".d-spread")) + 1;
    let s = 0, h = 0; const items = [];
    $$('.dc-chead, .dc-blk[data-blk="section"], .dc-blk[data-blk="heading"]', doc).forEach(b => {
      if (b.classList.contains("dc-chead")) { items.push({ ch: true, sec: true, id: b.id, n: b.closest("[data-nonum]") ? "" : $(".dc-cnum", b).textContent, txt: $(".dc-ctitle", b).textContent.replace(/\s+/g, " ").trim(), pg: pageOf(b) }); return; }
      const sec = b.dataset.blk === "section"; b.id = sec ? "dcs-" + (++s) : "dch-" + (++h);
      const txt = ($(sec ? ".dc-stitle" : ".dc-h", b) || b).textContent.replace(/\s+/g, " ").trim();
      items.push({ sec, id: b.id, n: sec ? ($(".dc-num", b) || {}).textContent || "" : "", txt, pg: pageOf(b) });
    });
    tocs.forEach(t => {
      const lv2 = t.dataset.lv === "2", list = items.filter(i => i.sec || lv2);
      $(".dc-tlist", t).innerHTML = list.length ? list.map(i => `<a class="dc-te${i.ch ? " ch" : i.sec ? "" : " l2"}" href="#${i.id}" target="_self"><span class="n">${i.n}</span><span class="t">${chEsc(i.txt)}</span><span class="d"></span><span class="p">${i.pg}</span></a>`).join("")
        : `<div class="dc-tempty">Add a Section title and it will be listed here.</div>`;
    });
  }
  /* Alert: every page carries the category banner of the front page */
  function alertFoot() {
    if (!TPL.cats) return; const f = $(".dc-first .gf", doc); if (!f) return;
    if (TPL.footFromSub) { const hs = $(".dc-first .gh-sub", doc), ft = $(".gf-t", f), tx = hs ? hs.textContent.trim().toUpperCase() : ""; if (ft && tx && ft.textContent !== tx) ft.textContent = tx; }   // Training: the banner repeats the line above the title
    $$(".gf", doc).forEach(g => { if (g === f) return; g.dataset.cat = f.dataset.cat; const t = $(".gf-t", g); if (t) t.textContent = $(".gf-t", f).textContent; });
    $$(".gf", doc).forEach(g => { const sp = g.closest(".d-spread"); if (sp) sp.dataset.cat = f.dataset.cat; });   // headers take the same category colour
  }
  /* bottom-left footer tag on every footer banner (Alert, Training, Blank Page): SHARED LEARNING | QUALITY, shrunk to stay clear of the banner */
  const CATL = { safety: "Safety", quality: "Quality", environment: "Environment", delivery: "Delivery" };
  function footTag() {
    if (bl()) { const f = $(".dc-first", doc), hs = f && f.dataset.sub === "1" && $(":scope > .gh .gh-sub", f), tx = hs && hs.textContent.trim() ? hs.textContent.trim().toUpperCase() : "";   // Blank Page: the banner repeats the minor title, else the category
      $$(".gf", doc).forEach(g => { const t = $(".gf-t", g); if (!t) return; const v = tx || (CATL[g.dataset.cat] || "").toUpperCase(); if (t.textContent !== v) t.textContent = v; }); }
    $$(".gf-sl span", doc).forEach(s => { const g = s.closest(".gf"), cl = g && CATL[g.dataset.cat] || ""; const tx = "Shared learning" + (cl ? " | " + cl : ""); if (s.textContent !== tx) s.textContent = tx;
      s.style.fontSize = ""; const b = g && $(".gf-3", g); if (!b || !s.offsetWidth) return;   // shrink to sit clear of the banner (A4 portrait)
      const room = b.getBoundingClientRect().left - s.getBoundingClientRect().left - b.getBoundingClientRect().height * .4, w = s.getBoundingClientRect().width;
      if (w > room && room > 0) s.style.fontSize = (parseFloat(getComputedStyle(s).fontSize) * room / w).toFixed(2) + "px"; });
  }
  /* add a page: kind "mid" (intermediate) or "last" (end page); inserted before `before` (a .d-spread) or at the end */
  function dcNewPage(kind, before) {
    const sp = htmlEl(TPL.page(kind)); sp.dataset.style = state.style;
    if (pp()) { const ps = dcPages(), at = before ? ps.indexOf(before) : ps.length, ref = ps[at - 1] || ps[0]; if (ref && ref.dataset.or) sp.dataset.or = ref.dataset.or; }   // a new page takes the orientation of the page before it
    const w = document.createElement("div"); w.className = "spread-wrap"; w.appendChild(sp);
    if (before) doc.insertBefore(w, before.parentNode); else doc.appendChild(w);
    $$(".d-logo", sp).forEach(i => { i.src = window.LOGO_DATA[i.dataset.logo || "colour"]; });
    $$("[data-sync-of]", sp).forEach(x => { const src = $(`[data-sync="${x.dataset.syncOf}"]`, doc); if (src) x.innerHTML = src.innerHTML; });
    paperApply(); return sp;
  }
  /* Blank Page > Page Setup: header (with or without the minor title), footer (with or without the info tag), logo, category colour
     and the GMI end page; applied to every page at once. Drawn in the right-hand panel (ui.js) and in the Page Setup dialog. */
  const CATC = { safety: "#067ed1", quality: "#4b4b50", environment: "#2e9b3b", delivery: "#0b0b0b" };
  const psBoxes = new Set();
  const pageCfg = () => bl() ? Object.assign(TPL.cfgOf(), { end: !!$(".dc-last", doc) }) : null;
  function psSet(patch) {
    if (!bl()) return; remember(); const { end, ...rest } = patch, cfg = Object.assign(TPL.cfgOf(), rest);
    $$(".d-spread.dc", doc).forEach(sp => TPL.setup(sp, cfg));
    if (end !== undefined) { const last = $(".dc-last", doc);
      if (end && !last) dcNewPage("last");
      else if (!end && last) { const ps = dcPages(), prev = ps[ps.indexOf(last) - 1], f = $(".dc-flow", last), pf = prev && $(".dc-flow", prev);
        if (f && pf) [...f.children].forEach(x => pf.appendChild(x));          // anything on the end page moves back onto the page before it
        last.parentNode.remove(); } }
    decorate(); layout(); dcNumber(); dcFlow(); psBoxes.forEach(psDraw);
  }
  function psDraw(body) {
    if (!body.isConnected) { psBoxes.delete(body); return; } const c = pageCfg(); if (!c) { body.innerHTML = ""; return; }
    const row = (k, lab, on, dis, sub) => `<label class="cd-c ps-r${sub ? " ps-sub" : ""}${dis ? " dis" : ""}"><input type="checkbox" data-ps="${k}"${on ? " checked" : ""}${dis ? " disabled" : ""}> ${lab}</label>`;
    body.innerHTML = row("hdr", "Header", c.hdr) + row("sub", "Minor title above the main title", c.sub, !c.hdr, 1) + row("logo", "Logo", c.logo, !c.hdr, 1)
      + row("ftr", "Footer banner", c.ftr) + row("info", "Info tag (Shared learning | category)", c.info, !c.ftr, 1)
      + row("end", "GMI end page (contact details)", c.end)
      + `<div class="cd-sub">Category colour</div><div class="ps-cats">${[["safety", "Safety"], ["quality", "Quality"], ["environment", "Environment"], ["delivery", "Delivery"]].map(([k, l]) =>
        `<button type="button" class="mini${c.cat === k ? " on" : ""}" data-cat="${k}"><i style="background:${CATC[k]}"></i>${l}</button>`).join("")}</div>`;
    $$("[data-ps]", body).forEach(i => i.onchange = () => psSet({ [i.dataset.ps]: i.checked }));
    $$("[data-cat]", body).forEach(b => b.onclick = () => psSet({ cat: b.dataset.cat }));
  }
  function pageSetupInto(body) { psBoxes.add(body); psDraw(body); }
  function pageSetup() {
    if (!bl()) return; const box = $("#psDlg"); pageSetupInto($("#psBody")); box.hidden = false; $("#psClose").onclick = () => { box.hidden = true; };
  }
  /* Pages are added and removed by the author and never disappear on their own.
     dcFlow only pushes forward: text after a page break, and anything that no longer fits, moves to the top of the
     next page (headings travel with what follows). If there is no next page the overflow is flagged instead. */
  let dcBusy = false;
  /* Process Cards: the card text always fits. Arrow labels: at most two rows, as big as they can be, and the same size on every stage of a block
     (set by the label that needs the smallest size); every label lines up with the top of its number circle.
     The bold line is limited to two lines and shrinks to fit; long body text steps down from 10pt to no smaller than 9pt (cards grow with their text, so nothing is ever cut off or overlapped) */
  function kOf(e) { return parseFloat(getComputedStyle(e).getPropertyValue("--k")) || 1; }
  function flFit(fs) {
    const fls = $$(".dc-fl", fs).filter(f => f.offsetParent); fs.removeAttribute("data-top");
    fls.forEach(f => { f.style.removeProperty("--fs"); f.style.removeProperty("margin-top"); f.removeAttribute("data-clamp"); });
    if (!fls.length) return;
    const lh = f => parseFloat(getComputedStyle(f).lineHeight), bad = f => f.scrollHeight > 2 * lh(f) + 2 || f.scrollWidth > f.clientWidth + 1;
    const set = (f, pt) => f.style.setProperty("--fs", pt + "pt");
    const best = f => { const hi = 18 * kOf(f); set(f, hi); if (!bad(f)) return hi;          // largest size (to a quarter point) that fits in two rows
      let lo = 5, up = hi; set(f, lo); if (bad(f)) return lo;
      while (up - lo > .25) { const m = (lo + up) / 2; set(f, m); if (bad(f)) up = m; else lo = m; } return Math.floor(lo * 4) / 4; };
    const pt = Math.min(...fls.map(best));
    fls.forEach(f => { set(f, pt); if (bad(f)) f.setAttribute("data-clamp", "1"); });
    fs.setAttribute("data-top", "1");
    for (let pass = 0; pass < 2; pass++) fls.forEach(f => {                                  // top of the capitals level with the top of the circle
      const fh = f.closest(".dc-fh"), n = $(".dc-fn", fh); if (!n || !n.offsetParent) return;
      const sc = fh.getBoundingClientRect().height / fh.offsetHeight || 1, cs = getComputedStyle(f), px = parseFloat(cs.fontSize);
      const c = (flFit.cv || (flFit.cv = document.createElement("canvas"))).getContext("2d"); c.font = `${cs.fontWeight} ${px}px ${cs.fontFamily}`;
      const t = c.measureText("H"), cap = t.fontBoundingBoxAscent - t.actualBoundingBoxAscent + (lh(f) - t.fontBoundingBoxAscent - t.fontBoundingBoxDescent) / 2;
      const cur = parseFloat(f.style.marginTop) || 0, d = (n.getBoundingClientRect().top - f.getBoundingClientRect().top) / sc - cap;
      f.style.marginTop = Math.max(0, cur + d) + "px"; });
  }
  function fcFit(fc) {
    const bt = $(".dc-fbt", fc), bp = $(".dc-fbp", fc);
    if (bt && bt.offsetParent) { bt.style.removeProperty("--fs"); bt.removeAttribute("data-clamp"); const k = kOf(bt), lim = () => 2 * parseFloat(getComputedStyle(bt).lineHeight) + 2;
      for (let pt = 15.6 * k; pt >= 10 && bt.scrollHeight > lim(); pt -= .5) bt.style.setProperty("--fs", pt + "pt");
      if (bt.scrollHeight > lim()) bt.setAttribute("data-clamp", "1"); }
    if (bp && bp.offsetParent) { bp.style.removeProperty("--fs"); const k = kOf(bp);
      for (const pt of [12, 11, 10, 9]) { if (bp.offsetHeight <= 55 * 96 / 25.4) break; bp.style.setProperty("--fs", pt * k + "pt"); } }
  }
  function dcFlow() {
    $$(".dc-flowc", doc).forEach(flFit); $$(".dc-fc", doc).forEach(fcFit);
    $$(".dc-glance", doc).forEach(glFit);
    if (!isDoc() || dcBusy || !TPL.page) return; dcBusy = true;
    const s = window.getSelection(), r = s && s.rangeCount ? s.getRangeAt(0) : null;
    const keep = r && doc.contains(r.startContainer) ? [r.startContainer, r.startOffset, r.endContainer, r.endOffset] : null;
    const pages = dcPages().filter(p => $(".dc-flow", p)), flowOf = sp => $(".dc-flow", sp);
    revPlace(); dcToc();                                            // so the contents block has its real height before measuring
    // push forward; when the last page overflows, add a page (before the end page, which keeps the tail)
    for (let i = 0, guard = 0; i < pages.length && guard < 60; i++) {
      let f = flowOf(pages[i]), out = [];
      const br = [...f.children].findIndex(b => b.dataset.blk === "pagebreak");
      if (br > -1 && br < f.children.length - 1) while (f.children.length > br + 1) { const x = f.lastElementChild; x.remove(); out.unshift(x); }
      while (over(f) && f.children.length > 1) {
        const x = f.lastElementChild; x.remove(); out.unshift(x);
        while (f.children.length > 1 && KEEP.has(f.lastElementChild.dataset.blk)) { const h = f.lastElementChild; h.remove(); out.unshift(h); }
      }
      if (!out.length) continue;
      const all = dcPages(), nxA = all[all.indexOf(pages[i]) + 1];
      if (nxA && nxA.classList.contains("dc-chap")) pages.splice(i + 1, 0, dcNewPage("mid", nxA));   // overflow stays in its chapter
      if (i === pages.length - 1) {                       // nowhere to go: make a page
        guard++;
        if (pages[i].classList.contains("dc-last")) {      // end page: a new page takes its content, the end page then carries on
          const mid = dcNewPage("mid", pages[i]), mf = flowOf(mid); while (f.firstChild) mf.appendChild(f.firstChild);
          out.forEach(x => f.appendChild(x)); pages.splice(i, 0, mid); i--; continue;
        }
        const np = dcNewPage("mid", null); pages.push(np);
      }
      const nx = flowOf(pages[i + 1]); for (let k = out.length - 1; k >= 0; k--) nx.insertBefore(out[k], nx.firstChild);
    }
    dcNumber(); layout(); markOverflow();
    if (keep && doc.contains(keep[0]) && doc.contains(keep[2])) { try { s.setBaseAndExtent(...keep); } catch (e) {} }
    dcBusy = false; if (curBlk) drawBar(); wordCount();
  }
  let curPage = null;                                  // last page clicked: where new pages / blocks go
  function dcAddPage(kind) {
    remember();
    const ps = dcPages(), end = ps.find(p => p.classList.contains("dc-last"));
    if (kind === "last") { if (end) return toast("This document already has an end page"); curPage = dcNewPage("last"); }
    else {
      const at = curPage && doc.contains(curPage) && !curPage.classList.contains("dc-last") ? curPage : null;
      const before = at ? (ps[ps.indexOf(at) + 1] || null) : end || null;
      curPage = dcNewPage(kind === "chap" ? "chap" : "mid", before);
    }
    dcNumber(); layout(); curPage.parentNode.scrollIntoView({ block: "nearest", behavior: "smooth" });
    toast(kind === "last" ? "End page added" : kind === "chap" ? "Chapter page added" : "Page added");
  }
  async function dcRemovePage(sp) {
    const n = $$(".dc-blk", sp).length, no = dcPages().indexOf(sp) + 1;
    if (n && await choose(`Remove page ${no}?`, `It has ${n} element${n > 1 ? "s" : ""} on it, which will be deleted too.`, ["Cancel", "Remove page"]) !== 1) return;
    remember(); if (curBlk && sp.contains(curBlk)) selectBlk(null); if (curPage === sp) curPage = null;
    sp.parentNode.remove(); dcNumber(); layout(); markOverflow(); toast(`Page ${no} removed`);
  }
  async function dcResetPage(sp) {
    const n = $$(".dc-blk", sp).length, no = dcPages().indexOf(sp) + 1;
    if (!n) return toast(`Page ${no} is already blank`);
    if (await choose(`Reset page ${no}?`, `This clears the ${n} element${n > 1 ? "s" : ""} on it. Undo brings them back.`, ["Cancel", "Reset page"]) !== 1) return;
    remember(); if (curBlk && sp.contains(curBlk)) selectBlk(null);
    $$(".dc-flow", sp).forEach(f => f.innerHTML = ""); dcNumber(); layout(); markOverflow(); toast(`Page ${no} reset`);
  }
  /* move a content / chapter page; never above the front page or below the end page */
  function dcMovePage(sp, d) {
    const ps = dcPages(), i = ps.indexOf(sp), j = i + d; if (j < 1 || !ps[j] || ps[j].classList.contains("dc-last")) return;
    remember(); const w = sp.parentNode, o = ps[j].parentNode; if (d < 0) o.before(w); else o.after(w);
    curPage = sp; dcNumber(); layout(); dcFlow(); w.scrollIntoView({ block: "nearest", behavior: "smooth" }); toast(`Moved to page ${j + 1}`);
  }
  /* the page last clicked (where new elements go) gets a subtle outline */
  function markCur() { $$(".spread-wrap.cur", doc).forEach(w => w.classList.remove("cur")); if (curPage && doc.contains(curPage) && curPage.parentNode.classList.contains("spread-wrap")) curPage.parentNode.classList.add("cur"); }
  /* small label + reset / remove buttons above each page (app only: sits in the wrapper, never in the document) */
  function dcControls() {
    markCur();
    dcPages().forEach((sp, i) => {
      const w = sp.parentNode; if (!w.classList.contains("spread-wrap")) return; let c = $(".pgctl", w);
      if (!c) { c = document.createElement("div"); c.className = "pgctl"; w.appendChild(c); }
      const k = sp.classList.contains("dc-first") ? ["front", "Front page"] : sp.classList.contains("dc-last") ? ["end", "End page"] : sp.classList.contains("dc-chap") ? ["chap", "Chapter page"] : ["mid", "Content page"];
      c.innerHTML = `<span><b class="pgk ${k[0]}">${k[1]}</b> Page ${i + 1}</span>`;
      const g = document.createElement("div"); g.className = "pgbtns"; c.appendChild(g);
      const ps = dcPages(), mov = k[0] === "mid" || k[0] === "chap", mk = (l, t, fn, off) => { const x = document.createElement("button"); x.textContent = l; x.title = t; x.disabled = off; x.onclick = fn; g.appendChild(x); };
      if (pp()) {                                          // portrait / landscape for this page only (paper size is for the whole document: Export)
        const l = sp.dataset.or === "l", sw = (lab, t, on, v) => { const x = document.createElement("button"); x.innerHTML = lab; x.title = t; if (on) x.className = "on";
          x.onclick = () => { if (sp.dataset.or === v) return; remember(); sp.dataset.or = v; setOrient(state.orient); dcNumber(); }; g.appendChild(x); };
        sw('<svg class="pgor" viewBox="0 0 20 20"><rect x="6" y="3" width="8" height="14" rx="1.2"/></svg>', `This page: ${state.paper.toUpperCase()} portrait`, !l, "p");
        sw('<svg class="pgor" viewBox="0 0 20 20"><rect x="3" y="6" width="14" height="8" rx="1.2"/></svg>', `This page: ${state.paper.toUpperCase()} landscape`, l, "l");
      }
      if (mov) { mk("↑", "Move this page up", () => dcMovePage(sp, -1), i <= 1); mk("↓", "Move this page down", () => dcMovePage(sp, 1), !ps[i + 1] || ps[i + 1].classList.contains("dc-last")); }
      const op = $(".pgopts", w); if (op) op.remove();
      if (k[0] === "front" && TPL.cats && $(".gf", sp)) {       // Alert: footer banner category (app only, above the page)
        const gf = $(".gf", sp), lab = document.createElement("span"); lab.className = "pglab"; lab.textContent = "Footer:"; g.appendChild(lab);
        TPL.cats.forEach(([v, l]) => { const x = document.createElement("button"); x.textContent = l; x.title = "Footer banner: " + l; if (gf.dataset.cat === v) x.className = "on";
          x.onclick = () => { remember(); gf.dataset.cat = v; $(".gf-t", gf).textContent = l.toUpperCase(); dcNumber(); }; g.appendChild(x); });
      }
      if (k[0] === "chap") {                              // chapter options (app only): title position, headings, number
        const o = document.createElement("div"); o.className = "pgopts"; w.appendChild(o);
        const y = +sp.dataset.y || 66, opt = (l, t, fn, on, off) => { const x = document.createElement("button"); x.textContent = l; x.title = t; if (on) x.className = "on"; x.disabled = !!off; x.onclick = () => { remember(); fn(); dcNumber(); }; o.appendChild(x); };
        opt("▲ Title", "Move the chapter title up", () => { sp.dataset.y = Math.max(30, y - 12); }, false, y <= 30);
        opt("▼ Title", "Move the chapter title down", () => { sp.dataset.y = Math.min(162, y + 12); }, false, y >= 162);
        opt("Headings", "Show headings under each section (off: sections only)", () => { if (sp.dataset.lv === "1") delete sp.dataset.lv; else sp.dataset.lv = "1"; }, sp.dataset.lv !== "1");
        opt("Number", "Show the chapter number", () => { if ("nonum" in sp.dataset) delete sp.dataset.nonum; else sp.dataset.nonum = ""; }, !("nonum" in sp.dataset));
      }
      if (k[0] === "front" && TPL.identifier !== false) {          // the revision record is optional
        const first = $(".dc-first", doc), on = !first.dataset.norev;
        mk(on ? "Hide revision record" : "Show revision record", on ? "Remove the revision record from the front page" : "Put the revision record back on the front page", () => {
          remember(); if (on) first.dataset.norev = "1"; else delete first.dataset.norev;
          $$(".dc-flow", doc).forEach(f => f.style.removeProperty("height")); revFix(); revPlace(); dcNumber(); dcFlow(); }, false);
      }
      if ($(".dc-revs", sp)) { mk("+ Revision", "Add a new revision at the top of the revision record", revAdd, false); if ($$(".dc-revs .dc-rv", sp).length > 1) mk("− Revision", "Remove the newest revision", revDel, false); }
      if (k[0] !== "chap") { const r = document.createElement("button"); r.textContent = "Reset"; r.title = "Clear every element from this page"; r.onclick = () => dcResetPage(sp); g.appendChild(r); }
      if (i > 0 && k[0] !== "end") { const b = document.createElement("button"); b.textContent = "Remove"; b.title = "Remove this page"; b.onclick = () => dcRemovePage(sp); g.appendChild(b); }
    });
  }

  /* Elements panel */
  function dcPanel() {
    const on = isDoc(); $("#dcEls").hidden = $("#dcPages").hidden = !on; doc.classList.toggle("dc-mode", on);
    $("#dcPageSetup").disabled = !bl(); const want = on && !bl() && (pp() ? state.paper === "a4" && dcPages().every(p => (p.dataset.or || (state.orient === "landscape" ? "l" : "p")) !== "l") : !a3() && !ls()); paperLast = undefined;   // wide pages (A3 Training) open one per row so they fill the space
    if (want !== doc.classList.contains("multi")) setView(want ? "multi" : "single");
    if (!on) { selectBlk(null); return; }
    const box = $("#dcElBtns"); if (box.childElementCount && box.dataset.tpl === TPL.file) return; box.innerHTML = ""; box.dataset.tpl = TPL.file;   // rebuilt when the document type changes (Alert has extra elements)
    const GI = { Text: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>', "Lists and links": '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1.2"/><circle cx="4.5" cy="12" r="1.2"/><circle cx="4.5" cy="18" r="1.2"/>',
      Images: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="m4 18 5-5 4 4 3-3 4 4"/>', Components: '<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/>',
      Charts: '<path d="M4 20V10M10 20V4M16 20v-7M21 20H3"/>' };
    (TPL.blockGroups || [["", TPL.blockOrder]]).forEach(([g, keys], gi) => {
      if (g && gi) box.appendChild(Object.assign(document.createElement("hr"), { className: "els-hr" }));
      if (g) { const h = document.createElement("div"); h.className = "els-h"; h.innerHTML = (GI[g] ? `<svg viewBox="0 0 24 24">${GI[g]}</svg>` : "") + chEsc(g); box.appendChild(h); }
      keys.forEach(e => { const [k, lab, tip, soon] = Array.isArray(e) ? e : [e], b = document.createElement("button"); b.className = "mini el"; b.textContent = lab || TPL.blocks[k].label; b.title = tip || "";
        if (soon) b.disabled = true; else b.onclick = () => dcInsert(k); box.appendChild(b); });
    });
    $("#dcGuides").onchange = e => doc.classList.toggle("noguides", !e.target.checked);
    $("#dcAddMid").onclick = () => dcAddPage("mid"); $("#dcAddChap").onclick = () => dcAddPage("chap"); $("#dcAddToc").onclick = () => dcInsert("toc"); $("#dcAddSect").onclick = () => dcInsert("section"); $("#dcAddBreak").onclick = () => dcInsert("pagebreak"); $("#dcPageSetup").onclick = pageSetup;
  }
  let dcUid = 0; const newUid = () => Date.now().toString(36) + (++dcUid);
  const htmlEl = h => { const t = document.createElement("div"); t.innerHTML = h.trim(); return t.firstElementChild; };
  function dcInsert(k) {
    remember();
    const el = htmlEl(TPL.blocks[k].html(newUid()));
    if (curBlk && doc.contains(curBlk)) curBlk.after(el);
    else if (curPage && doc.contains(curPage) && $(".dc-flow", curPage)) $(".dc-flow", curPage).appendChild(el);
    else if (curPage && doc.contains(curPage)) { const ps = dcPages(), nf = $(".dc-flow", ps.slice(ps.indexOf(curPage) + 1).find(p => $(".dc-flow", p))); nf.insertBefore(el, nf.firstChild); }   // chapter page: starts the next page
    else { const bl = dcBlocks(); if (bl.length) bl[bl.length - 1].after(el); else $(".dc-flow", doc).appendChild(el); }   // nothing clicked: after the last element, or on the first page
    $$(".d-fig[data-slot]", el).forEach(f => setSlot(f.dataset.slot, "ph"));
    $$("[data-chart]", el).forEach(renderChart); $$(".d-qr", el).forEach(renderQR); mapFix();
    dcFlow(); selectBlk(el); el.scrollIntoView({ block: "center", behavior: "smooth" });
    const ed = $(".ed", el); if (ed) setTimeout(() => { ed.focus(); const rg = document.createRange(); rg.selectNodeContents(ed); const s = getSelection(); s.removeAllRanges(); s.addRange(rg); }, 60);
    toast(TPL.blocks[k].label + " added");
    setTimeout(protect, 400);
  }

  /* block toolbar (floats over the selected block; never part of the document) */
  const bar = $("#blkBar");
  /* image border (right pane): shown while an image element is selected */
  function borderPane() {
    const b = curBlk, figs = b && /^(media|imagefw|image[234]|map|moreinfo)$/.test(b.dataset.blk) ? $$(".dc-img", b) : [];
    $("#imgBorder").hidden = !figs.length; if (!figs.length) return;
    const bc = figs[0].dataset.bc || "", bw = figs[0].dataset.bw || "2";
    $$("#ibCol [data-c]").forEach(x => x.classList.toggle("on", x.dataset.c === bc));
    $$("#ibW [data-w]").forEach(x => { x.classList.toggle("on", !!bc && x.dataset.w === bw); x.disabled = !bc; });
  }
  $$("#ibCol [data-c]").forEach(x => x.onclick = () => { if (!curBlk) return; remember(); const c = x.dataset.c;
    $$(".dc-img", curBlk).forEach(f => { if (c) { f.dataset.bc = c; if (!f.dataset.bw) f.dataset.bw = "2"; } else { delete f.dataset.bc; delete f.dataset.bw; } }); borderPane(); });
  $$("#ibW [data-w]").forEach(x => x.onclick = () => { if (!curBlk) return; remember(); $$(".dc-img", curBlk).forEach(f => { if (f.dataset.bc) f.dataset.bw = x.dataset.w; }); borderPane(); });
  function selectBlk(b) {
    $$(".dc-blk.sel", doc).forEach(x => x.classList.remove("sel")); if (curFig && (!b || !b.contains(curFig))) { curFig.classList.remove("sel"); curFig = null; } if (curStep && (!b || !b.contains(curStep))) { curStep.classList.remove("on"); curStep = null; } curBlk = b || null;
    if (!curBlk) { bar.hidden = true; drawPane(null); borderPane(); colHandles(); return; }
    curBlk.classList.add("sel"); drawBar(); borderPane();
  }
  /* drag a picture inside its frame (documentation image blocks) to choose what shows: no more guessing with the focus dots */
  doc.addEventListener("dragstart", e => { if (e.target.closest && e.target.closest(".dc-blk .d-fig")) e.preventDefault(); });
  doc.addEventListener("mousedown", e => { const f = e.target.closest && e.target.closest(".dc-blk .d-fig"); if (!f || f.dataset.mapslot || e.button || f.dataset.fit === "fit") return; const im = $("img", f); if (!im || !im.naturalWidth) return;
    const r = f.getBoundingClientRect(), z = +f.dataset.z || 1, sc = Math.max(r.width / im.naturalWidth, r.height / im.naturalHeight) * z, sx = im.naturalWidth * sc - r.width, sy = im.naturalHeight * sc - r.height;
    const cur = (im.style.objectPosition || "50% 50%").split(" ").map(parseFloat); let x0 = e.clientX, y0 = e.clientY, moved = false;
    const mv = ev => { const dx = ev.clientX - x0, dy = ev.clientY - y0; if (!moved && Math.abs(dx) + Math.abs(dy) < 4) return; if (!moved) { moved = true; remember(); f.classList.add("panning"); }
      const nx = sx > 1 ? Math.max(0, Math.min(100, cur[0] - dx / sx * 100)) : cur[0], ny = sy > 1 ? Math.max(0, Math.min(100, (cur[1] || 50) - dy / sy * 100)) : (cur[1] || 50), p = nx.toFixed(1) + "% " + ny.toFixed(1) + "%";
      im.style.objectPosition = p; f.style.setProperty("--zo", p); if (f.dataset.slot) state.focus[f.dataset.slot] = p; };
    const up = () => { removeEventListener("mousemove", mv); removeEventListener("mouseup", up); f.classList.remove("panning"); };
    addEventListener("mousemove", mv); addEventListener("mouseup", up); });
  doc.addEventListener("load", e => { const f = e.target.tagName === "IMG" && e.target.closest(".dc-img[data-shape=aw],.dc-img[data-shape=ah]"); if (f && e.target.naturalWidth) { f.style.setProperty("--ar", (e.target.naturalWidth / e.target.naturalHeight).toFixed(4)); setTimeout(dcFlow, 0); } }, true);
  let curStep = null;
  doc.addEventListener("mousedown", e => { if (!isDoc()) return; const p = e.target.closest(".d-spread.dc"); if (p && p !== curPage) { curPage = p; markCur(); }
    const sp = e.target.closest(".dc-step, .dc-fc"); if (sp) { $$(".dc-step.on, .dc-fc.on", doc).forEach(x => x.classList.remove("on")); curStep = sp; sp.classList.add("on"); setTimeout(drawBar, 0); } const b = e.target.closest(".dc-blk"); if (b !== curBlk) selectBlk(b); });
  doc.addEventListener("focusin", e => { const b = e.target.closest && e.target.closest(".dc-blk"); if (b && b !== curBlk) selectBlk(b); });
  const HR = ["line", "bold", "dots", "steps", "double"], CV = ["fact", "note", "warn", "tip", "best"];
  /* toolbar items: { l: label or icon html, f: action, on: highlighted, t: tooltip } or "|" for a divider */
  const IC = {
    land: '<svg viewBox="0 0 20 20"><rect x="2" y="5.5" width="16" height="9" rx="1"/></svg>',
    sq:   '<svg viewBox="0 0 20 20"><rect x="4.5" y="4.5" width="11" height="11" rx="1"/></svg>',
    port: '<svg viewBox="0 0 20 20"><rect x="5.5" y="2" width="9" height="16" rx="1"/></svg>',
    fill: '<svg viewBox="0 0 20 20"><rect x="3" y="4" width="14" height="12" rx="1"/><path d="M3 13l4-4 3 3 3-3 4 4" /><circle cx="7" cy="7.5" r="1.2"/></svg>',
    fit:  '<svg viewBox="0 0 20 20"><rect x="2" y="4" width="16" height="12" rx="1"/><rect x="6" y="6.5" width="8" height="7" rx=".5"/></svg>',
    centre: '<svg viewBox="0 0 20 20"><rect x="3" y="4" width="14" height="12" rx="1"/><path d="M10 7v6M7 10h6"/></svg>',
    tick: '<svg viewBox="0 0 20 20"><path d="M4 10.5l4 4 8-9"/></svg>',
    change: '<svg viewBox="0 0 20 20"><rect x="2.5" y="4" width="15" height="12" rx="1.5"/><path d="M2.5 13l4-4 3 3 2.5-2.5 5 5"/><circle cx="13.5" cy="7.5" r="1.3"/></svg>'
  };
  const pickCol = (cur, cb) => { const i = document.createElement("input"); i.type = "color"; i.value = /^#[0-9a-f]{6}$/i.test(cur || "") ? cur : "#d20a11"; i.style.cssText = "position:fixed;left:-99px;top:0;opacity:0"; document.body.appendChild(i);
    i.oninput = () => { cb(i.value); dcFlow(); }; i.onchange = () => { remember(); i.remove(); drawBar(); }; i.click(); };
  const RAIN = '<span class="swd" style="background:conic-gradient(#d20a11,#f0b429,#3fae49,#0a6fc2,#7a3fb0,#d20a11)"></span>';
  const SW = c => `<span class="swd" style="background:${c}"></span>`;
  function barActions(b) {
    const t = b.dataset.blk, A = [], PA = []; let tgt = A, gn = "";   // PA: controls that live in the right-hand Layout panel instead of the popup
    const it = (l, f, on, tt, dis) => tgt.push({ l, f, on, t: tt, g: gn, dis }), pane = (g, fn) => { tgt = PA; gn = g; fn(); tgt = A; gn = ""; };
    if (t === "media" || t === "imagefw" || t === "moreinfo" || /^image[234]$/.test(t)) {
      const target = curFig && b.contains(curFig) ? curFig : $(".dc-img", b), many = $$(".dc-img", b).length > 1;
      it(IC.change + `<span class="tl">Change</span>`, () => changeImage(target), false, many ? "Click an image first to choose which one to change" : "Choose a different image"); A.push("|"); }
    const bt = baseType(b);
    if (maxU(bt)) { const cur = unitCount(b);
      pane("Across", () => { for (let n = 1; n <= maxU(bt); n++) it("x" + n, () => unitCols(b, n), cur === n, n === 1 ? "Single" : n + " side by side"); });
      A.push("|"); }
    if (!/^(pagebreak|toc|section)$/.test(t)) pane("Place", () => [["Full", ""], ["Left", "l"], ["Right", "r"]].forEach(([l, v]) => it(l, () => { if (v) b.dataset.side = v; else delete b.dataset.side; }, (b.dataset.side || "") === v, v ? `Half of the page width, on the ${l.toLowerCase()}. Left and right blocks stack independently` : "The full width of the page")));
    if (bt === "map" && unitCount(b) === 1) { const w = b.dataset.w || "100";
      pane("Width", () => [["33", "⅓"], ["50", "½"], ["67", "⅔"], ["100", "Full"]].forEach(([v, l]) => it(l, () => { if (v === "100") delete b.dataset.w; else b.dataset.w = v; mapFix(); }, w === v, "Map width " + l))); A.push("|");
      if (w !== "100") { it("⇄", () => b.classList.toggle("flip"), false, "Swap the map and the text");
        it("Tt", () => b.classList.toggle("notext"), !b.classList.contains("notext"), "Show or hide the text beside the map"); A.push("|"); } }
    if (bt === "map") { const h = b.dataset.h || "";
      pane("Height", () => [["s", "S", "50mm"], ["m", "M", "80mm"], ["l", "L", "110mm"]].forEach(([v, l, mm]) => it("↕" + l, () => { if (h === v) delete b.dataset.h; else b.dataset.h = v; toast(h === v ? "Map height follows the width" : "Map height " + mm + ". Click the map and Use to redraw it at this shape"); }, h === v, `Map height ${mm} (click again for automatic)`))); A.push("|"); }
    if (t === "imagefw" || /^image[234]$/.test(t)) { const cur = t === "imagefw" ? 1 : +t.slice(5);
      pane("Across", () => [1, 2, 3, 4].forEach(n => it("x" + n, () => imageCount(b, n), cur === n, n === 1 ? "One full-width image" : n + " images in a row"))); A.push("|"); }
    if (/^list[23]?$/.test(t)) { const ol = $(".dc-list", b).tagName === "OL"; it(ol ? "• Bullets" : "1. Numbers", () => { const tag = ol ? "ul" : "ol"; $$(".dc-list", b).forEach(l => { const n = document.createElement(tag); [...l.attributes].forEach(x => n.setAttribute(x.name, x.value)); n.innerHTML = l.innerHTML;
        $$("li > ol, li > ul", n).forEach(s => { const m = document.createElement(tag); m.innerHTML = s.innerHTML; s.replaceWith(m); }); l.replaceWith(n); }); listCont(); });
      A.push("|"); it("→ Sub", () => liMove(b, 1), false, "Make the line you're on a sub-item of the one above (or press Tab)");
      it("← Out", () => liMove(b, -1), false, "Move a sub-item back out (or press Shift+Tab)"); }
    if (t === "callout") { const c = unitFor(b, ".dc-call"); it(TPL.callouts[c.dataset.v] + " ▸", () => { const v = CV[(CV.indexOf(c.dataset.v) + 1) % CV.length]; c.dataset.v = v; $(".dc-ctag", c).textContent = TPL.callouts[v]; $(".dc-cicon", c).innerHTML = TPL.icons[v]; delete c.dataset.ic; });
      it("Icon ▸", () => { const K = TPL.calloutIcons || CV, k = K[(K.indexOf(c.dataset.ic || c.dataset.v) + 1) % K.length]; c.dataset.ic = k; $(".dc-cicon", c).innerHTML = TPL.icons[k]; }, false, "Change the icon (the colour stays the same)");
      it("Label", () => { c.classList.toggle("notag"); }, !c.classList.contains("notag"), "Show or hide the label above the text (Fact, Note, Warning, Tip)"); }
    const lnk = !!$(".dc-media.lnk", b);
    if (baseType(b) === "para" || (t === "media" && !lnk) || t === "map") {
      it("Loose", () => { b.classList.remove("tight"); b.classList.toggle("loose"); }, b.classList.contains("loose"), "Looser line spacing and a gap between paragraphs. Text is tight by default. Tip: Shift+Enter starts a new line without a gap"); }
    if (t === "media") { it("⇄", () => $(".dc-media", b).classList.toggle("flip"), false, "Swap sides");
      it("Tt", () => b.classList.toggle("notext"), !b.classList.contains("notext"), "Show or hide the text beside the image"); A.push("|"); }
    if (t === "media" || t === "imagefw" || /^image[234]$/.test(t)) {
      const figs = $$(".dc-img", b), f0 = figs[0], all = (k, v) => figs.forEach(f => { if (v == null) delete f.dataset[k]; else f.dataset[k] = v; });
      if (!/^image[234]$/.test(t)) { const box = t === "media" ? $(".dc-media", b) : f0, cur = box.dataset.size || (t === "media" ? "" : "100");
        pane("Width", () => (t === "media" ? [10, 20, 30, 40, 50, 60, 70, 80, 90] : [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]).map(String).forEach(s => it(s + "%", () => { box.dataset.size = s; }, cur === s, `Image width: ${s}% of the text column`))); A.push("|");
        if (t === "imagefw") { const al = f0.dataset.al || "c", full = f0.offsetWidth >= f0.parentNode.clientWidth - 1;   // alignment only matters when the image is narrower than the column
          pane("Align", () => [["l", "Left"], ["c", "Centre"], ["r", "Right"]].forEach(([v, l]) => it(l, () => { if (v === "c") delete f0.dataset.al; else f0.dataset.al = v; }, !full && al === v, full ? "Set the image narrower than 100% to align it" : "Align the image: " + l.toLowerCase(), full))); } }
      const sh = f0.dataset.shape || "land", ft = f0.dataset.fit || "fill";
      const natural = f => { const im = $("img", f); return im && im.naturalWidth ? im.naturalWidth / im.naturalHeight : 1.5; };
      pane("Shape", () => { [["land", "Landscape"], ["sq", "Square"], ["port", "Portrait"]].forEach(([k, n]) => it(IC[k] + `<span class="tl">${n}</span>`, () => { all("shape", k); figs.forEach(f => f.style.removeProperty("--fh")); }, sh === k, n + " frame"));
        it("Circle", () => all("shape", "circ"), sh === "circ", "Round frame: drag the picture to place it, Zoom to size it");
        it("As wide", () => figs.forEach(f => { f.style.setProperty("--ar", natural(f).toFixed(4)); f.style.removeProperty("--fh"); f.dataset.shape = "aw"; }), sh === "aw", "Keep this width; the frame takes the picture's own height (nothing cropped)");
        it("As high", () => figs.forEach(f => { const h = f.offsetHeight; f.style.setProperty("--ar", natural(f).toFixed(4)); f.style.setProperty("--fh", (h * 25.4 / 96).toFixed(2) + "mm"); f.dataset.shape = "ah"; }), sh === "ah", "Keep this height; the frame takes the picture's own width (nothing cropped)"); }); A.push("|");
      { const zf = curFig && b.contains(curFig) ? curFig : f0, z = +zf.dataset.z || 1, setZ = v => { v = Math.round(Math.max(1, Math.min(4, v)) * 100) / 100; if (v === 1) { delete zf.dataset.z; zf.style.removeProperty("--z"); } else { zf.dataset.z = v; zf.style.setProperty("--z", v); } };
        pane("Zoom", () => { it("−", () => setZ(z - .1), false, "Zoom out", z <= 1); it(Math.round(z * 100) + "%", () => setZ(1), false, "Zoom now. Click to reset. Drag the picture on the page to move it inside its frame"); it("+", () => setZ(z + .1), false, "Zoom in. Then drag the picture on the page to place it", z >= 4); }); }
      pane("Fit", () => [["fill", "Fill the frame (crop)"], ["fit", "Fit the whole image"], ["centre", "Fill, centred"]].forEach(([k, n]) => it(IC[k] + `<span class="tl">${({ fill: "Fill", fit: "Fit", centre: "Centre" })[k]}</span>`, () => { all("fit", k); if (k === "centre") figs.forEach(f => { state.focus[f.dataset.slot] = "50% 50%"; const im = $("img", f); if (im) im.style.objectPosition = "50% 50%"; }); }, ft === k, n))); A.push("|");
    }
    if (t === "steps") { const s = $(".dc-steps", b), n = s.children.length, c = s.dataset.c || "red", lab = s.dataset.lab || "num";
      if (n < stepMax()) it("+ Step", () => s.appendChild(htmlEl(TPL.step(n + 1)))); if (n > 2) it("− Step", () => s.lastElementChild.remove()); A.push("|");
      { const v = s.dataset.o === "v"; it("Row", () => { delete s.dataset.o; }, !v, "Steps side by side in a row"); it("Stack", () => { s.dataset.o = "v"; }, v, "Steps stacked down the page"); A.push("|");
        if (!v) pane("Per row", () => { for (let k = 3; k <= stepRow(); k++) it(String(k), () => { s.dataset.per = k; }, Math.max(3, Math.min(+s.dataset.per || 5, n)) === k, k + " steps in each row"); });
        pane("Shape", () => [["", "Circle"], ["sq", "Square"], ["dia", "Diamond"], ["pill", "Pill"], ["hex", "Hexagon"]].forEach(([k, l]) => it(l, () => { if (k) s.dataset.sh = k; else delete s.dataset.sh; }, (s.dataset.sh || "") === k, l + " markers"))); }
      const one = curStep && s.contains(curStep) ? curStep : null, sc = one ? (one.dataset.c || c) : c;
      A.push({ lab: one ? "Step " + ([...s.children].indexOf(one) + 1) : "All steps" });
      [["red", "#D20A11"], ["black", "#1d1d1b"], ["grey", "#9a9a9f"]].forEach(([k, col]) => it(SW(col), () => { (one || s).style.removeProperty("--sc"); if (one) one.dataset.c = k; else { s.dataset.c = k; $$(".dc-step", s).forEach(x => { delete x.dataset.c; x.style.removeProperty("--sc"); }); } }, sc === k, (one ? "Colour this step " : "Colour all steps ") + k));
      it(RAIN, () => pickCol((one || s).style.getPropertyValue("--sc"), v => { (one || s).style.setProperty("--sc", v); if (!one) $$(".dc-step", s).forEach(x => { delete x.dataset.c; x.style.removeProperty("--sc"); }); }), !!(one || s).style.getPropertyValue("--sc"), "Pick any colour for " + (one ? "this step" : "all steps"));
      if (one) it("All", () => { s.dataset.c = sc; s.style.removeProperty("--sc"); const cv = one.style.getPropertyValue("--sc"); if (cv) s.style.setProperty("--sc", cv); $$(".dc-step", s).forEach(x => { delete x.dataset.c; x.style.removeProperty("--sc"); }); }, false, "Use this colour for every step"); A.push("|");
      if (lab !== "free") { const st = +s.dataset.start || 1, mx = lab === "abc" ? 26 : 99, shw = v => lab === "abc" ? String.fromCharCode(64 + v) : v;
        A.push({ lab: "Start" });
        it("−", () => { if (st - 1 <= 1) delete s.dataset.start; else s.dataset.start = st - 1; }, false, "Start the numbering one lower");
        it(String(shw(st)), () => {}, true, "First step's number / letter");
        it("+", () => { s.dataset.start = Math.min(mx, st + 1); }, false, "Start the numbering one higher (e.g. to carry on from the Process above)"); A.push("|"); }
      [["num", "1 2 3"], ["abc", "A B C"], ["free", "Text"]].forEach(([k, l]) => it(l, () => { s.dataset.lab = k; if (k === "free") $$(".dc-sn", s).forEach((sn, i) => { if (!$(".dc-snt", sn)) sn.innerHTML = `<span class="ed dc-snt" contenteditable="true" spellcheck="false">${i + 1}</span>`; }); }, lab === k, k === "free" ? "Type your own label in each circle" : "Label steps " + l));
      if (one) it(IC.tick, () => { if (one.dataset.done === "1") delete one.dataset.done; else one.dataset.done = "1"; }, one.dataset.done === "1", "Mark this step complete");
      if (one) it("✕", () => { if (one.dataset.done === "x") delete one.dataset.done; else one.dataset.done = "x"; }, one.dataset.done === "x", "Mark this step as failed / not done");
      if (one) it("Current", () => { const on = !one.dataset.cur; $$(".dc-step", s).forEach(x => delete x.dataset.cur); if (on) { one.dataset.cur = "1"; s.dataset.hascur = "1"; } else delete s.dataset.hascur; }, !!one.dataset.cur, "Make this the current step: the other steps grey out");
      if (one) {                                          // move the selected step along the line; at either end it hops into the Process just above / below
        const all = dcBlocks(), bi = all.indexOf(b), pv = all[bi - 1], nx = all[bi + 1], st = x => x && x.dataset.blk === "steps" && $(".dc-steps", x).children.length < stepMax() ? $(".dc-steps", x) : null;
        const prevS = one.previousElementSibling, nextS = one.nextElementSibling, up = !prevS && n > 1 && st(pv), dn = !nextS && n > 1 && st(nx);
        A.push("|");
        if (prevS || up) it("◀", () => { if (prevS) prevS.before(one); else { up.appendChild(one); setTimeout(() => selectBlk(pv), 0); } }, false, prevS ? "Move this step earlier" : "Move this step to the end of the Process above");
        if (nextS || dn) it("▶", () => { if (nextS) nextS.after(one); else { dn.insertBefore(one, dn.firstChild); setTimeout(() => selectBlk(nx), 0); } }, false, nextS ? "Move this step later" : "Move this step to the start of the Process below");
      } }
    if (t === "flow") { const s = $(".dc-flowc", b), n = s.children.length, v = s.dataset.o === "v", c = s.dataset.c || "red";
      if (n < stepMax()) it("+ Stage", () => s.appendChild(htmlEl(TPL.flowStage(n + 1)))); if (n > 2) it("− Stage", () => s.lastElementChild.remove()); A.push("|");
      it("Row", () => { delete s.dataset.o; }, !v, "Stages side by side in a row (wrapping onto more rows)"); it("Stack", () => { s.dataset.o = "v"; }, v, "Stages stacked down the page");
      it("• Bullet", () => { const sl = getSelection(); let n = sl.rangeCount ? sl.anchorNode : null; n = n && (n.nodeType === 1 ? n : n.parentNode); const box = n && n.closest && n.closest(".dc-fbp"); if (!box || !s.contains(box)) return toast("Click in a line of the card's text first");
        let ln = n.closest("p,div,li"); if (!ln || ln === box) { document.execCommand("formatBlock", false, "p"); n = getSelection().anchorNode; n = n && (n.nodeType === 1 ? n : n.parentNode); ln = n && n.closest("p"); } if (ln && box.contains(ln) && ln !== box) ln.classList.toggle("bul"); }, false, "Turn the line you are on into a bullet point (click again to turn it back)");
      if (!v) pane("Per row", () => { for (let k = 2; k <= Math.max(stepRow(), 4); k++) it(String(k), () => { s.dataset.per = k; }, Math.min(+s.dataset.per || 4, n) === Math.min(k, n), k + " stages in each row"); });
      const one = curStep && s.contains(curStep) && curStep.classList.contains("dc-fc") ? curStep : null, sc = one ? (one.dataset.c || c) : c;
      A.push({ lab: one ? "Stage " + ([...s.children].indexOf(one) + 1) : "All stages" });
      [["red", "#D20A11"], ["black", "#1d1d1b"], ["grey", "#9a9a9f"]].forEach(([k, col]) => it(SW(col), () => { (one || s).style.removeProperty(one ? "--sc" : "--fcol"); if (one) one.dataset.c = k; else { s.dataset.c = k; $$(".dc-fc", s).forEach(x => { delete x.dataset.c; x.style.removeProperty("--sc"); }); } }, sc === k, (one ? "This stage: " : "All stages: ") + k));
      it(RAIN, () => pickCol((one || s).style.getPropertyValue(one ? "--sc" : "--fcol"), v => { if (one) one.style.setProperty("--sc", v); else { if (s.dataset.c === "tones") s.dataset.c = "red"; s.style.setProperty("--fcol", v); $$(".dc-fc", s).forEach(x => { delete x.dataset.c; x.style.removeProperty("--sc"); }); } }), !!(one || s).style.getPropertyValue(one ? "--sc" : "--fcol"), "Pick any colour for " + (one ? "this stage" : "all stages"));
      if (one) it("Current", () => { const on = !one.dataset.cur; $$(".dc-fc", s).forEach(x => delete x.dataset.cur); if (on) { one.dataset.cur = "1"; s.dataset.hascur = "1"; } else delete s.dataset.hascur; }, !!one.dataset.cur, "Make this the current stage: the other stages grey out");
      if (!one) it("Tones", () => { s.style.removeProperty("--fcol"); s.dataset.c = "tones"; $$(".dc-fc", s).forEach(x => delete x.dataset.c); }, c === "tones", "Each stage a slightly darker shade");
      else it("Reset", () => { delete one.dataset.c; one.style.removeProperty("--sc"); }, false, "Use the colour of all stages for this one again");
      it("Number", () => { if (s.dataset.nonum) delete s.dataset.nonum; else s.dataset.nonum = "1"; }, !s.dataset.nonum, "Show or hide the stage numbers");
      pane("Card", () => [["grey", "Grey"], ["white", "White"], ["red", "Red"], ["black", "Black"]].forEach(([k, l]) => it(l, () => { if (k === "grey") delete s.dataset.bg; else s.dataset.bg = k; }, (s.dataset.bg || "grey") === k, "Card background: " + l))); }
    if (t === "glance") { const g = $(".dc-glance", b), n = g.children.length;
      if (n < glMax()) it("+ Item", () => { g.appendChild(g.lastElementChild.cloneNode(true)); glFit(g); }); if (n > 2) it("− Item", () => { g.lastElementChild.remove(); glFit(g); });
      pane("Bar", () => [["", "Red"], ["black", "Black"], ["grey", "Grey"], ["white", "White"]].forEach(([k, l]) => it(l, () => { if (k) g.dataset.bar = k; else delete g.dataset.bar; }, (g.dataset.bar || "") === k, "Top bar: " + l)));
      pane("Card", () => [["", "Grey"], ["white", "White"], ["red", "Red"], ["black", "Black"]].forEach(([k, l]) => it(l, () => { if (k) g.dataset.bg = k; else delete g.dataset.bg; }, (g.dataset.bg || "") === k, "Card background: " + l)));
      if (n > 3) it("Wrap", () => { if (g.dataset.wrap) delete g.dataset.wrap; else g.dataset.wrap = "1"; glFit(g); }, !!g.dataset.wrap, "Break the boxes onto several rows instead of one narrow row"); }
    if (t === "dodont") { const dd = unitFor(b, ".dc-dd"), all = $$(".dc-dd", b), m = dd.dataset.mode || "both";
      all.forEach(x => { if (!$(".dc-ddtext", x)) x.insertAdjacentHTML("beforeend", '<div class="ed dc-p dc-rich dc-ddtext" contenteditable="true" spellcheck="false"><p>Explain why this matters, or what to do instead.</p></div>');
        $$(".dc-ddh", x).forEach(h => { if ($(".dc-ddl", h)) return; const tx = [...h.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join("").trim(); [...h.childNodes].forEach(n => { if (n.nodeType === 3) n.remove(); }); h.insertAdjacentHTML("beforeend", `<span class="ed dc-ddl" contenteditable="true" spellcheck="false">${chEsc(tx || "Do")}</span>`); }); });   // older blocks: the Do / Don't titles become editable
      [["both", "Both"], ["do", "Do"], ["dont", "Don't"]].forEach(([k, l]) => it(l, () => { dd.dataset.mode = k; if (k === "both") delete dd.dataset.solo; else if (m === "both") dd.dataset.solo = "1"; }, m === k, k === "both" ? "Do and Don't side by side" : `Just the ${l} panel, using the full width`));
      if (m !== "both") { it("Text beside", () => { if (dd.dataset.solo) delete dd.dataset.solo; else dd.dataset.solo = "1"; }, !dd.dataset.solo, "Put a text box beside the panel (off: the panel uses the full width)");
        if (!dd.dataset.solo) it("⇄", () => dd.classList.toggle("flip"), false, "Swap sides"); } A.push("|");
      it("→ Sub", () => liMove(b, 1), false, "Make the line you're on a sub-item of the one above (or press Tab)"); it("← Out", () => liMove(b, -1), false, "Move a sub-item back out (or press Shift+Tab)"); A.push("|");
      [["", "Green / Red"], ["brand", "Brand"], ["blue", "Blue / Grey"]].forEach(([k, l]) => it(l, () => all.forEach(x => { if (k) x.dataset.s = k; else delete x.dataset.s; }), (dd.dataset.s || "") === k, "Colours: " + (k === "brand" ? "black and red (brand colours)" : l.toLowerCase()))); }
    if (/^(table|directory|sign|specs)$/.test(t) && curRow && b.contains(curRow)) {   // the row last clicked: move it up / down, or delete it
      const r = curRow, sel = t === "specs" ? ".dc-sp-r" : "tbody tr", all = $$(sel, b), i = all.indexOf(r);
      A.push({ lab: "Row " + (i + 1) });
      if (i > 0) it("↑", () => all[i - 1].before(r), false, "Move this row up");
      if (i < all.length - 1) it("↓", () => all[i + 1].after(r), false, "Move this row down");
      if (all.length > 1) it("✕", () => { const n = all[i + 1] || all[i - 1]; r.remove(); curRow = n; }, false, "Delete this row");
      A.push("|"); }
    if (t === "sign") { const tb = $("table", b), rows = $$("tbody tr", tb);
      it("+ Row", () => $("tbody", tb).insertAdjacentHTML("beforeend", "<tr><td></td><td></td><td></td><td></td></tr>"));
      if (rows.length > 1) it("− Row", () => rows[rows.length - 1].remove()); A.push("|"); }
    if (t === "table" || t === "directory" || t === "sign") { const tb = $("table", b), tc = tb.dataset.tc || "black";
      [["red", "#D20A11"], ["black", "#1d1d1b"], ["grey", "#8a8a90"], ["white", "#ffffff"]].forEach(([k, c]) => it(SW(c), () => { tb.dataset.tc = k; }, tc === k, "Header colour: " + k)); A.push("|"); }
    if (t === "directory") { const tb = $("table", b), rows = $$("tbody tr", tb);
      it("+ Person", () => { const r = rows[rows.length - 1].cloneNode(true); $$("td", r).forEach((td, i) => td.textContent = ["Name", "Role", "Business", "name@company.co.uk", "01234 567890"][i] || "..."); $("tbody", tb).appendChild(r); });
      if (rows.length > 1) it("− Person", () => rows[rows.length - 1].remove()); }
    if (t === "table") { const tb = $("table", b), rows = $$("tbody tr", tb), cols = $$("thead th", tb).length;
      it("+ Row", () => { const r = rows[rows.length - 1].cloneNode(true); $$("td", r).forEach(td => td.textContent = "..."); $("tbody", tb).appendChild(r); });
      if (rows.length > 1) it("− Row", () => rows[rows.length - 1].remove());
      if (cols < 5) it("+ Col", () => { $("thead tr", tb).insertAdjacentHTML("beforeend", "<th>Column</th>"); $$("tbody tr", tb).forEach(r => r.insertAdjacentHTML("beforeend", "<td>...</td>")); });
      if (cols > 2) it("− Col", () => $$("tr", tb).forEach(r => r.lastElementChild.remove())); }
    if (t === "duration") { const d = unitFor(b, ".dc-dur"), c = d.dataset.c || "green", v = d.dataset.v || "rule";
      it(v === "rule" ? "Rule ▸" : "Badge ▸", () => { d.dataset.v = v === "rule" ? "badge" : "rule"; }, false, "Switch between a divider line carrying the time, and a stacked badge (good for several side by side)");
      it("Caption", () => d.classList.toggle("nocap"), !d.classList.contains("nocap"), "Show or hide the small caption"); A.push("|");
      [["green", "#3fae49"], ["amber", "#f0b429"], ["red", "#d20a11"], ["grey", "#4b4b50"]].forEach(([k, col]) => it(SW(col), () => { d.dataset.c = k; const ve = $(".dc-dur-v", d), std = { green: "3m", amber: "6m", red: "9m", grey: "12m" }; if (ve && Object.values(std).includes(ve.textContent.trim())) ve.textContent = std[k]; }, c === k, "Colour: " + k + " (" + ({ green: "3m", amber: "6m", red: "9m", grey: "12m" })[k] + ")")); }
    if (baseType(b) === "para") { const bg = b.dataset.bg || "";
      pane("Fill", () => [["", "None"], ["pale", "Pale"], ["grey", "Grey"], ["red", "Red"], ["black", "Black"], ["line", "Outline"]].forEach(([k, n]) => it(n, () => { if (k) b.dataset.bg = k; else delete b.dataset.bg; }, bg === k, "Fill the text box: " + n))); }
    if (/^(ltitle|lsub|section|heading|sub|chapter)$/.test(t)) { const ri = $(":scope > .dc-ri", b), kind = ri ? ri.dataset.k || "img" : "";
      const put = (k, html) => { const o = $(":scope > .dc-ri", b); if (o) o.remove(); if (!html) { b.classList.remove("hasri"); return; } b.insertAdjacentHTML("beforeend", `<span class="dc-ri" data-k="${k}" contenteditable="false">${html}</span>`); b.classList.add("hasri"); };
      const CLK = `<svg class="dc-dur-i" viewBox="0 0 48 48" aria-hidden="true"><rect x="7" y="10" width="34" height="31" rx="4"/><path d="M7 20h34M16 5v9M32 5v9"/></svg>`;
      pane("Icon (right)", () => { it("None", () => put(""), !ri, "No icon on the right");
        it("Upload…", () => { const i = document.createElement("input"); i.type = "file"; i.accept = "image/*"; i.onchange = () => { const fl = i.files[0]; if (!fl) return; const rd = new FileReader();
          rd.onload = () => { const im = new Image(); im.onload = () => { const H = Math.min(240, im.naturalHeight), W = Math.round(im.naturalWidth * H / im.naturalHeight), c = document.createElement("canvas"); c.width = W; c.height = H; c.getContext("2d").drawImage(im, 0, 0, W, H);
            remember(); put("img", `<img src="${/svg/.test(fl.type) ? rd.result : c.toDataURL("image/png")}" alt="">`); dcFlow(); drawBar(); }; im.src = rd.result; }; rd.readAsDataURL(fl); }; i.click(); }, kind === "img", "Upload your own icon. It is sized to fit the height of this line");
        [["green", "3m"], ["amber", "6m"], ["red", "9m"], ["grey", "12m"]].forEach(([c, v]) => it(v, () => put(c, `<span class="dc-rid" data-c="${c}">${CLK}<b>${v}</b></span>`), kind === c, "Duration icon: " + v)); }); }
    { const ps = dcPages(), go = $(":scope > .dc-go", b), cur = go ? ps.findIndex(p => p.id && "#" + p.id === go.getAttribute("href")) : -1;
      pane("Link to page", () => { it("None", () => { if (go) go.remove(); }, !go, "No link");
        ps.forEach((p, i) => { if (p.contains(b)) return; it(String(i + 1), () => { if (!p.id) p.id = "dc-p" + Math.random().toString(36).slice(2, 8); const o = $(":scope > .dc-go", b); if (o) o.remove();
          b.insertAdjacentHTML("beforeend", `<a class="dc-go" href="#${p.id}" target="_self" contenteditable="false" title="Go to page ${i + 1}"></a>`); }, cur === i, "In the exported document, clicking this component jumps to page " + (i + 1)); }); }); }
    { const pd = +b.dataset.pad || 0;
      pane("Padding", () => { it("Pad −", () => { const v = Math.max(-4, pd - 1); if (v) b.dataset.pad = v; else delete b.dataset.pad; b.style.setProperty("--pad", (v * 3) + "px"); if (!v) b.style.removeProperty("--pad"); }, false, "A little less space above and below (3px a click)", pd <= -4);
        it(String(pd * 3) + "px", () => { delete b.dataset.pad; b.style.removeProperty("--pad"); }, false, "Extra space above and below now. Click to reset");
        it("Pad +", () => { const v = Math.min(20, pd + 1); b.dataset.pad = v; b.style.setProperty("--pad", (v * 3) + "px"); }, false, "A little more space above and below (3px a click)"); }); }
    if (t === "hr") { const h = $(".dc-hr", b), w = h.dataset.w || "100", c = h.dataset.c || "";
      it(h.dataset.v[0].toUpperCase() + h.dataset.v.slice(1) + " ▸", () => { h.dataset.v = HR[(HR.indexOf(h.dataset.v) + 1) % HR.length]; }, false, "Divider style"); A.push("|");
      [["100", "Full"], ["75", "¾"], ["50", "½"]].forEach(([v, l]) => it(l, () => { if (v === "100") delete h.dataset.w; else h.dataset.w = v; }, w === v, "Divider width " + v + "%")); A.push("|");
      [["red", "#D20A11"], ["black", "#1d1d1b"], ["grey", "#9a9a9f"]].forEach(([k, col]) => it(SW(col), () => { if (c === k) delete h.dataset.c; else h.dataset.c = k; }, c === k, "Colour: " + k)); }
    if (t === "sub" || ((t === "media" || t === "map") && !lnk && !b.classList.contains("notext"))) it("Label", () => b.classList.toggle("shlabel"), b.classList.contains("shlabel"), "Sub-heading as a small red capitals label");
    if (t === "moreinfo") { const c = $(".dc-mi", b).dataset.c || "red";
      it("Photo", () => { $$(".dc-mi", b).forEach(x => x.classList.toggle("nophoto")); }, !$(".dc-mi", b).classList.contains("nophoto"), "Show or hide the profile photo");
      [["red", "#D20A11"], ["black", "#1d1d1b"], ["grey", "#9a9a9f"]].forEach(([k, col]) => it(SW(col), () => { $$(".dc-mi", b).forEach(x => { x.dataset.c = k; }); }, c === k, "Accent colour: " + k)); }
    if (t === "inhere") { const h = unitFor(b, ".dc-inhere"), c = h.dataset.c || "red";
      [["red", "#D20A11"], ["grey", "#9a9a9f"], ["black", "#1d1d1b"], ["none", "#ffffff"]].forEach(([k, col]) => it(SW(col), () => { $$(".dc-inhere", b).forEach(x => { x.dataset.c = k; }); }, c === k, k === "none" ? "No shading" : "Shade: " + k)); }
    if (t === "qr") { it("Edit link", () => editLink($(".d-qr", unitFor(b, ".dc-qrb"))), false, "Change the address the QR code opens");
      { const q0 = unitFor(b, ".dc-qrb"), pos = q0.dataset.pos === "top" ? "top" : q0.classList.contains("flip") ? "right" : "left";   // each code in a x2 / x3 row is placed on its own
        [["left", "Code left"], ["right", "Code right"], ["top", "Code above"]].forEach(([k, l]) => it(l, () => { q0.classList.toggle("flip", k === "right"); if (k === "top") q0.dataset.pos = "top"; else delete q0.dataset.pos; }, pos === k, l + " of the text" + (k === "right" ? " (text lines up on the right)" : ""))); } }
    if (t === "media" && $(".dc-url", b)) { const u = $(".dc-url", b), addr = u.dataset.show === "addr", md = $(".dc-media", b);
      pane("Link across", () => [["", "Left"], ["r", "Right"]].forEach(([k, l]) => it(l, () => { if (k) md.dataset.lh = k; else delete md.dataset.lh; }, (md.dataset.lh || "") === k, "Link sits to the " + l.toLowerCase() + " of its space")));
      pane("Link up/down", () => [["t", "Top"], ["", "Middle"], ["b", "Bottom"]].forEach(([k, l]) => it(l, () => { if (k) md.dataset.lv = k; else delete md.dataset.lv; }, (md.dataset.lv || "") === k, "Link lines up with the " + l.toLowerCase() + " of the image")));
      it("Edit link", () => editLink(u), false, "Change where the link goes");
      it(addr ? "Show button" : "Show address", () => { if (addr) delete u.dataset.show; else u.dataset.show = "addr"; }, false, addr ? "Show a Click here button instead of the web address" : "Show the full web address instead of the button"); A.push("|"); }
    if (t === "url") { const u = unitFor(b, ".dc-url"), addr = u.dataset.show === "addr"; it(addr ? "Show button" : "Show address", () => { $$(".dc-url", b).forEach(x => { if (addr) delete x.dataset.show; else x.dataset.show = "addr"; }); }, false, addr ? "Show a Click here button instead of the web address" : "Show the full web address instead of the button"); }
    if (t === "url" || t === "product") it("Edit link", () => editLink(unitFor(b, ".dc-url")), false, t === "product" ? "Click a link cell first to choose which one" : "");
    if (colTarget(b)) it("Even", () => colEven(colTarget(b)), false, "Make the columns their default widths again (drag the column edges to change them)");
    if (t === "specs") { const sp = $(".dc-spec", b), rows = $$(".dc-sp-r", sp), c = sp.dataset.c || "red";
      it("+ Row", () => sp.appendChild(htmlEl(TPL.specRow("Product name", "What it is used for", "Certification"))));
      if (rows.length > 1) it("− Row", () => rows[rows.length - 1].remove());
      it("Paste list", () => specPaste(b), false, "Optional: build all the rows at once from lines like “product = X, main use = Y, certification = Z”"); A.push("|");
      [["red", "#D20A11"], ["black", "#1d1d1b"], ["grey", "#9a9a9f"]].forEach(([k, col]) => it(SW(col), () => { sp.dataset.c = k; }, c === k, "Accent: " + k)); A.push("|");
      const rw = curRow && sp.contains(curRow) ? curRow : null, pills = rw ? $$(".dc-sp-b", rw) : $$(".dc-sp-b", sp), pc = (pills[0] || {}).dataset ? pills[0].dataset.pc || "green" : "green";
      A.push({ lab: rw ? "Button (row)" : "Buttons" });
      [["green", "#119b24"], ["amber", "#e08a00"], ["red", "#d20a11"], ["blue", "#0a6fc2"]].forEach(([k, col]) => it(SW(col), () => pills.forEach(x => { if (k === "green") delete x.dataset.pc; else x.dataset.pc = k; }), pc === k, "Button colour: " + k + (rw ? " (this row)" : " (all rows; click a row first to change just one)")));
      it("Text", () => { const cur = pills[0] ? pills[0].textContent.trim() : "Verified", v = prompt("Button text", cur); if (v && v.trim()) pills.forEach(x => { const i = $(".dc-sp-bi", x); x.textContent = v.trim(); if (i) x.prepend(i); }); }, false, "Change the button text" + (rw ? " (this row)" : " (all rows)")); }
    if (t === "product") { const pr = $(".dc-prod", b), c = pr.dataset.c || "red"; A.push("|");
      [["red", "#D20A11"], ["black", "#1d1d1b"], ["grey", "#9a9a9f"]].forEach(([k, col]) => it(SW(col), () => { pr.dataset.c = k; }, c === k, "Header: " + k)); }
    if (t === "space") { const sp = $(".dc-space", b); pane("Height", () => [["h", "Half"], ["1", "Single"], ["2", "Double"], ["5", "x5"]].forEach(([v, l]) => it(l, () => { sp.dataset.v = v; }, sp.dataset.v === v, "Space height: " + l.toLowerCase()))); }
    if (t === "map") { const mu = unitFor(b, ".dc-mapu") || b; it("Directions", () => mu.classList.toggle("nodir"), !mu.classList.contains("nodir"), "Show or hide the Click for Directions link under the map"); }
    if (t === "map") it("Set location", () => openMap($(".d-fig", unitFor(b, ".dc-mapu") || b).dataset.slot));
    if (t === "timeline") { const g = $("[data-chart]", b), gc = chData(g) || {};
      it("Edit timeline", () => editChart(g));
      it("Today", () => { const d = chData(g) || {}; d.now = d.now === 0 ? 1 : 0; g.dataset.chart = JSON.stringify(d); renderChart(g); }, gc.now !== 0, "Show or hide the today marker"); }
    if (/^ch-/.test(t)) it("Edit chart", () => editChart(unitFor(b, ".dc-chart")));
    if (t === "toc") { const c = $(".dc-toc", b); it(c.dataset.lv === "2" ? "Sections only" : "+ Headings", () => { c.dataset.lv = c.dataset.lv === "2" ? "1" : "2"; }); }
    A.pane = PA; return A;
  }
  /* side-by-side copies of an element (Text, Lge Text/Sub-text, Heading, Sub-heading, Link, Attention, Map): x1..x4 */
  const UNIT = { dodont: ".dc-dd", duration: ".dc-dur", moreinfo: ".dc-mi", qr: ".dc-qrb", list: ".dc-list", para: ".dc-p", ltitle: ".dc-lt", lsub: ".dc-lnd", heading: ".dc-h", sub: ".dc-sh", url: ".dc-url", callout: ".dc-call", map: ".dc-mapu", medialink: ".dc-media.lnk", mediatext: ".dc-media", inhere: ".dc-inhere",
    "ch-pie": ".dc-chart", "ch-pie2": ".dc-chart", "ch-sun": ".dc-chart", "ch-kpi": ".dc-chart", "ch-gauge": ".dc-chart", "ch-lines": ".dc-chart", "ch-radar": ".dc-chart" };
  const lim = () => (TPL.paper && TPL.paper.alt && !a3() ? null : TPL.limits);   // Training's wider limits only apply on A3
  const stepMax = () => (lim() && lim().steps) || 10, stepRow = () => (lim() && lim().stepsRow) || 5, glMax = () => (lim() && lim().glance) || 10;
  /* Glance items stay in one row (small boxes) unless the author turns Wrap on; then they break onto balanced rows (at most 5 across on A4, 6 on A3, half that beside another block) */
  const glFit = g => { const n = g.children.length, side = g.closest(".dc-blk[data-side]"), per = Math.max(2, Math.ceil((g.closest(".dc-a3") ? 6 : 5) / (side ? 2 : 1))), rows = g.dataset.wrap ? Math.ceil(n / per) : 1; g.style.setProperty("--gc", Math.max(1, Math.ceil(n / rows))); };
  const maxU = k => (lim() && lim().across && lim().across[k]) || MAXU[k];   // a template can allow more (or fewer) side-by-side copies: limits.across in its settings
  const MAXU = { dodont: 2, duration: 4, moreinfo: 3, qr: 3, list: 4, para: 4, ltitle: 3, lsub: 3, heading: 4, sub: 4, url: 4, callout: 2, map: 3, medialink: 2, inhere: 2, "ch-pie": 2, "ch-pie2": 2, "ch-sun": 2, "ch-kpi": 2, "ch-gauge": 3, "ch-lines": 2, "ch-radar": 2 };
  const baseType = b => b.dataset.blk === "media" && $(".dc-media", b) ? ($(".dc-media.lnk", b) ? "medialink" : "mediatext") : b.dataset.blk.replace(/^(para|list|image)[234]$/, "$1");
  function unitsOf(b) {
    const t = baseType(b);
    if (t === "map" && !$(".dc-mapu", b)) { const w = document.createElement("div"); w.className = "dc-mapu"; while (b.firstChild) w.appendChild(b.firstChild); b.appendChild(w); }
    return $$(UNIT[t], b).filter(u => u.closest(".dc-blk") === b && !(t === "para" && u.classList.contains("dc-ddtext")));
  }
  function unitCount(b) { const c = $(".dc-cols", b); if (c) return c.children.length; const p = $(baseType(b) === "list" ? ".dc-list" : ".dc-p", b); return p && p.classList.contains("four") ? 4 : p && p.classList.contains("three") ? 3 : p && p.classList.contains("two") ? 2 : 1; }
  function cloneUnit(t, u) {
    const c = u.cloneNode(true); c.classList.remove("sel");
    if (t === "para") c.innerHTML = "<p>Text for this column.</p>";
    if (t === "list") { c.innerHTML = "<li>List item</li><li>List item</li><li>List item</li>"; c.style.removeProperty("counter-reset"); }
    if (t === "url") c.dataset.link = "dl" + newUid();
    if (t === "qr") { const id = "dq" + newUid(); $$("[data-link]", c).forEach(x => { x.dataset.link = id; }); setTimeout(() => $$(".d-qr", c).forEach(renderQR), 0); }
    if (t === "map") { const f = $(".d-fig", c), s = "dc" + newUid(); f.dataset.slot = s; delete f.dataset.map; delete f.dataset.href; f.classList.remove("sel"); const cp = $(".dc-mapcap", c); if (cp) delete cp.dataset.href; setTimeout(() => setSlot(s, "ph"), 0); }
    if (t === "medialink" || t === "mediatext") { const f = $(".d-fig", c), sl = "dc" + newUid(); f.dataset.slot = sl; f.classList.remove("sel"); delete f.dataset.href; setTimeout(() => setSlot(sl, "ph"), 0); $$("[data-link]", c).forEach(x => { x.dataset.link = "dl" + newUid(); }); }
    if (t === "moreinfo") { const f = $(".d-fig", c), sl = "dc" + newUid(); f.dataset.slot = sl; f.classList.remove("sel"); delete f.dataset.href; setTimeout(() => setSlot(sl, "ph"), 0); $$("[data-link]", c).forEach(x => { x.dataset.link = "dl" + newUid(); }); $$(".dc-mimail", c).forEach(x => { delete x.dataset.manual; }); }
    return c;
  }
  function unitCols(b, n) {
    const t = baseType(b), units = unitsOf(b), side = t === "map" ? $(".dc-mapside", b) : null;
    if (t === "para" || t === "list") units.forEach(c => c.classList.remove("two", "three", "four"));
    const keep = units.slice(0, n);
    if (t === "para" || t === "list") units.slice(n).forEach(c => keep[keep.length - 1].insertAdjacentHTML("beforeend", c.innerHTML));
    if (t === "list") keep.forEach(c => c.style.removeProperty("counter-reset"));
    while (keep.length < n) keep.push(cloneUnit(t, keep[0]));
    b.innerHTML = "";
    if (n === 1) b.appendChild(keep[0]);
    else { const g = document.createElement("div"); g.className = "dc-cols"; g.style.setProperty("--n", n); keep.forEach(c => g.appendChild(c)); b.appendChild(g); }
    if (side) b.appendChild(side);
    b.dataset.blk = t === "medialink" || t === "mediatext" ? "media" : t; if (n > 1) delete b.dataset.w;
    $$("[data-chart]", b).forEach(renderChart); if (t === "list") listCont();
  }
  /* older lists used flowing CSS columns (class two / three / four): split them into separate typed-in columns, items shared out evenly */
  function listColsFix() {
    $$(".dc-blk", doc).filter(b => /^list[23]?$/.test(b.dataset.blk)).forEach(b => {
      const l = $(".dc-list", b); if (!l || l.closest(".dc-cols")) return;
      const n = l.classList.contains("four") ? 4 : l.classList.contains("three") ? 3 : l.classList.contains("two") ? 2 : 1; l.classList.remove("two", "three", "four"); b.dataset.blk = "list";
      if (n === 1) return;
      const items = [...l.children], per = Math.ceil(items.length / n), g = document.createElement("div"); g.className = "dc-cols"; g.style.setProperty("--n", n);
      for (let k = 0; k < n; k++) { const m = l.cloneNode(false); items.slice(k * per, (k + 1) * per).forEach(x => m.appendChild(x)); if (!m.children.length) m.innerHTML = "<li>List item</li>"; g.appendChild(m); }
      l.replaceWith(g);
    });
  }
  /* numbered lists split into columns carry on counting: column 2 starts after the last number in column 1 */
  function listCont() {
    $$('.dc-blk[data-blk="list"]', doc).forEach(b => { let n = 0; $$(".dc-list", b).forEach((l, i) => {
      if (l.tagName === "OL" && i > 0) l.style.counterReset = `dcl ${n}`; else l.style.removeProperty("counter-reset");
      n += [...l.children].filter(c => c.tagName === "LI").length; }); });
  }
  let curRow = null;              // last clicked row in a Table / Directory / Signatures / Product List
  doc.addEventListener("mousedown", e => { const r = e.target.closest && e.target.closest(".dc-blk tbody tr, .dc-sp-r"); curRow = r || (e.target.closest && e.target.closest(".dc-blk") && curRow && e.target.closest(".dc-blk").contains(curRow) ? curRow : null); if (r) setTimeout(drawBar, 0); }, true);
  let curUnit = null;            // last clicked Link / Attention / Map inside a multi block
  doc.addEventListener("mousedown", e => { const u = e.target.closest && e.target.closest(".dc-url,.dc-call,.dc-mapu,.dc-chart,.dc-qrb,.dc-dur,.dc-dd"); if (u && u !== curUnit) { curUnit = u; if (curBlk && curBlk.contains(u)) setTimeout(drawBar, 0); } }, true);   // the toolbar follows the copy you clicked in a x2 / x3 / x4 block
  const unitFor = (b, sel) => (curUnit && b.contains(curUnit) && curUnit.matches(sel) ? curUnit : $(sel, b));
  /* switch an image block between 1 (full width) and 2-4 images in a row, keeping the photos already chosen */
  function imageCount(b, n) {
    const figs = $$(".dc-img", b), f0 = figs[0], keep = ["shape", "fit", "bc", "bw"];
    const make = () => { const f = f0.cloneNode(true); f.classList.remove("wide", "sel"); delete f.dataset.size; const s = "dc" + newUid(); f.dataset.slot = s; setTimeout(() => setSlot(s, "ph"), 0); return f; };
    const list = figs.slice(0, n); while (list.length < n) list.push(make());
    figs.slice(n).forEach(f => f.remove());
    if (n === 1) { const f = list[0]; f.classList.add("wide"); b.innerHTML = ""; b.appendChild(f); b.dataset.blk = "imagefw"; }
    else { list.forEach(f => { f.classList.remove("wide"); delete f.dataset.size; keep.forEach(k => { if (f0.dataset[k]) f.dataset[k] = f0.dataset[k]; }); });
      const pr = document.createElement("div"); pr.className = "dc-pair" + (n > 2 ? (n === 3 ? " three" : " four") : ""); list.forEach(f => pr.appendChild(f)); b.innerHTML = ""; b.appendChild(pr); b.dataset.blk = "image" + n; }
  }
  /* right-hand Layout panel: the sizing controls for the selected element (columns across, widths, shape, fit) */
  function drawPane(items, btn, name) {
    const sec = $("#elPane"), body = $("#epBody"); body.innerHTML = "";
    if (!items || !items.length || !curBlk) { sec.hidden = true; return; }
    const groups = []; items.forEach(x => { let g = groups.find(q => q.n === x.g); if (!g) groups.push(g = { n: x.g, a: [] }); g.a.push(x); });
    groups.forEach(g => { const r = document.createElement("div"); r.className = "eprow"; r.innerHTML = `<span class="eplab">${g.n}</span>`; const w = document.createElement("div"); w.className = "epbtns";
      g.a.forEach(x => { const el = btn(x.l, x.f, x.t, x.on); el.classList.add("mini"); if (x.dis) el.disabled = true; w.appendChild(el); }); r.appendChild(w); body.appendChild(r); });
    $("#epName").textContent = name || ""; sec.hidden = false;
  }
  function drawBar() {
    const b = curBlk; if (!b || !doc.contains(b)) { bar.hidden = true; drawPane(null); return; }
    const all = dcBlocks(), i = all.indexOf(b);
    const btn = (label, fn, title, on) => { const x = document.createElement("button"); x.innerHTML = label; if (on) x.className = "on"; const plain = String(label).replace(/<[^>]+>/g, "").trim(); x.title = title || (/^\+ /.test(plain) ? "Add " + plain.slice(2).toLowerCase() : /^[−-] /.test(plain) ? "Remove the last " + plain.slice(2).toLowerCase() : plain.length > 1 ? plain : ""); x.onmousedown = e => e.preventDefault(); x.onclick = () => { remember(); fn(); dcFlow(); drawBar(); }; return x; };
    let grp = null; const sep = () => { grp = null; };
    const put = el => { if (!grp) { grp = document.createElement("span"); grp.className = "bg"; bar.appendChild(grp); } grp.appendChild(el); };
    borderPane();
    const key = b.dataset.blk === "media" ? ($(".dc-media.flip", b) ? "mediar" : "medial") : /^image[234]$/.test(b.dataset.blk) ? "imagefw" : /^para[234]$/.test(b.dataset.blk) ? "para" : /^list[23]$/.test(b.dataset.blk) ? "list" : b.dataset.blk;
    bar.innerHTML = ""; bar.title = (TPL.blocks[key] || {}).label || "";
    const acts = barActions(b); drawPane(acts.pane, btn, bar.title);
    acts.forEach(x => { if (x === "|") return sep(); if (x.lab) { const s = document.createElement("span"); s.className = "bl"; s.textContent = x.lab + ":"; return put(s); } put(btn(x.l, x.f, x.t, x.on)); });
    sep();
    const pg = dcPages(), pi = pg.indexOf(b.closest(".d-spread")), fl = b.parentNode;
    const upPage = !b.previousElementSibling && pi > 0, downPage = !b.nextElementSibling && pi < pg.length - 1;
    if (upPage) put(btn("↑", () => $(".dc-flow", pg[pi - 1]).appendChild(b), "Move to the previous page"));
    else if (i > 0) put(btn("↑", () => all[i - 1].before(b), "Move up"));
    if (downPage) put(btn("↓", () => { const nf = $(".dc-flow", pg[pi + 1]); nf.insertBefore(b, nf.firstChild); }, "Move to the next page"));
    else if (i < all.length - 1) put(btn("↓", () => all[i + 1].after(b), "Move down"));
    put(btn("⧉", () => { const c = b.cloneNode(true); c.classList.remove("sel"); c.removeAttribute("id");
      $$(".d-fig[data-slot]", c).forEach(f => { const n = "dc" + newUid(), old = f.dataset.slot; f.dataset.slot = n; setTimeout(() => setSlot(n, state.slots[old] || "ph", state.focus[old]), 0); });
      $$("[data-link]", c).forEach(x => { x.dataset.link = "dl" + newUid(); }); b.after(c); setTimeout(() => selectBlk(c), 0); }, "Duplicate"));
    put(btn("✕", () => { const n = all[i + 1] || all[i - 1]; b.remove(); setTimeout(() => selectBlk(n || null), 0); }, "Delete"));
    bar.hidden = false;
    const st = $("#stage"), sr = st.getBoundingClientRect(), r = b.getBoundingClientRect();
    bar.style.top = Math.max(0, r.top - sr.top + st.scrollTop - bar.offsetHeight - 6) + "px";
    bar.style.left = Math.max(0, Math.min(r.right - sr.left + st.scrollLeft - bar.offsetWidth, st.scrollWidth - bar.offsetWidth - 4)) + "px";
    colHandles();
  }
  /* column widths (Table, Directory, Product List): drag handles sit on the column edges of the selected block (app only, outside the document) */
  const colTarget = b => b && ($(".dc-spec", b) || $("table.dc-table", b));
  const colCells = t => t.classList.contains("dc-spec") ? $$(".dc-sp-h > span", t) : $$("thead th", t);
  function colApply(t, pct) {
    pct = pct.map(v => Math.round(v * 10) / 10);
    if (t.classList.contains("dc-spec")) t.style.setProperty("--spc", pct.map(v => `minmax(0,${v}fr)`).join(" "));
    else { t.style.tableLayout = "fixed"; colCells(t).forEach((th, i) => { th.style.width = pct[i] + "%"; }); }
  }
  function colEven(t) { if (t.classList.contains("dc-spec")) t.style.removeProperty("--spc"); else { t.style.tableLayout = ""; colCells(t).forEach(th => th.style.removeProperty("width")); } }
  function colHandles() {
    const box = $("#colH"); box.innerHTML = ""; const t = curBlk && doc.contains(curBlk) && colTarget(curBlk); if (!t) return;
    const cells = colCells(t); if (cells.length < 2) return;
    const st = $("#stage"), sr = st.getBoundingClientRect(), tr = t.getBoundingClientRect();
    for (let i = 0; i < cells.length - 1; i++) {
      const a = cells[i].getBoundingClientRect(), c = cells[i + 1].getBoundingClientRect(), x = (a.right + c.left) / 2;
      const h = document.createElement("div"); h.className = "colh"; h.title = "Drag to change the column widths";
      h.style.cssText = `left:${x - sr.left + st.scrollLeft - 5}px;top:${tr.top - sr.top + st.scrollTop}px;height:${tr.height}px`;
      h.onpointerdown = e => {
        e.preventDefault(); remember(); h.setPointerCapture(e.pointerId); h.classList.add("on");
        const ws = cells.map(x => x.getBoundingClientRect().width), tot = ws.reduce((p, q) => p + q, 0), x0 = e.clientX, pair = ws[i] + ws[i + 1], min = tot * .08;
        h.onpointermove = ev => { const d = ev.clientX - x0, wi = Math.max(min, Math.min(pair - min, ws[i] + d)), w = ws.slice(); w[i] = wi; w[i + 1] = pair - wi;
          colApply(t, w.map(v => v / tot * 100)); h.style.left = (parseFloat(h.style.left) + (ev.clientX - (h._lx || x0))) + "px"; h._lx = ev.clientX; };
        h.onpointerup = () => { h.onpointermove = h.onpointerup = null; dcFlow(); drawBar(); };
      };
      box.appendChild(h);
    }
  }

  /* ------------------------------------------------------------------ undo / redo (whole page set, last 10 steps) */
  const UNDO = [], REDO = []; let lastMark = 0;
  const snapDoc = () => ({ type: state.type, html: doc.innerHTML.replace(/ sel(?=["\s])/g, ""), slots: Object.assign({}, state.slots), focus: Object.assign({}, state.focus) });
  function remember() { UNDO.push(snapDoc()); if (UNDO.length > 10) UNDO.shift(); REDO.length = 0; lastMark = Date.now(); undoUI(); }
  function undoUI() { $("#undoBtn").disabled = !UNDO.length; $("#redoBtn").disabled = !REDO.length; }
  function applySnap(s) {
    selectBlk(null); doc.innerHTML = s.html; state.slots = s.slots; state.focus = s.focus;
    $$(".spread-wrap", doc).forEach(w => { const c = $(".pgctl", w); if (c) c.remove(); });
    dcNumber(); layout(); markOverflow(); wordCount();
  }
  function undo() { const s = UNDO.pop(); if (!s || s.type !== state.type) { UNDO.length = 0; return undoUI(); } REDO.push(snapDoc()); applySnap(s); undoUI(); toast("Undone"); }
  function redo() { const s = REDO.pop(); if (!s || s.type !== state.type) { REDO.length = 0; return undoUI(); } UNDO.push(snapDoc()); applySnap(s); undoUI(); toast("Redone"); }
  function resetHistory() { UNDO.length = REDO.length = 0; undoUI(); }
  $("#undoBtn").onclick = undo; $("#redoBtn").onclick = redo;
  doc.addEventListener("beforeinput", () => { if (Date.now() - lastMark > 1500) remember(); lastMark = Date.now(); });
  document.addEventListener("keydown", e => {
    if (!(e.metaKey || e.ctrlKey) || e.key.toLowerCase() !== "z" || (e.target.closest && e.target.closest(".ed,input,textarea,select"))) return;
    e.preventDefault(); e.shiftKey ? redo() : undo();
  });

  /* word + page count in the top bar */
  let wcT; function wordCount() {
    clearTimeout(wcT); wcT = setTimeout(() => {
      const txt = $$(".d-spread", doc).map(sp => sp.innerText).join(" "), w = (txt.match(/[A-Za-z0-9À-ɏ'’]+/g) || []).length, p = pageCount();
      $("#wcount").textContent = `${w.toLocaleString("en-GB")} words · ${p} page${p === 1 ? "" : "s"}`;
    }, 250);
  }

  /* simple name dialog (returns null on cancel) */
  function ask(title, value, hint, okLabel) {
    return new Promise(res => {
      const box = $("#ask"), inp = $("#askInput"); $("#askTitle").textContent = title; $("#askHint").textContent = hint || ""; $("#askOk").textContent = okLabel || "Save";
      inp.value = value || ""; box.hidden = false; setTimeout(() => { inp.focus(); inp.select(); }, 20);
      const done = v => { box.hidden = true; $("#askForm").onsubmit = null; $("#askCancel").onclick = null; res(v); };
      $("#askForm").onsubmit = e => { e.preventDefault(); const v = inp.value.trim(); done(v || null); };
      $("#askCancel").onclick = () => done(null);
    });
  }

  /* new project / uploads */
  $("#newProj").onclick = async () => {
    if (!WS.on) return;
    const n = await ask("New project", "", "Creates source/<name>/ with media, info, saves, PDF outputs and HTML outputs folders.", "Create"); if (!n) return;
    const name = safeName(n); for (const sub of SUBS) await subDir(name, sub);
    await scanSource(); state.project = name; fillProjectSelect(); renderSaves(); fillFromProject(name); toast("Project created: " + name);
  };
  $("#upFilesBtn").onclick = () => {
    if (!WS.on) return toast("Connect the platform folder first");
    if (state.project === PH) return toast("Choose or create a project first");
    $("#upFiles").click();
  };
  $("#upFiles").addEventListener("change", async e => {
    const files = Array.from(e.target.files); e.target.value = ""; let img = 0, info = 0, skip = 0;
    for (const f of files) {
      const isImg = f.type.startsWith("image/") || IMG_RX.test(f.name), isInfo = !isImg && INFO_RX.test(f.name);
      if (!isImg && !isInfo) { skip++; continue; }
      await writeFile(await subDir(state.project, isImg ? "media" : "info"), f.name, f); isImg ? img++ : info++;
    }
    if (img) await scanSource();
    toast(`${img} image${img === 1 ? "" : "s"} → media, ${info} file${info === 1 ? "" : "s"} → info` + (skip ? `, ${skip} skipped` : ""));
  });

  /* ------------------------------------------------------------------ saves: a small JSON "index" (text + image references) */
  const styleName = st => { const t = $(`.stile[data-style="${st}"]`); return t ? t.textContent.trim() : st; };
  /* canvas -> data URL: PNG when the image has transparency (logos), otherwise JPEG (JPEG would turn transparent areas black) */
  function encodeCanvas(c, q = .86) {
    try { const d = c.getContext("2d").getImageData(0, 0, c.width, c.height).data;
      for (let i = 3; i < d.length; i += 16) if (d[i] < 250) return c.toDataURL("image/png"); } catch (e) {}
    return c.toDataURL("image/jpeg", q);
  }
  async function toDataURL(src, max = 2400) {
    if (src.startsWith("data:")) return src;
    const im = new Image(); im.src = src; await im.decode();
    const sc = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas");
    c.width = Math.round(im.naturalWidth * sc); c.height = Math.round(im.naturalHeight * sc); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
    return encodeCanvas(c);
  }
  const inlCache = new Map();
  async function inlineImgs(root) {
    for (const im of $$("img", root)) {
      const s0 = im.getAttribute("src") || ""; if (!s0.startsWith("blob:")) continue;
      try { if (!inlCache.has(s0)) inlCache.set(s0, await toDataURL(s0)); im.setAttribute("src", inlCache.get(s0)); }
      catch (err) {                                            // stale link: re-read the image from the library entry for that slot
        const f = im.closest("[data-slot],[data-mirror-slot]"), id = f && state.slots[f.dataset.slot || f.dataset.mirrorSlot], e = id && byId(id);
        try { if (e) im.setAttribute("src", await toDataURL(e.src)); } catch (e2) { console.warn("image skipped in export", e2); }
      }
    }
  }
  async function snapshot(full, name) {
    const spreads = $$(".d-spread", doc).map(sp => {
      const c = sp.cloneNode(true);
      $$(".d-fig img,.d-logo", c).forEach(i => i.removeAttribute("src")); $$(".d-icon", c).forEach(i => { i.innerHTML = ""; });
      $$(".sel,.over,.dc-step.on,.dc-fc.on", c).forEach(n => n.classList.remove("sel", "over", "on")); c.style.transform = "";
      return c.outerHTML;
    });
    const images = {};
    for (const [slot, id] of Object.entries(state.slots)) {
      if (!id || id === "ph") { images[slot] = { ph: 1 }; continue; }
      const e = byId(id); if (!e) { images[slot] = { ph: 1 }; continue; }
      const isLib = !e.fs && !e.embed && (e.id.startsWith("logo:") || (window.IMAGE_LIBRARY || []).some(x => x.id === e.id));
      const ref = e.fs ? { project: e.project, file: e.file } : isLib ? { lib: e.id } : {};
      if (full || !Object.keys(ref).length) ref.data = await toDataURL(e.src);
      images[slot] = ref;
    }
    return { app: "gmi-templating", version: 2, name: name || "", saved: new Date().toISOString(), full: !!full,
             type: state.type, region: state.region, style: state.style, orient: state.orient, paper: state.paper, project: state.project, focus: Object.assign({}, state.focus), images, spreads };
  }
  let sid = 0;
  async function restore(v) {
    if (!v || v.app !== "gmi-templating" || !window.TEMPLATES[v.type]) return toast("That isn't a templating save file");
    try { await autosave(); } catch (e) { console.warn(e); }   // whatever is on screen is backed up before it is replaced (project autosave, or WiP)
    curSave = v.name || ""; wipName = ""; asked.add(window.TEMPLATES[v.type] ? v.type : "documentation");
    if (v.type !== state.type) toast(`Switching to ${window.TEMPLATES[v.type].name}`);
    switchType(v.type, true);                       // keeps the other document types as they are
    if (v.region) setRegion(v.region, true);
    state.style = STYLES.includes(v.style) ? v.style : "s1"; state.orient = v.orient || "portrait";
    if (pp()) { const h0 = String((v.spreads || [])[0] || ""), m = h0.match(/data-pw="(\d+)" data-ph="(\d+)"|data-ph="(\d+)"[^>]*data-pw="(\d+)"/);   // paper size for the whole document
      state.paper = v.paper === "a3" || v.paper === "a4" ? v.paper : m ? (Math.max(...m.slice(1).filter(Boolean).map(Number)) > 300 ? "a3" : "a4") : /data-paper="a3"/.test(h0) ? "a3" : "a4"; }
    state.project = projects().includes(v.project) ? v.project : PH; syncUI(); build();
    doc.innerHTML = "";                              // rebuild every spread: documents can have any number of pages
    v.spreads.forEach(h => { const t = document.createElement("div"); t.innerHTML = h; const w = document.createElement("div"); w.className = "spread-wrap"; w.appendChild(t.firstElementChild); doc.appendChild(w); });
    decorate(); layout(); state.slots = {}; state.focus = Object.assign({}, v.focus || {}); let missing = 0;
    await dimsReady();
    for (const [slot, ref] of Object.entries(v.images || v.slots || {})) {
      let id = "ph";
      if (typeof ref === "string") id = byId(ref) ? ref : "ph";                                   // older browser-saved versions
      else if (ref.project && byId(`${ref.project}/${ref.file}`)) id = `${ref.project}/${ref.file}`;
      else if (ref.lib && byId(ref.lib)) id = ref.lib;
      else if (ref.data) { id = "saved-" + (++sid); LIB.push({ id, project: "Saved", w: 0, h: 0, src: ref.data, embed: true }); }
      else if (!ref.ph) missing++;
      setSlot(slot, id, state.focus[slot]);
    }
    syncOrient(); setOrient(state.orient); renderSaves();
    requestAnimationFrame(() => { $$(".d-title").forEach(fitTitle); dcFlow(); markOverflow(); resetHistory(); wordCount(); });
    autoAt = Date.now() + 1500; Object.assign(LAST, { t: Date.now() + 1500, kind: "open", name: v.name || "" });
    toast(`Opened “${v.name || "save"}”` + (missing ? ` (${missing} image${missing > 1 ? "s" : ""} not found, shown as placeholders)` : ""));
  }
  async function savesFor(p) {
    if (!WS.on || p === PH) return [];
    const dir = await subDir(p, "saves"), out = [];
    for (const fh of await listFiles(dir, /\.json$/i)) { const f = await fh.getFile(); out.push({ fh, name: fh.name.replace(/\.json$/i, ""), when: f.lastModified, dir }); }
    return out.sort((a, b) => b.when - a.when);
  }
  /* saves: one dropdown opens a version (or a file); Manage saves lists them with delete + export */
  const verLabel = v => { const d = new Date(v.when); return `${v.name} · ${d.toLocaleDateString("en-GB", { day: "numeric", month: "short" })} ${d.toTimeString().slice(0, 5)}`; };
  let SAVES = [], curSave = "";                 // curSave: name of the save that's open (shown in the Open dropdown)
  async function renderSaves() {
    SAVES = await savesFor(state.project);
    $("#vCount").textContent = WS.on && state.project !== PH ? `${SAVES.length} save${SAVES.length === 1 ? "" : "s"}` : "";
    $("#manageSaves").hidden = !WS.on || state.project === PH; $("#upFilesBtn").hidden = !WS.on;
    $("#verSel").innerHTML = `<option value="">${curSave ? chEsc(curSave) : "Open&hellip;"}</option>` + (SAVES.length ? `<optgroup label="Saved versions">${SAVES.map((v, i) => { const t = typeOfName(v.name); return `<option value="${i}">${t ? "[" + chEsc(window.TEMPLATES[t].name) + "] " : ""}${chEsc(verLabel(v))}</option>`; }).join("")}</optgroup>` : "")
      + `<option value="file">From a file&hellip;</option>`;
    if (!$("#savesDlg").hidden) drawSaves();
  }
  $("#verSel").onchange = async e => {
    const v = e.target.value; e.target.value = "";
    if (v === "file") return $("#openSaveFile").click();
    if (v !== "") await openSave(SAVES[+v]);
  };
  function drawSaves() {
    $("#sdTitle").textContent = `${pname(state.project)}: ${SAVES.length} save${SAVES.length === 1 ? "" : "s"}`;
    $("#exportSaves").disabled = !SAVES.length; $("#pruneSaves").disabled = SAVES.length <= 5;
    $("#sdHint").textContent = "Saves live in the project's saves folder. \"Autosave\" is the automatic backup, updated every 5 minutes while you work.";
    $("#sdList").innerHTML = SAVES.length ? "" : `<p class="hint">No saves yet.</p>`;
    SAVES.forEach(v => {
      const row = document.createElement("div"); row.className = "ver";
      row.innerHTML = `${tPill(typeOfName(v.name))}<span title="${chEsc(v.name)}">${chEsc(verLabel(v))}</span><button>Open</button><button class="x">Delete</button>`;
      const [ob, xb] = row.querySelectorAll("button"); ob.title = "Open this save"; xb.title = "Delete this save (click twice to confirm)";
      ob.onclick = async () => { $("#savesDlg").hidden = true; if (!await openSave(v)) $("#savesDlg").hidden = false; };
      xb.onclick = async () => {
        if (!xb.dataset.sure) { xb.dataset.sure = 1; xb.textContent = "Sure?"; setTimeout(() => { delete xb.dataset.sure; xb.textContent = "Delete"; }, 2500); return; }
        try { await trashFile(v.dir, v.fh.name, state.project, "saves"); toast("Save moved to the trash folder"); } catch (e) { console.error(e); toast("Couldn't move that file to trash, so it was left where it is"); } renderSaves();
      };
      $("#sdList").appendChild(row);
    });
  }
  $("#pruneSaves").onclick = async () => {
    const del = [...SAVES].sort((a, b) => b.when - a.when).slice(5); if (!del.length) return toast("Nothing to delete: there are 5 saves or fewer");
    if (await choose(`Delete ${del.length} older save${del.length === 1 ? "" : "s"}?`, `Keeps the 5 most recent saves of “${pname(state.project)}” and moves the other ${del.length} to the trash folder.`, ["Cancel", `Delete ${del.length}`]) !== 1) return;
    let n = 0; for (const v of del) { try { await trashFile(v.dir, v.fh.name, state.project, "saves"); n++; } catch (e) { console.error(e); } }
    await renderSaves(); toast(`Moved ${n} save${n === 1 ? "" : "s"} to the trash folder`);
  };
  $("#manageSaves").onclick = () => { $("#savesDlg").hidden = false; drawSaves(); };
  $("#delProj").onclick = async () => {
    const p = state.project; if (!WS.on || p === PH) return;
    if (await choose(`Delete “${pname(p)}”?`, "This moves the whole project folder (photos, info files, saves and outputs) into the trash folder next to source. Nothing is permanently deleted.", ["Cancel", "Delete project"]) !== 1) return;
    try { await trashProject(p); } catch (e) { console.error(e); return toast("Couldn't move that project to trash, so it was left where it is"); }
    $("#savesDlg").hidden = true; await scanSource(); state.project = PH; fillProjectSelect(); fillFromProject(PH); renderSaves(); toast(`${pname(p)} moved to the trash folder`);
  };
  $("#sdClose").onclick = () => { $("#savesDlg").hidden = true; };
  $("#saveVer").onclick = async () => {
    // name: the open version's name with the date/time appended (any earlier date/time replaced); new documents get project - type - style
    const d = new Date(), stamp = `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()} ${String(d.getHours()).padStart(2, "0")}.${String(d.getMinutes()).padStart(2, "0")}`;
    const proj = state.project === PH ? "" : pname(state.project) + " - ";
    const base = curSave ? curSave.replace(/ - \d{1,2} [A-Z][a-z]{2}( \d{4})?( \d{2}\.\d{2})?$/, "") : `${proj}${TPL.name} - ${styleName(state.style)}`, def = `${base} - ${stamp}`;
    if (!WS.on) {
      const n = await ask("Save version as", def, "Folder not connected, so the save downloads as a .json file. Use Open… > From a file to load it again."); if (!n) return;
      download(new Blob([JSON.stringify(await snapshot(true, n))], { type: "application/json" }), safeName(n) + ".json"); return toast("Save downloaded");
    }
    if (state.project === PH) return toast("Choose or create a project first");
    const n = curSave ? def : await ask("Save version as", def, `Saved to source/${state.project}/saves. Images are referenced from the media folder, not copied.`); if (!n) return;
    const dir = await subDir(state.project, "saves"); let file = safeName(n), k = 2;
    while (await exists(dir, file + ".json")) file = `${safeName(n)} (${k++})`;
    await writeFile(dir, file + ".json", JSON.stringify(await snapshot(false, n)));
    curSave = n; renderSaves(); toast("Saved: " + file); savedNote(n); Object.assign(LAST, { t: Date.now(), kind: "save", name: n });
  };
  /* after a save: the document title shows the document type as a pill beside the saved name */
  function savedNote() { const el = $("#docTitle"); if (!el) return; let p = $("#savedPill"); if (!p) { p = document.createElement("span"); p.id = "savedPill"; el.after(p); }
    p.innerHTML = tPill(state.type) + `<em>Saved ${new Date().toTimeString().slice(0, 5)}</em>`; }
  /* autosave: every 5 minutes, if anything changed, the project's rolling backup "Autosave - <type>.json" (in saves/) is overwritten.
     Needs a connected folder and a project. The Save button greys out for a few seconds to show it happened. */
  let autoAt = Date.now(), autoBusy = false;
  /* documents that were never saved into a project are still protected: they autosave as "WiP - <type> - <date time>" in a project called WiP */
  const stampNow = () => { const d = new Date(); return `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()} ${String(d.getHours()).padStart(2, "0")}.${String(d.getMinutes()).padStart(2, "0")}`; };
  async function autosave() {
    if (autoBusy || !WS.on || lastMark <= autoAt) return;
    const wip = state.project === PH; if (wip && (!isDoc() || !dcBlocks().length)) return;
    autoBusy = true; const t0 = Date.now();
    try {
      if (wip && !wipName) wipName = `WiP - ${TPL.name} - ${stampNow()}`;
      const name = wip ? wipName : `Autosave - ${TPL.name}`;
      await writeFile(await subDir(wip ? WIP : state.project, "saves"), safeName(name) + ".json", JSON.stringify(await snapshot(wip, name)));
      if (wip && !WS.projects.includes(WIP)) { await scanSource(); fillProjectSelect(); }
      Object.assign(LAST, { t: Date.now(), kind: wip ? "wip" : "auto", name });
      autoAt = t0; renderSaves();
      const bt = $("#saveVer"); bt.classList.add("auto"); bt.disabled = true; bt.textContent = "Autosaved"; bt.title = "Backed up automatically at " + new Date().toTimeString().slice(0, 5);
      setTimeout(() => { bt.classList.remove("auto"); bt.disabled = false; bt.textContent = "Save"; bt.title = "Save this document as a version"; }, 5000);
    } catch (e) { console.warn("autosave failed", e); }
    autoBusy = false;
  }
  setInterval(autosave, 5 * 60 * 1000);
  setInterval(() => { if (state.project === PH) autosave(); }, 60 * 1000);   // work in progress with no project: backed up every minute

  /* protect a new document: the first time a component goes into a document that has not been saved or opened,
     ask what it is - New (name it, it is saved straight away), Load (open a save instead) or Practice (carry on; it is still backed up as WiP) */
  async function quickSave() {
    const base = `${pname(state.project)} - ${TPL.name} - ${styleName(state.style)}`, n = `${base} - ${stampNow()}`, dir = await subDir(state.project, "saves"); let file = safeName(n), k = 2;
    while (await exists(dir, file + ".json")) file = `${safeName(n)} (${k++})`;
    await writeFile(dir, file + ".json", JSON.stringify(await snapshot(false, n))); curSave = n; autoAt = Date.now(); renderSaves(); toast(`Saved: ${file}`); savedNote(n); Object.assign(LAST, { t: Date.now(), kind: "save", name: n });
  }
  /* document type of a save: from its name ("... - Alert - ...", "Autosave - Training"), otherwise from the file itself */
  const typeKeys = () => Object.keys(window.TEMPLATES).filter(t => window.TEMPLATES[t].name);
  const typeOfName = n => typeKeys().sort((a, b) => window.TEMPLATES[b].name.length - window.TEMPLATES[a].name.length).find(t => new RegExp("(^|[\\s-])" + window.TEMPLATES[t].name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "([\\s.-]|$)").test(n)) || "";
  async function typeOfSave(v) { if (v.t === undefined) { v.t = typeOfName(v.name); if (!v.t) { try { v.t = JSON.parse(await (await v.fh.getFile()).text()).type || ""; } catch (e) { v.t = ""; } } } return v.t; }
  const SHORT = { documentation: "Doc", training: "Train", alert: "Alert", blank: "Blank" };   // short labels for the type pills
  const tPill = t => t && window.TEMPLATES[t] ? `<i class="tpill" data-t="${t}" title="${chEsc(window.TEMPLATES[t].name)}">${chEsc(SHORT[t] || window.TEMPLATES[t].name)}</i>` : "";
  const aAn = w => (/^[aeiou]/i.test(w) ? "an " : "a ") + w;
  /* open a save; if it is a different document type from the one on screen, ask before switching. Returns false when the user backs out. */
  async function openSave(v) {
    let j; try { j = JSON.parse(await (await v.fh.getFile()).text()); } catch (e) { toast("Couldn't read that save"); return false; }
    return openJson(j);
  }
  async function openJson(j) {
    const t = j && window.TEMPLATES[j.type] ? j.type : "";
    if (t && t !== state.type && isDoc() && await choose(`That's ${aAn(window.TEMPLATES[t].name)} document`, `You are working on ${aAn(TPL.name)} document. Do you want to switch to ${window.TEMPLATES[t].name} and open it? What is on screen now is backed up first.`, ["Cancel", "Switch and open"]) !== 1) return false;
    await restore(j); return true;
  }
  /* Load: the project list, newest first, each with a pill for every document type it holds. Click a pill for that type's latest save, or the row for the newest. */
  async function projectRows() {
    const rows = []; for (const p of projects()) { if (p === PH) continue; const sv = await savesFor(p); if (!sv.length) continue; const by = {}; for (const v of sv) { const t = await typeOfSave(v); if (t && !by[t]) by[t] = v; } rows.push({ p, when: sv[0].when, latest: sv[0], by, n: sv.length }); }
    return rows.sort((a, b) => (a.p === WIP) - (b.p === WIP) || b.when - a.when);
  }
  /* a clean document of one type (used by the home screen's New) */
  function newDoc(t) { if (!window.TEMPLATES[t]) return; delete DOCS[t]; asked.delete(t);
    if (state.type === t) { curSave = ""; wipName = ""; resetHistory(); state.slots = {}; state.focus = {}; state.project = PH; syncUI(); build(); renderSaves(); } else { switchType(t); if (DOCS[t]) { delete DOCS[t]; } state.project = PH; }
    { const sp = $("#savedPill"); if (sp) sp.remove(); } fillProjectSelect(); LAST.t = 0; }
  /* name a document: its project is created (or reused) and it is saved straight away */
  async function startNamed(n) { const name = safeName(n), had = WS.projects.includes(name); for (const sub of SUBS) await subDir(name, sub);
    if (!had) await scanSource(); state.project = name; fillProjectSelect(); await quickSave(); }
  /* Make a copy: a new project holding what is on screen. Pictures from this project's media folder are copied into the new project
     (so the two can change separately); pictures from shared libraries (_People, _Logos) or other projects keep pointing where they were.
     The original gets a saved version first if it has unsaved edits. Returns the new project's name, or "" if it already exists. */
  async function makeCopy(n) {
    const name = safeName(n), from = state.project; if (!WS.on || from === PH) return "";
    if (WS.projects.includes(name) || name === from) return "";
    if (lastMark > LAST.t) await quickSave();
    for (const sub of SUBS) await subDir(name, sub);
    const media = await subDir(name, "media"), moved = {};
    for (const [slot, id] of Object.entries(state.slots)) {
      const e = id && id !== "ph" && byId(id); if (!e || !e.fs || e.project !== from) continue;
      if (!moved[e.file]) { try { const f = await (await (await subDir(from, "media")).getFileHandle(e.file)).getFile(); await writeFile(media, e.file, f); moved[e.file] = 1; } catch (err) { console.warn("copy", e.file, err); continue; } }
      state.slots[slot] = `${name}/${e.file}`;
    }
    await scanSource(); state.project = name; curSave = ""; fillProjectSelect(); await quickSave(); return name;
  }
  async function loadPicker() {
    if (!WS.on) { $("#openSaveFile").click(); return "file"; }
    const rows = await projectRows();
    for (;;) {
      const r = await new Promise(res => {
        $("#chTitle").textContent = "Open a project"; $("#chHint").textContent = rows.length ? "Click a project to open its latest save, or a coloured label to open the latest of that document type." : "No saved projects in the connected folder yet."; const box = $("#chBtns"); box.innerHTML = ""; box.classList.add("col");
        const close = v => { $("#choose").hidden = true; box.classList.remove("col"); res(v); };
        rows.forEach(w => { const b = document.createElement("div"); b.className = "prow"; b.tabIndex = 0; b.innerHTML = `<span class="pn"><b>${chEsc(pname(w.p))}</b><em>${new Date(w.when).toLocaleDateString("en-GB", { day: "numeric", month: "short" })} ${new Date(w.when).toTimeString().slice(0, 5)}</em></span><span class="pt">${Object.keys(w.by).map(tPill).join("")}</span>`;
          b.onclick = e => { const pl = e.target.closest(".tpill"); close(pl ? w.by[pl.dataset.t] : w.latest); }; b.onkeydown = e => { if (e.key === "Enter") close(w.latest); }; box.appendChild(b); });
        const ft = document.createElement("div"); ft.className = "pfoot"; ft.innerHTML = `<button class="mini" type="button">From a file…</button><button class="mini on" type="button">Back</button>`;
        ft.firstChild.onclick = () => close("file"); ft.lastChild.onclick = () => close("back"); box.appendChild(ft);
        $("#choose").hidden = false;
      });
      if (r === "back") return "back";
      if (r === "file") { $("#openSaveFile").click(); return "file"; }
      if (await openSave(r)) return "opened";      // backed out of switching type: show the list again
    }
  }
  async function protect() {
    if (!isDoc() || curSave || asked.has(state.type) || !dcBlocks().length || !$("#choose").hidden || !$("#ask").hidden) return;
    asked.add(state.type); const type = state.type;
    const hint = WS.on ? "New: name it and it is saved straight away.\nLoad: open a project you saved before.\nPractice: carry on without naming it. It is still backed up automatically as a WiP file."
      : "The platform folder is not connected, so nothing can be saved automatically.\nNew downloads a save file.\nPractice carries on with no backup. Connect the folder (top right) to be protected.";
    for (;;) {
      const pick = await choose(`New ${TPL.name} document`, hint, ["Practice", "Load…", "New"]);
      if (pick === 1) { const r = await loadPicker(); if (r === "back") continue;
        if (r === "file") { const inp = $("#openSaveFile"), again = () => { asked.delete(type); if (state.type === type) protect(); }; inp.addEventListener("cancel", again, { once: true }); inp.addEventListener("change", () => inp.removeEventListener("cancel", again), { once: true }); }
        return; }
      if (pick === 2) {
        if (!WS.on) return $("#saveVer").click();
        const cur = state.project === PH || state.project === WIP ? "" : pname(state.project);
        const n = await ask("Name this document", cur, "This is the project it is saved under. Use an existing project name to add it to that project.", "Save"); if (!n) continue;
        await startNamed(n); return;
      }
      autosave(); return;   // Practice: first WiP backup straight away
    }
  }
  $("#openSaveFile").addEventListener("change", async e => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    let j; try { j = JSON.parse(await f.text()); } catch (err) { return toast("Couldn't read that file"); }
    if (j && j.shared) return openShared(j); openJson(j);
  });

  /* ---------------------------------------------------------------- sharing
     Share writes ONE file (<name>.gmi): the save with every picture inside it, so nothing needs zipping or unzipping.
     Opening a .gmi with "Open from a file" adds it as a new project on that computer (pictures go into its media folder). */
  async function shareFile() {
    toast("Packing the document and its pictures…");
    const base = state.project === PH ? "Shared " + TPL.name.toLowerCase() : pname(state.project), j = await snapshot(true, base);
    for (const ref of Object.values(j.images || {})) if (ref && ref.data && !ref.file) ref.file = "";      // file names are made up on the other side if missing
    j.shared = { at: new Date().toISOString(), from: base };
    const blob = new Blob([JSON.stringify(j)], { type: "application/octet-stream" }), name = safeName(base) + ".gmi";
    download(blob, name); return { name, mb: Math.round(blob.size / 1048576 * 10) / 10 };
  }
  async function openShared(j) {
    const imgs = j.images || {};
    if (!WS.on) {                                     // no folder: open it as it is (pictures come from inside the file)
      for (const ref of Object.values(imgs)) if (ref && ref.data) { delete ref.project; delete ref.file; }
      delete j.shared; return openJson(j);
    }
    const base = safeName(j.shared.from || (j.project && j.project !== PH ? pname(j.project) : "Shared document"));
    let name = base; for (let k = 1; WS.projects.includes(name) || name === WIP; k++) name = `${base} (shared${k > 1 ? " " + k : ""})`;
    for (const sub of SUBS) await subDir(name, sub);
    const media = await subDir(name, "media"), used = new Set(); let n = 0;
    for (const [slot, ref] of Object.entries(imgs)) {
      if (!ref || !ref.data) { if (ref && ref.project) { delete ref.project; delete ref.file; ref.ph = 1; } continue; }
      const ext = ref.data.startsWith("data:image/png") ? "png" : "jpg";
      let fn = safeName((ref.file || `picture ${++n}`).replace(/\.[a-z0-9]+$/i, "")) + "." + ext; for (let c = 2; used.has(fn); c++) fn = fn.replace(/( \(\d+\))?\.(\w+)$/, ` (${c}).$2`); used.add(fn);
      try { await writeFile(media, fn, await (await fetch(ref.data)).blob()); imgs[slot] = { project: name, file: fn }; } catch (err) { console.warn("shared picture", err); }
    }
    j.project = name; delete j.shared; j.name = `${name} - ${(window.TEMPLATES[j.type] || TPL).name} - shared`;
    const sv = await subDir(name, "saves"); await writeFile(sv, safeName(`${j.name} ${stampNow()}`) + ".json", JSON.stringify(j));
    await scanSource(); fillProjectSelect(); const ok = await openJson(j);
    if (ok !== false) toast(`Shared document added as the project "${name}"`);
    return name;
  }

  /* ---------------------------------------------------------------- Word + PDF
     The text as a plain Word file (editable, no pictures or styling) and the full-looking PDF beside it */
  $("#outWord").onclick = async () => {
    const b = $("#outWord"); b.disabled = true; toast("Building the Word file and the PDF…");
    try {
      const name = outName(), pages = dcPages().length ? dcPages() : $$(".d-spread", doc);
      const docx = new Blob([zipStore(window.GMI_WORD.build(pages, docTitle()))], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
      const pdf = await buildPdf();
      download(docx, name + ".docx"); setTimeout(() => download(pdf, name + ".pdf"), 700);
      if (WS.on && state.project !== PH) { const d = await subDir(state.project, "Word outputs"); await writeFile(d, name + ".docx", docx); await writeFile(d, name + ".pdf", pdf);
        toast(`Word file and PDF downloaded; copies kept in ${pname(state.project)}/Word outputs`); }
      else toast("Word file and PDF downloaded");
    } catch (err) { console.error(err); toast("Couldn't build the Word file"); }
    b.disabled = false;
  };
  $("#exportSaves").onclick = async () => {
    const list = await savesFor(state.project); if (!list.length) return;
    const files = []; for (const v of list) files.push({ name: v.fh.name, data: new Uint8Array(await (await v.fh.getFile()).arrayBuffer()) });
    download(zipStore(files), safeName(pname(state.project) + " - saves") + ".zip"); toast(`Exported ${files.length} saves`);
  };

  /* minimal ZIP writer (stored, no compression) */
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zipStore(files) {
    const enc = new TextEncoder(), parts = [], cen = []; let off = 0, dt = new Date();
    const dtime = (dt.getHours() << 11) | (dt.getMinutes() << 5) | (dt.getSeconds() >> 1), ddate = ((dt.getFullYear() - 1980) << 9) | ((dt.getMonth() + 1) << 5) | dt.getDate();
    const u16 = v => [v & 255, (v >>> 8) & 255], u32 = v => [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255];
    for (const f of files) {
      const nm = enc.encode(f.name), crc = crc32(f.data), sz = f.data.length;
      const lh = new Uint8Array([...u32(0x04034b50), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(dtime), ...u16(ddate), ...u32(crc), ...u32(sz), ...u32(sz), ...u16(nm.length), ...u16(0)]);
      parts.push(lh, nm, f.data);
      cen.push(new Uint8Array([...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(dtime), ...u16(ddate), ...u32(crc), ...u32(sz), ...u32(sz), ...u16(nm.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(off)]), nm);
      off += lh.length + nm.length + sz;
    }
    const cenLen = cen.reduce((a, b) => a + b.length, 0);
    const end = new Uint8Array([...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(cenLen), ...u32(off), ...u16(0)]);
    return new Blob([...parts, ...cen, end], { type: "application/zip" });
  }

  /* ------------------------------------------------------------------ interactive site map
     OpenFreeMap vector tiles (free, no key, OK for business use) via MapLibre; postcodes.io + Photon for search. Needs internet. */
  let MAP = null, MARK = null, APM = null, mapSlot = null;
  const apSvg = () => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 46" width="40" height="46"><rect x="1" y="1" width="38" height="34" rx="4" fill="#1a8f3c" stroke="#fff" stroke-width="2"/><path d="M14 35l6 9 6-9z" fill="#1a8f3c"/><g fill="#fff"><circle cx="13" cy="10" r="2.6"/><circle cx="27" cy="10" r="2.6"/><circle cx="13" cy="26" r="2.6"/><circle cx="27" cy="26" r="2.6"/><path d="M20 11l3 3h-2v6h-2v-6h-2z"/><path d="M11 18h5v-2l3 3-3 3v-2h-5z" transform="translate(-1 0)"/><path d="M29 18h-5v-2l-3 3 3 3v-2h5z" transform="translate(1 0)"/><path d="M20 27l-3-3h2v-3h2v3h2z"/></g></svg>`;
  function setAP(lngLat) {
    if (!lngLat) { if (APM) { APM.remove(); APM = null; } $("#mapAP").textContent = "+ Assembly point"; return; }
    if (!APM) { const el = document.createElement("div"); el.className = "gmi-pin"; el.style.cursor = "grab"; el.innerHTML = apSvg();
      APM = new maplibregl.Marker({ element: el, draggable: true, anchor: "bottom" }); }
    APM.setLngLat(lngLat).addTo(MAP); $("#mapAP").textContent = "Remove assembly point";
  }
  /* extra markers: more locations (numbered pins, added by postcode) and place icons (parking, entrance, first aid...). All draggable; double-click one to remove it. */
  const PLACE = { park: ["Parking", "#0a6fc2", "P"], gate: ["Entrance", "#1d1d1b", "IN"], aid: ["First aid", "#119b24", "+"], welfare: ["Welfare", "#7a3fb0", "W"], office: ["Site office", "#4b4b50", "O"], deliv: ["Deliveries", "#e08a00", "D"], fire: ["Fire point", "#d20a11", "F"], wc: ["Toilets", "#0a6fc2", "WC"], info: ["Information", "#1d1d1b", "i"] };
  const placeSvg = k => { const [, col, g] = PLACE[k]; return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 46" width="40" height="46"><rect x="1" y="1" width="38" height="34" rx="4" fill="${col}" stroke="#fff" stroke-width="2"/><path d="M14 35l6 9 6-9z" fill="${col}"/><text x="20" y="${g.length > 1 ? 24 : 26}" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="${g.length > 1 ? 15 : 22}" fill="#fff">${g}</text></svg>`; };
  const numSvg = n => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 34 46" width="34" height="46"><path d="M17 1.5C8.4 1.5 1.5 8.3 1.5 16.7 1.5 28 17 44.5 17 44.5S32.5 28 32.5 16.7C32.5 8.3 25.6 1.5 17 1.5z" fill="#1d1d1b" stroke="#fff" stroke-width="2"/><text x="17" y="22" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="14" fill="#fff">${n}</text></svg>`;
  let EXTRA = [];
  const exSvg = x => x.k === "loc" ? numSvg(EXTRA.filter(e => e.k === "loc").indexOf(x) + 2) : placeSvg(x.k);
  const exRedraw = () => EXTRA.forEach(x => { x.m.getElement().innerHTML = exSvg(x); });
  function addExtra(k, lngLat) {
    const el = document.createElement("div"); el.className = "gmi-pin"; el.style.cursor = "grab"; el.title = (k === "loc" ? "Location" : PLACE[k][0]) + " - drag to move, double-click to remove";
    const x = { k, m: new maplibregl.Marker({ element: el, draggable: true, anchor: "bottom" }).setLngLat(lngLat).addTo(MAP) };
    el.addEventListener("dblclick", e => { e.stopPropagation(); x.m.remove(); EXTRA = EXTRA.filter(y => y !== x); exRedraw(); });
    EXTRA.push(x); exRedraw(); return x;
  }
  const clearExtra = () => { EXTRA.forEach(x => x.m.remove()); EXTRA = []; };
  const fitAll = () => { const pts = [MARK.getLngLat()].concat(EXTRA.filter(x => x.k === "loc").map(x => x.m.getLngLat())); if (pts.length < 2) return;
    const b = new maplibregl.LngLatBounds(pts[0], pts[0]); pts.forEach(p => b.extend(p)); MAP.fitBounds(b, { padding: 70, maxZoom: 16.5, duration: 0 }); };
  $("#mapIcon").onchange = e => { const k = e.target.value; e.target.value = ""; if (!PLACE[k]) return; const c = MAP.getCenter(), b = MAP.getBounds(), n = EXTRA.length;
    addExtra(k, [c.lng + (b.getEast() - c.lng) * (.2 + .12 * (n % 4)), c.lat - (c.lat - b.getSouth()) * (.25 + .1 * (n % 3))]); $("#mapMsg").textContent = "Drag the icon into place. Double-click it to remove it."; };
  $("#mapAdd").onclick = async () => { const q = $("#mapQ").value.trim(); if (!q) return ($("#mapMsg").textContent = "Type a postcode or address first, then press + Location.");
    $("#mapMsg").textContent = "Searching…";
    try { const ll = await geocode(q); if (!ll) { $("#mapMsg").textContent = "Couldn't find that. Try a full postcode."; return; }
          addExtra("loc", [ll[1], ll[0]]); fitAll(); $("#mapQ").value = ""; $("#mapMsg").textContent = "Location added. The map is scaled to show them all."; }
    catch (err) { $("#mapMsg").textContent = "Search failed: check the internet connection."; } };
  const MAP_STYLES = { "": "https://tiles.openfreemap.org/styles/liberty", bright: "https://tiles.openfreemap.org/styles/bright", light: "https://tiles.openfreemap.org/styles/positron" };
  let mapLook = "";
  $("#mapStyle").onchange = e => { mapLook = e.target.value; if (!window.__MAP_STYLE) MAP.setStyle(MAP_STYLES[mapLook] || MAP_STYLES[""]); };
  $("#mapAP").onclick = () => { if (APM) setAP(null); else { const c = MAP.getCenter(), b = MAP.getBounds(); setAP([c.lng + (b.getEast() - c.lng) * .35, c.lat + (b.getNorth() - c.lat) * .3]); } };
  const MAP_STYLE = "https://tiles.openfreemap.org/styles/liberty";
  const MAP_CREDIT = "© OpenFreeMap © OpenMapTiles © OpenStreetMap contributors";
  const pinSvg = () => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 34 46" width="34" height="46"><path d="M17 1.5C8.4 1.5 1.5 8.3 1.5 16.7 1.5 28 17 44.5 17 44.5S32.5 28 32.5 16.7C32.5 8.3 25.6 1.5 17 1.5z" fill="${state.main}" stroke="#fff" stroke-width="2"/><circle cx="17" cy="16.5" r="6" fill="#fff"/></svg>`;
  const PC_RX = /\b([A-Z]{1,2}\d[A-Z\d]?)\s*(\d[A-Z]{2})\b/i;
  function openMap(slot) {
    if (!window.maplibregl) return toast("The map library didn't load");
    mapSlot = slot; const f = slotEl(slot), a = f.offsetWidth / f.offsetHeight;
    $("#mapModal").hidden = false; $("#mapMsg").textContent = "";
    let w = Math.min(860, innerWidth * .9 - 40), h = w / a; const maxH = innerHeight * .62; if (h > maxH) { h = maxH; w = h * a; }
    const el = $("#leaf"); el.style.width = Math.round(w) + "px"; el.style.height = Math.round(h) + "px";
    if (!MAP) {
      MAP = new maplibregl.Map({ container: el, style: window.__MAP_STYLE || MAP_STYLE, center: [-2.2, 54.2], zoom: 5, preserveDrawingBuffer: true,
        pixelRatio: Math.max(2, window.devicePixelRatio || 1), attributionControl: { compact: true } });
      MAP.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");
      const pin = document.createElement("div"); pin.className = "gmi-pin"; pin.style.cursor = "grab";
      MARK = new maplibregl.Marker({ element: pin, draggable: true, anchor: "bottom" }).setLngLat([-2.2, 54.2]).addTo(MAP);
      MAP.on("click", e => MARK.setLngLat(e.lngLat));
      MAP.on("error", () => { $("#mapMsg").textContent = "Some map tiles couldn't load. Check the internet connection."; });
    }
    MARK.getElement().innerHTML = pinSvg();
    setTimeout(() => MAP.resize(), 30);
    const saved = f.dataset.map ? JSON.parse(f.dataset.map) : null;
    clearExtra();
    const look = (saved && saved.st) || ""; if (look !== mapLook) { mapLook = look; if (!window.__MAP_STYLE) MAP.setStyle(MAP_STYLES[look] || MAP_STYLES[""]); } $("#mapStyle").value = look;
    if (saved) { MAP.jumpTo({ center: [saved.lng, saved.lat], zoom: saved.z }); MARK.setLngLat([saved.mlng, saved.mlat]); $("#mapQ").value = saved.q || ""; setAP(saved.alat != null ? [saved.alng, saved.alat] : null);
      (saved.ex || []).forEach(x => { if (x[0] === "loc" || PLACE[x[0]]) addExtra(x[0], [x[1], x[2]]); }); }
    else {
      MAP.jumpTo({ center: [-2.2, 54.2], zoom: 5 }); MARK.setLngLat([-2.2, 54.2]); setAP(null);
      const m = $$(".ed", doc).map(x => x.innerText).join("\n").match(PC_RX); $("#mapQ").value = m ? `${m[1]} ${m[2]}`.toUpperCase() : "";
      if (m) $("#mapForm").requestSubmit();
    }
  }
  function closeMap() { $("#mapModal").hidden = true; }
  async function geocode(q) {
    if (window.__GEOCODE) return window.__GEOCODE(q);
    const pc = q.replace(/\s+/g, "");
    if (/^[A-Z]{1,2}\d[A-Z\d]?\d[A-Z]{2}$/i.test(pc)) {
      const r = await fetch("https://api.postcodes.io/postcodes/" + encodeURIComponent(pc));
      if (r.ok) { const j = await r.json(); if (j.result) return [j.result.latitude, j.result.longitude]; }
    }
    const r = await fetch("https://photon.komoot.io/api/?limit=1&lat=54&lon=-2&q=" + encodeURIComponent(q));
    const j = await r.json(), ft = j.features && j.features[0]; return ft ? [ft.geometry.coordinates[1], ft.geometry.coordinates[0]] : null;
  }
  $("#mapForm").onsubmit = async e => {
    e.preventDefault(); const q = $("#mapQ").value.trim(); if (!q) return;
    $("#mapMsg").textContent = "Searching…";
    try { const ll = await geocode(q); if (!ll) { $("#mapMsg").textContent = "Couldn't find that. Try a full postcode."; return; }
          MAP.jumpTo({ center: [ll[1], ll[0]], zoom: 16.5 }); MARK.setLngLat([ll[1], ll[0]]); $("#mapMsg").textContent = "Drag the marker to the exact spot."; }
    catch (err) { $("#mapMsg").textContent = "Search failed: check the internet connection."; }
  };
  $("#mapPin").onclick = () => MARK.setLngLat(MAP.getCenter());
  $("#mapClose").onclick = closeMap;
  $("#mapModal").addEventListener("mousedown", e => { if (e.target.id === "mapModal") closeMap(); });
  $("#mapImage").onclick = () => { closeMap(); pickSlot = mapSlot; slotEl(mapSlot).classList.add("sel"); openPicker(); };
  async function captureMap(scale = 2) {
    await new Promise(res => { if (MAP.loaded() && MAP.areTilesLoaded()) res(); else { MAP.once("idle", res); setTimeout(res, 5000); } });
    MAP.triggerRepaint(); await new Promise(r => MAP.once("render", r));
    const el = $("#leaf"), W = el.clientWidth, H = el.clientHeight, src = MAP.getCanvas();
    const c = document.createElement("canvas"); c.width = W * scale; c.height = H * scale;
    const g = c.getContext("2d"); g.drawImage(src, 0, 0, c.width, c.height); g.scale(scale, scale);
    const p = MAP.project(MARK.getLngLat()), pin = new Image();
    pin.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(pinSvg()); await pin.decode(); g.drawImage(pin, p.x - 17, p.y - 45, 34, 46);
    const keys = [];
    for (const x of EXTRA) { const q = MAP.project(x.m.getLngLat()), im = new Image(), loc = x.k === "loc"; im.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(exSvg(x)); await im.decode();
      if (loc) g.drawImage(im, q.x - 17, q.y - 45, 34, 46); else { g.drawImage(im, q.x - 20, q.y - 46, 40, 46); if (!keys.some(k => k[0] === PLACE[x.k][0])) keys.push([PLACE[x.k][0], PLACE[x.k][1]]); } }
    if (APM) keys.unshift(["Assembly point", "#1a8f3c"]);
    g.font = "bold 10px Arial"; keys.forEach((k, i) => { const lw = g.measureText(k[0]).width, y = H - 24 - i * 20;   // small key, bottom-left, one line per kind of icon
      g.fillStyle = "rgba(255,255,255,.92)"; g.fillRect(6, y, lw + 30, 18); g.fillStyle = k[1]; g.fillRect(10, y + 4, 10, 10); g.fillStyle = "#222"; g.fillText(k[0], 25, y + 13); });
    if (APM) {
      const q = MAP.project(APM.getLngLat()), ap = new Image(); ap.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(apSvg()); await ap.decode();
      g.drawImage(ap, q.x - 20, q.y - 46, 40, 46);
    }
    g.font = "9px Arial"; const tw = g.measureText(MAP_CREDIT).width;
    g.fillStyle = "rgba(255,255,255,.85)"; g.fillRect(W - tw - 8, H - 14, tw + 8, 14); g.fillStyle = "#333"; g.fillText(MAP_CREDIT, W - tw - 4, H - 4);
    return c.toDataURL("image/jpeg", .9);
  }
  $("#mapUse").onclick = async () => {
    let data; try { data = await captureMap(); } catch (e) { console.error(e); return toast("Couldn't capture the map (still loading, or offline?)"); }
    const f = slotEl(mapSlot), ctr = MAP.getCenter(), m = MARK.getLngLat(), q = $("#mapQ").value.trim();
    const apl = APM ? APM.getLngLat() : null;
    f.dataset.map = JSON.stringify({ lat: ctr.lat, lng: ctr.lng, z: MAP.getZoom(), mlat: m.lat, mlng: m.lng, q, alat: apl ? apl.lat : null, alng: apl ? apl.lng : null, st: mapLook, ex: EXTRA.map(x => { const l = x.m.getLngLat(); return [x.k, l.lng, l.lat]; }) });
    remember();
    f.dataset.href = `https://www.google.com/maps/dir/?api=1&destination=${q ? encodeURIComponent(q) : m.lat.toFixed(6) + "," + m.lng.toFixed(6)}`;   // exported map opens directions (to the postcode/address entered)
    if (f.closest(".dc-blk")) mapFix();
    let id;
    if (WS.on && state.project !== PH) {
      const t = new Date(), ts = `${t.getFullYear()}${String(t.getMonth() + 1).padStart(2, "0")}${String(t.getDate()).padStart(2, "0")}-${String(t.getHours()).padStart(2, "0")}${String(t.getMinutes()).padStart(2, "0")}${String(t.getSeconds()).padStart(2, "0")}`;
      const name = "site-map" + (q ? "-" + safeName(q).replace(/\s+/g, "") : "") + "-" + ts + ".jpg";   // a new file every time, so an older capture can never be shown instead
      await writeFile(await subDir(state.project, "media"), name, await (await fetch(data)).blob()); await scanSource(); await dimsReady(); id = `${state.project}/${name}`;
    } else { id = "map-" + Date.now(); const im = new Image(); im.src = data; await im.decode(); LIB.push({ id, project: "Maps", src: data, w: im.naturalWidth, h: im.naturalHeight, embed: true }); }
    setSlot(mapSlot, id, "50% 50%"); const mi = $("img", f); if (mi && WS.on) mi.src = (byId(id) || {}).src || data;
    inlCache.clear(); closeMap(); toast(WS.on && state.project !== PH ? `Map saved to ${state.project}/media` : "Map added");
  };

  /* ------------------------------------------------------------------ archive PDF (rendered in the browser, pages as high-res images + live links) */
  async function buildPdf(dpi = 200) {
    const host = document.createElement("div"); host.style.cssText = "position:fixed;left:-30000px;top:0;";
    host.appendChild(pageWindows()); document.body.appendChild(host); await inlineImgs(host);
    const rs = document.documentElement.style, vars = ["--c-main", "--c-light", "--c-dark", "--c-mixl", "--c-mixd", "--c-main-rgb", "--c-light-rgb", "--c-dark-rgb"]
      .map(v => `${v}:${rs.getPropertyValue(v)}`).join(";");
    const css = `${$("#fontStyle").textContent}\n${$("#docStyle").textContent}\n:root{${vars}}`;
    const pages = [], targets = {};
    $$(".pw", host).forEach((pw, i) => { const pr = pw.getBoundingClientRect(); $$("[id]", pw).forEach(el => { targets[el.id] = { p: i, y: (el.getBoundingClientRect().top - pr.top) / pw.offsetHeight }; }); });
    try {
      for (const pw of $$(".pw", host)) {
        const W = pw.offsetWidth, H = pw.offsetHeight, pr = pw.getBoundingClientRect();
        const links = $$("a[href]", pw).map(a => { const r = a.getBoundingClientRect(); return { href: a.getAttribute("href"), x: (r.left - pr.left) / W, y: (r.top - pr.top) / H, w: r.width / W, h: r.height / H }; })
          .filter(l => l.x < 1 && l.y < 1 && l.x + l.w > 0 && l.y + l.h > 0);
        const xhtml = new XMLSerializer().serializeToString(pw);
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}"><foreignObject x="0" y="0" width="${W}" height="${H}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${W}px;height:${H}px"><style>/*<![CDATA[*/${css}/*]]>*/</style>${xhtml}</div></foreignObject></svg>`;
        const url = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg), im = new Image(); im.src = url;
        await im.decode(); await new Promise(r => setTimeout(r, 120));
        const sc = dpi / 96, c = document.createElement("canvas"); c.width = Math.round(W * sc); c.height = Math.round(H * sc);
        const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height);
        const jb = await new Promise(r => c.toBlob(r, "image/jpeg", .9));
        pages.push({ jpg: new Uint8Array(await jb.arrayBuffer()), pw: c.width, ph: c.height, links, pt: pw.dataset.mm ? pw.dataset.mm.split("x").map(v => +v * 72 / 25.4) : null });
      }
    } finally { host.remove(); }
    return makePdf(pages, PAPER().pt, targets);
  }
  function makePdf(pages, size, targets = {}) {
    const enc = new TextEncoder(), chunks = [], offs = []; let pos = 0;
    const put = x => { const b = typeof x === "string" ? enc.encode(x) : x; chunks.push(b); pos += b.length; };
    const SZ = p => p.pt || size;                     // each page can have its own size (portrait and landscape pages in one document)
    const n = pages.length, pageIds = pages.map((_, i) => 3 + i * 3), esc = s => s.replace(/[\\()]/g, m => "\\" + m);
    let next = 3 + n * 3; const annotIds = pages.map(p => p.links.map(() => next++));
    const obj = (id, body) => { offs[id] = pos; put(`${id} 0 obj\n`); if (typeof body === "string") put(body); else body(); put("\nendobj\n"); };
    put("%PDF-1.4\n%âãÏÓ\n");
    obj(1, "<< /Type /Catalog /Pages 2 0 R >>");
    obj(2, `<< /Type /Pages /Count ${n} /Kids [${pageIds.map(i => i + " 0 R").join(" ")}] >>`);
    pages.forEach((p, i) => {
      const pid = pageIds[i], iid = pid + 1, cid = pid + 2, [PWpt, PHpt] = SZ(p);
      const annots = annotIds[i].length ? ` /Annots [${annotIds[i].map(a => a + " 0 R").join(" ")}]` : "";
      obj(pid, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PWpt} ${PHpt}] /Resources << /XObject << /Im0 ${iid} 0 R >> >> /Contents ${cid} 0 R${annots} >>`);
      obj(iid, () => { put(`<< /Type /XObject /Subtype /Image /Width ${p.pw} /Height ${p.ph} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.jpg.length} >>\nstream\n`); put(p.jpg); put("\nendstream"); });
      const cs = `q ${PWpt} 0 0 ${PHpt} 0 0 cm /Im0 Do Q`;
      obj(cid, `<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`);
    });
    pages.forEach((p, i) => p.links.forEach((l, k) => {
      const [PWpt, PHpt] = SZ(p), tp = pages[(targets[l.href.slice(1)] || {}).p], TPH = tp ? SZ(tp)[1] : PHpt;
      const x1 = (l.x * PWpt).toFixed(2), y2 = (PHpt - l.y * PHpt).toFixed(2), x2 = ((l.x + l.w) * PWpt).toFixed(2), y1 = (PHpt - (l.y + l.h) * PHpt).toFixed(2);
      const tg = l.href.startsWith("#") && targets[l.href.slice(1)];      // contents entries jump inside the PDF
      const act = tg ? `/Dest [${pageIds[tg.p]} 0 R /XYZ 0 ${(TPH - tg.y * TPH + 10).toFixed(2)} null]` : `/A << /S /URI /URI (${esc(l.href)}) >>`;
      obj(annotIds[i][k], `<< /Type /Annot /Subtype /Link /Rect [${x1} ${y1} ${x2} ${y2}] /Border [0 0 0] ${act} >>`);
    }));
    const xref = pos, total = next;
    put(`xref\n0 ${total}\n0000000000 65535 f \n`);
    for (let id = 1; id < total; id++) put(String(offs[id]).padStart(10, "0") + " 00000 n \n");
    put(`trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
    return new Blob(chunks, { type: "application/pdf" });
  }

  /* ------------------------------------------------------------------ start-up */
  function loadLibrary() {
    return window.IMAGE_LIBRARY ? Promise.resolve() : new Promise(res => { const sc = document.createElement("script"); sc.src = "js/library.js"; sc.onload = sc.onerror = res; document.head.appendChild(sc); });
  }
  async function init() {
    applyColour(GMI.main); renderWS();
    const h = fsOK() ? await kvGet("root") : null;
    if (h) { try { if (await h.queryPermission({ mode: "readwrite" }) === "granted") { await useRoot(h); syncPanel(); return; } WS.pending = h.name; } catch (e) {} }
    toast("Loading sample image library…"); await loadLibrary();
    if (!WS.on) { LIB.push(...(window.IMAGE_LIBRARY || [])); addBuiltins(); fillProjectSelect(); renderWS(); renderSaves(); build(); syncPanel(); }
  }

  /* ------------------------------------------------------------------ misc */
  let tt; function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(tt); tt = setTimeout(() => t.classList.remove("on"), 1800); }
  window.GMI_APP = { state, WS, PH, WIP, LAST, asked, get TPL() { return TPL; }, get curSave() { return curSave; }, get lastMark() { return lastMark; }, get blocks() { return isDoc() ? dcBlocks().length : 0; },
    projects, projectRows, savesFor, openSave, openJson, newDoc, startNamed, makeCopy, shareFile, pageCfg, pageSetupInto, perPage: () => pp() && isDoc(), allOrient: o => { remember(); setOrient(o, true); dcNumber(); }, quickSave, switchType, typeOfName, tPill, pname, ask, choose, autosave, toast, connect: () => $("#wsBtn").onclick(), chEsc };
  window.__platform = { autosave, state, LIB, WS, useRoot, snapshot, restore, build, buildPdf, fillFromProject, reflow, markOverflow, fitTitle };   // handy for testing

  /* tooltips for the fixed buttons in the page itself */
  ([    ["[data-type=documentation]", "Documentation: build a document from blocks on flowing pages"], ["[data-type=alert]", "Alert: a one-page alert notice"], ["[data-type=training]", "Training: build a training document from blocks on flowing pages"], ["[data-type=casestudy]", "Case Study"],
    ["#zOut", "Zoom out"], ["#zIn", "Zoom in"], ["#zFit", "Fit the page to the window"], ["#ibW [data-w]", "Image border thickness"],
    ["#tsBold", "Bold"], ["#tsItalic", "Italic"], ["#styleTiles [data-style=s1]", "Red style"], ["#styleTiles [data-style=s3]", "Black (Monolith) style"],
    ["#outHtml", "Export as an HTML file"], ["#outPdf", "Export as a print-ready A4 PDF"], ["#oPort", "Portrait page"], ["#oLand", "Landscape page"],
    ["#mClose", "Close"], ["#mapClose", "Close without changing the map"], ["#mapImage", "Use a photo in place of the map"], ["#mapPin", "Move the site marker to the middle of the map"], ["#mapUse", "Use this map in the document"],
    ["#askCancel", "Cancel"], ["#askOk", "Save"], ["#pipeCancel", "Cancel"], ["#cdCancel", "Cancel"], ["#pipeStRow [data-st=go]", "Project secured"], ["#pipeStRow [data-st=mid]", "Project in tender"], ["#pipeStRow [data-st=early]", "Project at an early stage"],
    ["#delProj", "Permanently delete this project folder and everything in it"], ["#exportSaves", "Download all of this project's saves as a .zip"], ["#sdClose", "Close"]
  ]).forEach(([sel, tip]) => $$(sel).forEach(el => { if (!el.title) el.title = tip; }));

  addBuiltins(); fillProjectSelect(); syncUI(); build(); init();
})();
